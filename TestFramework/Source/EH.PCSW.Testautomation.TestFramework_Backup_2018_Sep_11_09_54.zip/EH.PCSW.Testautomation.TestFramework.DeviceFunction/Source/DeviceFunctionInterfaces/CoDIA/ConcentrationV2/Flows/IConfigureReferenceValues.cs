﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureReferenceValues.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ConfigureReferenceValues interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    /// The ConfigureReferenceValues interface.
    /// </summary>
    public interface IConfigureReferenceValues
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs the specified carrier type.
        /// </summary>
        /// <param name="carrierType">
        /// Type of the carrier.
        /// </param>
        /// <param name="referenceTemperature">
        /// The reference temperature.
        /// </param>
        /// <param name="densityUnit">
        /// The density unit.
        /// </param>
        /// <param name="carrierLinearExpansionCoefficient">
        /// The carrier linear expansion coefficient.
        /// </param>
        /// <param name="carrierSquareExpansionCoefficientTarget">
        /// The carrier square expansion coefficient target.
        /// </param>
        /// <param name="carrierReferenceDensity">
        /// The carrier reference density.
        /// </param>
        /// <param name="targetLinearExpansionCoefficient">
        /// The target linear expansion coefficient.
        /// </param>
        /// <param name="targetSquareExpansionCoefficientTarget">
        /// The target square expansion coefficient target.
        /// </param>
        /// <param name="targetReferenceDensity">
        /// The target reference density.
        /// </param>
        /// <returns>
        /// <c>true</c> if configured, <c>false</c> otherwise.
        /// </returns>
        bool Run(string carrierType, string referenceTemperature, string densityUnit, string carrierLinearExpansionCoefficient, string carrierSquareExpansionCoefficientTarget, string carrierReferenceDensity, string targetLinearExpansionCoefficient, string targetSquareExpansionCoefficientTarget, string targetReferenceDensity);

        #endregion
    }
}