﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIsNewButtonEnabled.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The IsNewButtonEnabled interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.MenuArea.Toolbar.Validation
{
    /// <summary>
    /// The IsNewButtonEnabled interface.
    /// </summary>
    public interface IIsNewButtonEnabled
    {
        #region Public Methods and Operators

        /// <summary>
        /// Returns whether the new button is enabled
        /// </summary>
        /// <returns><c>true</c> if enabled, <c>false</c> otherwise.</returns>
        bool Run();

        #endregion
    }
}