﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureLiquidProperties.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IConfigureLiquidProperties.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of IConfigureLiquidProperties.
    /// </summary>
    public interface IConfigureLiquidProperties
    {
        #region Public Methods and Operators

        /// <summary>
        /// Configures tab Liquid Properties. To skip a parameter, use an empty string.
        /// </summary>
        /// <param name="inputFormat">
        /// The input format.
        /// </param>
        /// <param name="spreadsheet">
        /// The spreadsheet.
        /// </param>
        /// <param name="column1Selection">
        /// The column1 selection.
        /// </param>
        /// <param name="column1Minimum">
        /// The column1 minimum.
        /// </param>
        /// <param name="column1Max">
        /// The column1 maximum.
        /// </param>
        /// <param name="column1Unit">
        /// The column1 unit.
        /// </param>
        /// <param name="column2Selection">
        /// The column2 selection.
        /// </param>
        /// <param name="column2Minimum">
        /// The column2 minimum.
        /// </param>
        /// <param name="column2Max">
        /// The column2 maximum.
        /// </param>
        /// <param name="column2Unit">
        /// The column2 unit.
        /// </param>
        /// <param name="column3Selection">
        /// The column3 selection.
        /// </param>
        /// <param name="column3Minimum">
        /// The column3 minimum.
        /// </param>
        /// <param name="column3Max">
        /// The column3 maximum.
        /// </param>
        /// <param name="column3Unit">
        /// The column3 unit.
        /// </param>
        /// <returns>
        /// <c>true</c> if configured, <c>false</c> otherwise.
        /// </returns>
        bool Run(string inputFormat, string spreadsheet, string column1Selection, string column1Minimum, string column1Max, string column1Unit, string column2Selection, string column2Minimum, string column2Max, string column2Unit, string column3Selection, string column3Minimum, string column3Max, string column3Unit);

        /// <summary>
        /// Configures tab Liquid Properties when Fine Tuning is activated. To skip a parameter, use an empty string.
        /// </summary>
        /// <param name="fineTuningValue1Unit">The fine tuning value1 unit.</param>
        /// <param name="fineTuningValue2Unit">The fine tuning value2 unit.</param>
        /// <param name="fineTuningValue3Unit">The fine tuning value3 unit.</param>
        /// <returns><c>true</c> if configured, <c>false</c> otherwise.</returns>
        bool Run(string fineTuningValue1Unit, string fineTuningValue2Unit, string fineTuningValue3Unit);

        #endregion
    }
}