﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IExpertResults.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides methods for tab expert results within module concentration
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides methods for tab expert results within module concentration
    /// </summary>
    public interface IExpertResults
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the density calibration.
        /// </summary>
        /// <value>The density calibration.</value>
        string DensityCalibration { get; set; }

        /// <summary>
        /// Gets or sets the diagram.
        /// </summary>
        /// <value>The diagram.</value>
        string Diagram { get; set; }

        /// <summary>
        /// Gets or sets the sensor.
        /// </summary>
        /// <value>The sensor.</value>
        string Sensor { get; set; }

        /// <summary>
        /// Gets or sets the field density adjustment.
        /// </summary>
        /// <value>The field density adjustment.</value>
        string FieldDensityAdjustment { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        ///     Get diagram image
        /// </summary>
        /// <returns>
        ///     <br>True: if screenshot could be made</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool GetDiagramImage();

        #endregion
    }
}