﻿//------------------------------------------------------------------------------
// <copyright file="ICheckUserNotificationMessages.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------
/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/9/2013
 * Time: 3:33 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    ///     Description of CheckUserNotificationMessages.
    /// </summary>
    public interface ICheckUserNotificationMessages
    {
        /// <summary>
        ///     Analysis the user notification messages in the status area
        /// </summary>
        /// <returns>
        ///     true: 	if everything is fine
        ///     false:  if an error, failure or warning is detected
        /// </returns>
        bool Run();

        /// <summary>
        ///     Analysis the user notification messages in the status area
        /// </summary>
        /// <param name="message">Message to check</param>
        /// <returns>
        ///     true: 	if everything is fine
        ///     false:  if an error, failure or warning is detected
        /// </returns>
        bool Run(string message);
    }
}