﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IReferenceValues.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Defines the IReferenceValues type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// Interface IReferenceValues
    /// </summary>
    public interface IReferenceValues
    {
        /// <summary>
        /// Gets or sets the linear expansion coefficient target.
        /// </summary>
        /// <value>The linear expansion coefficient target.</value>
        string LinearExpansionCoefficientTarget { get; set; }

        /// <summary>
        /// Gets or sets the linear expansion coefficient carrier.
        /// </summary>
        /// <value>The linear expansion coefficient carrier.</value>
        string LinearExpansionCoefficientCarrier { get; set; }

        /// <summary>
        /// Gets or sets the sugar expansion coefficient carrier.
        /// </summary>
        /// <value>The sugar expansion coefficient carrier.</value>
        string SugarExpansionCoefficientCarrier { get; set; }

        /// <summary>
        /// Gets or sets the sugar expansion coefficient target.
        /// </summary>
        /// <value>The sugar expansion coefficient target.</value>
        string SugarExpansionCoefficientTarget { get; set; }

        /// <summary>
        /// Gets or sets the reference temperature.
        /// </summary>
        /// <value>The reference temperature.</value>
        string ReferenceTemperature { get; set; }

        /// <summary>
        /// Gets or sets the reference density carrier fluid.
        /// </summary>
        /// <value>The reference density carrier fluid.</value>
        string ReferenceDensityCarrierFluid { get; set; }

        /// <summary>
        /// Gets or sets the reference density target fluid.
        /// </summary>
        /// <value>The reference density target fluid.</value>
        string ReferenceDensityTargetFluid { get; set; }

        /// <summary>
        /// Gets or sets the density unit.
        /// </summary>
        /// <value>The density unit.</value>
        string DensityUnit { get; set; }
    }
}