﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISetCoefficientsFromDevice.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface ISetCoefficientsFromDevice
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    /// Interface ISetCoefficientsFromDevice
    /// </summary>
    public interface ISetCoefficientsFromDevice
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs the specified a0.
        /// </summary>
        /// <param name="a0">The a0.</param>
        /// <param name="a1">The a1.</param>
        /// <param name="a2">The a2.</param>
        /// <param name="a3">The a3.</param>
        /// <param name="a4">The a4.</param>
        /// <param name="b1">The b1.</param>
        /// <param name="b2">The b2.</param>
        /// <param name="b3">The b3.</param>
        /// <param name="d1">The d1.</param>
        /// <param name="d2">The d2.</param>
        /// <param name="d3">The d3.</param>
        /// <param name="d4">The d4.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool Run(string a0, string a1, string a2, string a3, string a4, string b1, string b2, string b3, string d1, string d2, string d3, string d4);

        #endregion
    }
}