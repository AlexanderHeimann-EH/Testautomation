﻿/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:06 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    ///     Description of IOpenHelp.
    /// </summary>
    public interface IOpenHelp
    {
        /// <summary>
        ///     Start help via related toolbar-icon
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool ViaIcon();
    }
}