﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckThatAllFieldsInBaseSettingsAreGrayed.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface ICheckThatAllFieldsInBaseSettingsAreGrayed
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// Interface ICheckThatAllFieldsInBaseSettingsAreGrayed
    /// </summary>
    public interface ICheckThatAllFieldsInBaseSettingsAreGrayed
    {
        #region Public Methods and Operators

        /// <summary>
        /// Checks whether all elements in the tab 'Base settings' ( combo boxes, edit fields etc...) except 'Calculation base' are grayed and inactive. 
        /// This is the case then selecting 'Fine tuning' as 'Calculation base'.
        /// </summary>
        /// <returns><c>true</c> if all elements are grayed, <c>false</c> otherwise.</returns>
        bool Run();

        #endregion
    }
}