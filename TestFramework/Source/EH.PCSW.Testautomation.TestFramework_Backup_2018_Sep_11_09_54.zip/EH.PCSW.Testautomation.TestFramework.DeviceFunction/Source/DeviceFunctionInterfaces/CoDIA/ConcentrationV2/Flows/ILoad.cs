﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ILoad.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of ILoad.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of ILoad.
    /// </summary>
    public interface ILoad
    {
        #region Public Methods and Operators

        /// <summary>
        /// Exports Concentration data with default name to report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// load a file with specified file name, check whether user notification message in status bar contains "Data loaded successfully"
        /// </summary>
        /// <param name="fileName">
        /// User specified filename
        /// </param>
        /// <returns>
        /// true: if loading was successful
        ///     false: if an error occurred
        /// </returns>
        bool Run(string fileName);

        #endregion
    }
}