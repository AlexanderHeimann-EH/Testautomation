﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISaveAs.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of ISaveAs.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of ISaveAs.
    /// </summary>
    public interface ISaveAs
    {
        #region Public Methods and Operators

        /// <summary>
        /// Saves file under given filename, replaces already existing files with same filename
        ///     FILE WATCHER will check if file has been created or modified
        ///     Default on drive C:
        /// </summary>
        /// <param name="fileName">
        /// Filename under which file is saved
        /// </param>
        /// <returns>
        /// true: if file was saved successful
        ///     false: if an error occurred
        /// </returns>
        bool Run(string fileName);

        /// <summary>
        /// Exports Concentration data with default name to report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}