﻿/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:08 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    ///     Description of IRunRead.
    /// </summary>
    public interface IRunRead
    {
        /// <summary>
        ///     Start read via related toolbar-icon
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool ViaIcon();
    }
}