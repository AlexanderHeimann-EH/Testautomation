﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISaveClipboardDataToReport.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   The SaveClipboardDataToReport interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Flows
{
    /// <summary>
    /// The SaveClipboardDataToReport interface.
    /// </summary>
    public interface ISaveClipboardDataToReport
    {
        #region Public Methods and Operators

        /// <summary>
        /// Saves the clipboard data to report.
        /// </summary>
        /// <returns>
        /// True if successful; False otherwise
        /// </returns>
        bool Run();

        #endregion
    }
}