﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IGetSetupInformation.cs" company="Endress+Hauer Process Solutions AG">
//  Endress+Hauer Process Solutions AG 
// </copyright>
// <summary>
//   Defines the IGetSetupInformation type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The GetSetupInformation interface.
    /// </summary>
    public interface IGetSetupInformation
    {
        /// <summary>
        /// Setup Information -> Name
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Name();

        /// <summary>
        /// Setup Information -> Version
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Version();

        /// <summary>
        /// Setup Information -> Manufacturer
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Manufacturer();
    }
}