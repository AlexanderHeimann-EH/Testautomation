﻿// -----------------------------------------------------------------------
// <copyright file="IIsSetupVersionCorrect.cs" company="Endress+Hauser Process Solutions AG">
// E+H PCPS AG
// </copyright>
// -----------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// The IsSetupVersionCorrect interface.
    /// </summary>
    public interface IIsSetupVersionCorrect
    {
        /// <summary>
        /// Checks whether a setup version matches the pattern [x]x.[x]x.[x]x.xxxx 
        /// </summary>
        /// <param name="setupVersion">
        /// The setup version.
        /// </param>
        /// <returns>
        /// True: if setup version matches pattern; False: otherwise
        /// </returns>
        bool Run(string setupVersion);
    }
}