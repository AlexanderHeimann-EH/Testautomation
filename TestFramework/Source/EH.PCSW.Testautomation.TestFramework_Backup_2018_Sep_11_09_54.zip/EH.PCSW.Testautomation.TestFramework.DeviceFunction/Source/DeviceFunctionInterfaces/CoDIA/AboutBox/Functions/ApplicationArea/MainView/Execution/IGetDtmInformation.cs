﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IGetDtmInformation.cs" company="Endress+Hauer Process Solutions AG">
//   Endress+Hauer Process Solutions AG
// </copyright>
// <summary>
//   Defines the IGetDtmInformation type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The GetDTMInformation interface.
    /// </summary>
    public interface IGetDtmInformation
    {
        /// <summary>
        /// DTM Information -> Name
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Name();

        /// <summary>
        /// DTM Information -> Version
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Version();

        /// <summary>
        /// DTM Information -> Date
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Date();
    }
}