﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIsModuleReady.cs" company="Endress+Hauer Process Solutions AG">
//   Endress+Hauer Process Solutions AG
// </copyright>
// <summary>
//   Defines the IIsModuleReady type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// The IsModuleReady interface.
    /// </summary>
    public interface IIsModuleReady
    {
        /// <summary>
        /// Checks if button [About] is available
        /// </summary>
        /// <returns>
        /// <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool Run();
    }
}