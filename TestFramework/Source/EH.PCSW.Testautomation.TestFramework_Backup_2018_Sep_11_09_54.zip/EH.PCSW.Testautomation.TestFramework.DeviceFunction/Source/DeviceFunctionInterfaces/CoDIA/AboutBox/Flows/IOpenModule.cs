﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IOpenModule.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The OpenModule interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Flows
{
    /// <summary>
    /// The OpenModule interface.
    /// </summary>
    public interface IOpenModule
    {
        #region Public Methods and Operators

        /// <summary>
        /// Open module via frame menu within a default time
        /// </summary>
        ///  <returns>
        /// <br>True: if everything worked fine</br>
        /// <br>False: if an error occurred</br>
        /// </returns>
        bool Run();

        /// <summary>
        /// Open module via frame menu within a default time
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds for the module opening.
        /// </param>
        /// <returns>
        /// <br>True: if everything worked fine</br>
        /// <br>False: if an error occurred</br>
        /// </returns>
        bool Run(int timeoutInMilliseconds);

        #endregion
    }
}