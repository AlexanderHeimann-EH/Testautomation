﻿// -----------------------------------------------------------------------
// <copyright file="ISaveClipboardDataToFile.cs" company="Endress+Hauser Process Solutions AG">
// E+H PCPS AG
// </copyright>
// -----------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Flows
{
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// The SaveClipboardDataToFile interface.
    /// </summary>
    public interface ISaveClipboardDataToFile
    {
        /// <summary>
        /// Saves the clipboard data with default path and file name
        /// </summary>
        /// <returns>
        /// True if file is saved; False otherwise
        /// </returns>
        bool Run();

        /// <summary>
        /// Saves the clipboard data to a file with a default file name on the desktop (File name = actual date and time + AboutBox.txt).
        /// </summary>
        /// <param name="filePath">
        /// The file path including the file name i.e. "C:\Test\AboutBoxMicropilot.txt"
        /// </param>
        /// <returns>
        /// True if file is saved; False otherwise
        /// </returns>
        [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "Reviewed. Suppression is OK here.")]
        bool Run(string filePath);
    }
}