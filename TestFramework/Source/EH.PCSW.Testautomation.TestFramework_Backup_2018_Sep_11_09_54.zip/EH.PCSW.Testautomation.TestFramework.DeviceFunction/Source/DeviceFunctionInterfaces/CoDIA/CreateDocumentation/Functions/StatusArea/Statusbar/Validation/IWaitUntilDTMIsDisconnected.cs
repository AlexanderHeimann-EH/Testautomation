﻿//------------------------------------------------------------------------------
// <copyright file="WaitUntilDTMIsDisconnected.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------
/*
 * Created by Ranorex
 * User: testadmin
 * Date: 11/06/2013
 * Time: 2:00 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    /// 
    /// </summary>
    public interface IWaitUntilDTMIsDisconnected
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="timeOutInMilliseconds"></param>
        /// <returns></returns>
        bool Run(int timeOutInMilliseconds);
    }
}