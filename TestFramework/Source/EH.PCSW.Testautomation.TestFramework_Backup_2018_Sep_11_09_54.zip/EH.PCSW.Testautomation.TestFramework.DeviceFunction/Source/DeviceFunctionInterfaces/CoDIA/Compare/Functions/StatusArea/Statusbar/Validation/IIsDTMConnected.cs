﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIsDtmConnected.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface of IsDTMConnected
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.StatusArea.Statusbar.Validation
{
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    ///     Interface of IsDTMConnected
    /// </summary>
    public interface IIsDtmConnected
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Determines whether dtm is online
        /// </summary>
        /// <returns>
        ///     true: if DTM is online
        ///     false: if DTM is offline or an error occurred
        /// </returns>
        [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "Reviewed. Suppression is OK here.")]
        bool Run();

        #endregion
    }
}