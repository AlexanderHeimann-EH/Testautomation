﻿//------------------------------------------------------------------------------
// <copyright file="ISelectMode.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Zander Jan
 * Date: 24.07.2012
 * Time: 3:18 
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Flows
{
    using System;

    /// <summary>
    ///     Interface for SelectMode
    /// </summary>
    public interface ISelectMode
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        bool Run(int index);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        bool Run(String mode);
    }
}