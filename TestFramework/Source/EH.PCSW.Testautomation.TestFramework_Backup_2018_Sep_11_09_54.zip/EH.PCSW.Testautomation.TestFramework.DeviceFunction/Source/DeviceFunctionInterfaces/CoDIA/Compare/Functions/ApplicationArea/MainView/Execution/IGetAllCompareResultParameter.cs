﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IGetAllCompareResultParameter.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   The GetAllCompareResultParameter interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.ApplicationArea.MainView.Execution
{
    using System.Collections.Generic;

    using EH.PCPS.TestAutomation.Common;

    /// <summary>
    /// The GetAllCompareResultParameter interface.
    /// </summary>
    public interface IGetAllCompareResultParameter
    {
        #region Public Methods and Operators

        /// <summary>
        /// Navigates through the Compare results tree and stores every parameter in a list. A parameter contains its name, the offline and online value.
        /// </summary>
        /// <returns>A list containing the Compare result parameter.</returns>
        List<CompareParameter> Run();

        #endregion
    }
}