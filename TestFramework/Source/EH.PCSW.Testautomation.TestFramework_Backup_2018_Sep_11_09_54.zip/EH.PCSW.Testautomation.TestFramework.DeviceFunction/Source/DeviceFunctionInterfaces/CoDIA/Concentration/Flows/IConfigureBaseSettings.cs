﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureBaseSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IConfigureBaseSettings.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IConfigureBaseSettings.
    /// </summary>
    public interface IConfigureBaseSettings
    {
        #region Public Methods and Operators       

        /// <summary>
        /// THIS METHOD IS OBSOLETE AND WORKS ONLY WITH OLDER TESTPACKAGES. Configures tab base settings. To ignore a value, it must be an empty string like this -&gt; "".
        /// </summary>
        /// <param name="calculationBase">
        /// Calculation base
        /// </param>
        /// <param name="liquidType">
        /// Liquid type
        /// </param>
        /// <param name="densityCalibration">
        /// Density Calibration
        /// </param>
        /// <param name="fieldDensityAdjustment">
        /// Field Density Adjustment
        /// </param>
        /// <param name="sensor">
        /// Sensor parameter
        /// </param>
        /// <param name="temperaturUnit">
        /// Temperature Unit
        /// </param>
        /// <param name="temperaturMin">
        /// Temperature Min.
        /// </param>
        /// <param name="temperaturMax">
        /// Temperature Max.
        /// </param>
        /// <param name="concentrationUnit">
        /// Concentration Unit
        /// </param>
        /// <param name="concentrationMin">
        /// Concentration Min.
        /// </param>
        /// <param name="concentrationMax">
        /// Concentration Max.
        /// </param>
        /// <returns>
        /// <br>true: if all worked fine</br>
        ///     <br>false: if an error occurred</br>
        /// </returns>
        bool Run(string calculationBase, string liquidType, string densityCalibration, string fieldDensityAdjustment, string sensor, string temperaturUnit, string temperaturMin, string temperaturMax, string concentrationUnit, string concentrationMin, string concentrationMax);

        #endregion
    }
}