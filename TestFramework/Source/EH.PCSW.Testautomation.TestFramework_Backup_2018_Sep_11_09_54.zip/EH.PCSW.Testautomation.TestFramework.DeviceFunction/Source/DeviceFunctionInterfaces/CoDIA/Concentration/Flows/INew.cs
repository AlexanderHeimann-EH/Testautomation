﻿//------------------------------------------------------------------------------
// <copyright file="INew.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of INew.
    /// </summary>
    public interface INew
    {
        /// <summary>
        /// Clears Concentration data via New button, checks whether coefficients in coefficients overview are empty
        /// </summary>
        /// <returns>true: if Concentration data is cleared; false: if an error occurred</returns>
        bool Run();
    }
}