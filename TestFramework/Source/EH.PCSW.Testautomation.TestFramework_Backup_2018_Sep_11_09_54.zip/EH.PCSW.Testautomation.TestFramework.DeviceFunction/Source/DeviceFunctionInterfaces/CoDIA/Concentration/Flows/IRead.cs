﻿//------------------------------------------------------------------------------
// <copyright file="IRead.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IRead.
    /// </summary>
    public interface IRead
    {
        /// <summary>
        ///     Reads coefficients from device, waits until "read finished" user notification message is displayed and read icon is enabled again
        /// </summary>
        /// <returns>
        ///     true: if coefficients were read
        ///     false: if an error occurred
        /// </returns>
        bool Run();
    }
}