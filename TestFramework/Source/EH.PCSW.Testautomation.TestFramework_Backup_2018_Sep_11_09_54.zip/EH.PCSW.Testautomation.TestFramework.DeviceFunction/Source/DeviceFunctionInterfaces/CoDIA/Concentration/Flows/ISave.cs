﻿/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of ISave.
    /// </summary>
    public interface ISave
    {
        /// <summary>
        ///     Saves current Viscosity data via Save button
        /// </summary>
        /// <returns>
        ///     true: if call worked fine
        ///     false: if an error occurred
        /// </returns>
        bool Run();
    }
}