﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISetCoefficientsFromDevice.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Defines the ISetCoefficientsFromDevice type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    /// Interface ISetCoefficientsFromDevice
    /// </summary>
    public interface ISetCoefficientsFromDevice
    {
        /// <summary>
        /// Sets coefficients from device
        /// </summary>
        /// <param name="a0">
        /// The a0 coefficient.
        /// </param>
        /// <param name="a1">
        /// The a1 coefficient.
        /// </param>
        /// <param name="a2">
        /// The a2 coefficient.
        /// </param>
        /// <param name="a3">
        /// The a3 coefficient.
        /// </param>
        /// <param name="a4">
        /// The a4 coefficient.
        /// </param>
        /// <param name="b1">
        /// The b1 coefficient.
        /// </param>
        /// <param name="b2">
        /// The b2 coefficient.
        /// </param>
        /// <param name="b3">
        /// The b3 coefficient.
        /// </param>
        /// <returns>
        /// <c>true</c> if coefficients have been set correctly, <c>false</c> otherwise.
        /// </returns>
        bool Run(string a0, string a1, string a2, string a3, string a4, string b1, string b2, string b3);
    }
}