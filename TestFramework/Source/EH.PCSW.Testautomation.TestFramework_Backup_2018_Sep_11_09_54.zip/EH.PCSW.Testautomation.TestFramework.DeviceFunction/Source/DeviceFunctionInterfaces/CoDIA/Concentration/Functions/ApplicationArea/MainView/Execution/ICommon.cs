﻿//------------------------------------------------------------------------------
// <copyright file="ICommon.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 01.11.2012
 * Time: 8:16 
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Functions.ApplicationArea.MainView.Execution
{
    using Ranorex.Core;

    /// <summary>
    ///     Provides methods for tab liquid properties within module concentration
    /// </summary>
    public interface ICommonMethods
    {
        #region public

        /// <summary>
        ///     Set a specific control to a specific value
        /// </summary>
        /// <param name="element">control to set</param>
        /// <param name="value">value to set</param>
        /// <returns>
        ///     <br>True: if parameter was set</br>
        ///     <br>Null: if an error occurred</br>
        /// </returns>
        bool SetParameterValue(Element element, string value);

        /// <summary>
        ///     Get value of a specific control
        /// </summary>
        /// <param name="element">control to get the value from</param>
        /// <returns>
        ///     <br>String: if everything worked fine</br>
        ///     <br>Emptry String: if an error occurred</br>
        /// </returns>
        string GetParameterValue(Element element);

        /// <summary>
        ///     Set a text control to a specified value
        /// </summary>
        /// <param name="element">parameter to set</param>
        /// <param name="value">value to set</param>
        /// <returns>
        ///     <br>True: if parameter was set</br>
        ///     <br>Null: if an error occurred</br>
        /// </returns>
        bool SetTextValue(Element element, string value);

        /// <summary>
        ///     Set a comboBox control to a specified value
        /// </summary>
        /// <param name="element">parameter to set</param>
        /// <param name="value">value to set</param>
        /// <returns>
        ///     <br>True: if parameter was set</br>
        ///     <br>Null: if an error occurred</br>
        /// </returns>
        bool SetComboBoxValue(Element element, string value);

        #endregion
    }
}