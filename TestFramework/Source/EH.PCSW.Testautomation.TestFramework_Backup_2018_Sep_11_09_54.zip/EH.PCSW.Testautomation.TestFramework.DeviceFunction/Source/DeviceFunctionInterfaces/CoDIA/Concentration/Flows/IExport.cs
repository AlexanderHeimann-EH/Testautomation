﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IExport.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IExport.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IExport.
    /// </summary>
    public interface IExport
    {
        #region Public Methods and Operators

        /// <summary>
        /// Exports Concentration data with default name to report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Exports Viscosity data with user given filename
        /// </summary>
        /// <param name="filename">
        /// Filename for Visosity Data
        /// </param>
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run(string filename);

        #endregion
    }
}