﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICalculate.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of ICalculate.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of ICalculate.
    /// </summary>
    public interface ICalculate
    {
        #region Public Methods and Operators

        /// <summary>
        /// Starts calculation via icon, waits until calculation is finished
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run();

        #endregion
    }
}