﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIsDtmConnected.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IsDtmConnected.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    ///     Description of IsDtmConnected.
    /// </summary>
    public interface IIsDtmConnected
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Determines whether dtm is online
        /// </summary>
        /// <returns>
        ///     true: if DTM is online
        ///     false: if DTM is offline or an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}