﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureSettingsTab.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ConfigureSettingsTab interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The ConfigureSettingsTab interface.
    /// </summary>
    public interface IConfigureSettingsTab
    {
        #region Public Methods and Operators

        /// <summary>
        /// Gets firmware version
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetFirmwareVersion();


        /// <summary>
        /// Gets device name
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetDeviceName();


        /// <summary>
        /// Gets order code
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetOrderCode();


        /// <summary>
        /// Gets serial number
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetSerialNumber();


        /// <summary>
        /// Get operating time
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetOperatingTime();


        /// <summary>
        /// Get date time
        /// </summary>
        /// <returns>
        /// Text value.
        /// </returns>
        string GetDateTime();


        #endregion
    }
}