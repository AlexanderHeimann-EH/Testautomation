﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClickOnWrite.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ClickOnWrite interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The ClickOnWrite interface.
    /// </summary>
    public interface IClickOnWrite
    {
        #region Public Methods and Operators

        /// <summary>
        /// Mouse click on the button Write
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run();

        #endregion
    }
}