﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IIsDtmDisconnected.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IsDTMDisconnected.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    ///     Description of IsDTMDisconnected.
    /// </summary>
    public interface IIsDtmDisconnected
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Determines whether dtm is offline
        /// </summary>
        /// <returns>
        ///     true: if DTM is offline
        ///     false: if DTM is online or an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}