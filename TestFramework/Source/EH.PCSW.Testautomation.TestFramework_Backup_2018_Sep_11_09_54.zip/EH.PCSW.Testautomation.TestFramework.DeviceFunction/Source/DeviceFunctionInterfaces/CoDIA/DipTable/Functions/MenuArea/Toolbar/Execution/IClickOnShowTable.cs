﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClickOnShowTable.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The IClickOnShowTable interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    /// The IClickOnShowTable interface.
    /// </summary>
    public interface IClickOnShowTable
    {
        #region Public Methods and Operators

        /// <summary>
        /// Mouse click on the button show table
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run();

        #endregion
    }
}