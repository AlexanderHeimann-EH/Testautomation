﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IImport.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The Import interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Flows
{
    /// <summary>
    /// The Import interface.
    /// </summary>
    public interface IImport
    {
        #region Public Methods and Operators

        /// <summary>
        /// Export Linearization data with default file name to report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Imports Linearization data via toolbar icon
        /// </summary>
        /// <param name="filename">
        /// filename (and path)of dataset which should be imported
        /// </param>
        /// <returns>
        /// true, if file was imported successfully; false, if an error occurred
        /// </returns>
        bool Run(string filename);

        #endregion
    }
}