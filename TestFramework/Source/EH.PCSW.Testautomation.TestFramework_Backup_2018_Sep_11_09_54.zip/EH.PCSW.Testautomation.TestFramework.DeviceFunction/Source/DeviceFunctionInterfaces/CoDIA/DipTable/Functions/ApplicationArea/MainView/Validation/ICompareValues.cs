﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICompareValues.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The CompareValues interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Validation
{
    using System.Collections.Generic;

    /// <summary>
    /// The CompareValues interface.
    /// </summary>
    public interface ICompareValues
    {
        #region Public Methods and Operators

        /// <summary>
        /// Determines whether values of two lists representing the Linearization table are equal
        /// </summary>
        /// <param name="values">
        /// The values.
        /// </param>
        /// <param name="referenceValues">
        /// The reference values.
        /// </param>
        /// <param name="accuracy">
        /// The accuracy for the comparison of two double values.
        /// </param>
        /// <returns>
        /// <c>true</c> if values are equal, <c>false</c> otherwise.
        /// </returns>
        bool AreValuesEqual(List<string> values, List<string> referenceValues, double accuracy);

        #endregion
    }
}