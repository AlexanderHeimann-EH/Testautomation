﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IWaitUntilModuleOnlineIsReady.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IWaitUntilModuleOnlineIsReady.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Description of IWaitUntilModuleOnlineIsReady.
    /// </summary>
    public interface IWaitUntilModuleOnlineIsReady
    {
        #region Public Methods and Operators

        /// <summary>
        /// Validation if module (online) is ready within a specified time
        /// </summary>
        /// <param name="timeOutInMilliseconds">
        /// Time within module should be ready
        /// </param>
        /// <returns>
        /// <br>True: if module is ready in time</br>
        ///     <br>False: if module is not ready in time</br>
        /// </returns>
        bool Run(int timeOutInMilliseconds);

        #endregion
    }
}