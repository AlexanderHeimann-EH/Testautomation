﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IWrite.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The Write interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Flows
{
    /// <summary>
    /// The Write interface.
    /// </summary>
    public interface IWrite
    {
        #region Public Methods and Operators

        /// <summary>
        /// Writes to device
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout In Milliseconds.
        /// </param>
        /// <returns>
        /// true: if writing finished successfully; false: if an error occurred
        /// </returns>
        bool Run(int timeoutInMilliseconds);

        #endregion
    }
}