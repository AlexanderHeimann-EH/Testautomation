﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckUserNotificationMessages.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The CheckUserNotificationMessages interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.StatusArea.Usermessages.Validation
{
    /// <summary>
    /// The CheckUserNotificationMessages interface.
    /// </summary>
    public interface ICheckUserNotificationMessages
    {
        #region Public Methods and Operators

        /// <summary>
        /// Scans the user notification messages in the status area for error messages
        /// </summary>
        /// <returns>
        /// true:  if the text contains any of the keywords
        /// false:  if the text does not contain any of the keywords
        /// </returns>
        bool ContainsError();

        /// <summary>
        /// Checks whether the user message contains a particular string
        /// </summary>
        /// <param name="value">
        /// String to look for
        /// </param>
        /// <returns>
        /// true: if the user message contains the string
        /// false: if string is not found
        /// </returns>
        bool ContainsString(string value);

        /// <summary>
        /// The user message.
        /// </summary>
        /// <returns>
        /// The actual user message
        /// </returns>
        string UserMessage();

        #endregion
    }
}