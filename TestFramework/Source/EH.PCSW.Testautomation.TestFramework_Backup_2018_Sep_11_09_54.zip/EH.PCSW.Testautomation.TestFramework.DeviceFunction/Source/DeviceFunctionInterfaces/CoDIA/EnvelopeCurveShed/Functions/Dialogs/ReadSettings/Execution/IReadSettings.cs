﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IReadSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Description of ReadSettings.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.Dialogs.ReadSettings.Execution
{
    /// <summary>
    ///     Description of ReadSettings.
    /// </summary>
    public interface IReadSettings
    {
        #region Public Properties

        /// <summary>
        ///     Can access the Begin of the Range.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        string BeginRangeUnit { get; }

        /// <summary>
        ///     Can access the Begin of the Range.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        double EditBeginRange { get; set; }

        /// <summary>
        ///     Can access the End of the Range.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        double EditEndRage { get; set; }

        /// <summary>
        ///     Can access the Begin of the Range.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        string EndRangeUnit { get; }

        /// <summary>
        ///     Change resolution
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        double Resolution { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        ///     Cancel settings. Changes are lost. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Cancel();

        /// <summary>
        ///     Check curves which should be read
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool CheckAllCurves();

        /// <summary>
        ///     Cancel settings. Changes are lost. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Close();

        /// <summary>
        ///     Confirm settings. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Confirm();

        /// <summary>
        ///     Confirm settings and start to read immediately. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool ReadNow();

        /// <summary>
        ///     Check curves which should not be read
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool UncheckAllCurves();

        #endregion
    }
}