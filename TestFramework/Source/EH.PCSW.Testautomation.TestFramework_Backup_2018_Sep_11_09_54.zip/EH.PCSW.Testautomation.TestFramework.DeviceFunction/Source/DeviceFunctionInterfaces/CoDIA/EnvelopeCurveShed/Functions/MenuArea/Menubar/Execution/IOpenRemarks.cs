﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IOpenRemarks.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface for function Open Remarks
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface for function Open Remarks
    /// </summary>
    public interface IOpenRemarks
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via button
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}