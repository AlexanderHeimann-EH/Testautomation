﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunFastForward.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality fast forward playback
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    ///     Interface to start Envelope Curve functionality fast forward playback
    /// </summary>
    public interface IRunFastForward
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via icon
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaIcon();

        #endregion
    }
}