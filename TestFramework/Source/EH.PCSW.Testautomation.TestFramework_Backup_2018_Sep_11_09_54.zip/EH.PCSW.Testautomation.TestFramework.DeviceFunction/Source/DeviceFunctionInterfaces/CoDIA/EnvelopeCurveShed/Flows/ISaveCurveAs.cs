﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISaveCurveAs.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of ISaveCurveAs.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Flows
{
    /// <summary>
    ///     Description of ISaveCurveAs.
    /// </summary>
    public interface ISaveCurveAs
    {
        #region Public Methods and Operators

        /// <summary>
        /// Save curve(s) with default file name in report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        ///     Methods to save curves
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu();

        /// <summary>
        /// Methods to save curves
        /// </summary>
        /// <param name="filename">
        /// File to save as named
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename);

        /// <summary>
        /// Methods to save curves
        /// </summary>
        /// <param name="filename">
        /// File to save as named
        /// </param>
        /// <param name="overwriteData">
        /// Enable / disable overwriting data mode
        /// </param>
        /// <param name="appendData">
        /// Enable / disable appending data mode
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename, bool overwriteData, bool appendData);

        #endregion
    }
}