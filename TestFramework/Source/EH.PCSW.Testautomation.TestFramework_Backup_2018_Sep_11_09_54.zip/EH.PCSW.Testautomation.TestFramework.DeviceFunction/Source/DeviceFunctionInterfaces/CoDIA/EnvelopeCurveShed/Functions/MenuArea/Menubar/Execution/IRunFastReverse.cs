﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunFastReverse.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality fast reverse playback
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface to start Envelope Curve functionality fast reverse playback
    /// </summary>
    public interface IRunFastReverse
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via menu
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}