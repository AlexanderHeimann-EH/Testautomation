﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IWaitUntilModuleOnlineIsReady.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Description of WaitUntilModuleOnlineIsReady.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Description of WaitUntilModuleOnlineIsReady.
    /// </summary>
    public interface IWaitUntilModuleOnlineIsReady
    {
        #region Public Methods and Operators

        /// <summary>
        /// Validation if module (online) is ready within a specified time
        /// </summary>
        /// <param name="timeOutInMilliseconds">
        /// Time within module should be ready
        /// </param>
        /// <returns>
        /// <br>True: if module is ready in time</br>
        ///     <br>False: if module is not ready in time</br>
        /// </returns>
        bool Run(int timeOutInMilliseconds);

        #endregion
    }
}