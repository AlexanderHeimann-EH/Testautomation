﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunHelp.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to open Envelope Curve menu help
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    using Ranorex.Core;

    /// <summary>
    ///     Interface to open Envelope Curve menu help
    /// </summary>
    public interface IRunHelp
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="Element"/>.
        /// </returns>
        Element ViaMenu();

        #endregion
    }
}