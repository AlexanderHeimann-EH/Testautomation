﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunCyclicRead.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface for function Run Cyclic Read
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    ///     Interface for function Run Cyclic Read
    /// </summary>
    public interface IRunCyclicRead
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via icon
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaIcon();

        #endregion
    }
}