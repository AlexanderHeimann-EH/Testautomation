﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunResetReadingRange.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Defines the IRunResetReadingRange type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    /// Interface IRunResetReadingRange
    /// </summary>
    public interface IRunResetReadingRange
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}