﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IReadAndWrite.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Validation methods for all read and write related actions
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Validation methods for all read and write related actions
    /// </summary>
    public interface IReadAndWrite
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Based on visual detection this function searches for the blue gradient color of the progressbar in the lower statusbar
        /// </summary>
        /// <returns>
        ///     <br>True: if progress bar is visible</br>
        ///     <br>False: if progress bar is not visible</br>
        /// </returns>
        bool IsProgressbarVisible();

        /// <summary>
        ///     Checks if envelope curve is in reading mode
        /// </summary>
        /// <returns>
        ///     <br>True: if module is reading curves</br>
        ///     <br>False: if module is not reading curves</br>
        /// </returns>
        bool IsReading();

        /// <summary>
        ///     Checks if stop reading button is enabled and accessible
        /// </summary>
        /// <returns>
        ///     <br>True: if module is ready to stop reading</br>
        ///     <br>False: if module is not ready to stop reading</br>
        /// </returns>
        bool IsReadyToStopReading();

        /// <summary>
        ///     Checks if envelope curve is in MAP writing mode
        /// </summary>
        /// <returns>
        ///     <br>True: if module is writing MAP</br>
        ///     <br>False: if module is not writing MAP</br>
        /// </returns>
        bool IsWritingMAP();

        /// <summary>
        /// Waits until Read-Curve is finished
        /// </summary>
        /// <param name="timeOutInMilliseconds">
        /// Time within module should be ready
        /// </param>
        /// <returns>
        /// <br>True: if reading is finished in time</br>
        ///     <br>False: if reading is not finished in time</br>
        /// </returns>
        bool WaitUntilReadFinished(int timeOutInMilliseconds);

        #endregion
    }
}