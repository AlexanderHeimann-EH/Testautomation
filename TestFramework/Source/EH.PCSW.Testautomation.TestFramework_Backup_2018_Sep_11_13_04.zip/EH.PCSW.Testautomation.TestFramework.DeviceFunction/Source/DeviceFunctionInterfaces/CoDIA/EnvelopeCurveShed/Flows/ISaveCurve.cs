﻿//------------------------------------------------------------------------------
// <copyright file="ISaveCurve.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Effner, Christian
 * Date: 10.07.2012
 * Time: 9:25 
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Flows
{
    /// <summary>
    ///     Description of ISaveCurve.
    /// </summary>
    public interface ISaveCurve
    {
        /// <summary>
        ///     Methods to save curves
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu();

        /// <summary>
        ///     Methods to save curves
        /// </summary>
        /// <param name="filename">File to save as named</param>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename);

        /// <summary>
        ///     Methods to save curves
        /// </summary>
        /// <param name="filename">File to save as named</param>
        /// <param name="overwriteData">Enable / disable overwriting data mode</param>
        /// <param name="appendData">Enable / disable appending data mode</param>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename, bool overwriteData, bool appendData);
    }
}