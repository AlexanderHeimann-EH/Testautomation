﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IZoomAndGridSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Description of ReadSettings.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.Dialogs.ZoomAndGridSettings.Execution
{
    /// <summary>
    ///     Description of ReadSettings.
    /// </summary>
    public interface IZoomAndGridSettings
    {
        #region Public Properties

        /// <summary>
        ///     Can access the xMax of zoom area.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        double XMax { get; set; }

        /// <summary>
        ///     Can access the xMax Unit of zoom area.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        string XMaxUnit { get; }

        /// <summary>
        ///     Can access the xMin of zoom area.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        double XMin { get; set; }

        /// <summary>
        ///     Can access the xMin Unit of zoom area.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        string XMinUnit { get; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        ///     Cancel settings. Changes are lost. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Cancel();

        /// <summary>
        ///     Cancel settings. Changes are lost. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Close();

        /// <summary>
        ///     Confirm settings. Dialog is closed.
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Confirm();

        #endregion
    }
}