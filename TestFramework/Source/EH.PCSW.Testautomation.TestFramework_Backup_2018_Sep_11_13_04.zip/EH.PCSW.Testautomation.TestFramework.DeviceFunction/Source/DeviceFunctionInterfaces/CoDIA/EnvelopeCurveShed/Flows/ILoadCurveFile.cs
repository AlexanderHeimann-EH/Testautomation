﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ILoadCurveFile.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface for flow Load Curve File
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Flows
{
    /// <summary>
    ///     Interface for flow Load Curve File
    /// </summary>
    public interface ILoadCurveFile
    {
        #region Public Methods and Operators

        /// <summary>
        /// Save curve(s) with default file name in report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Start flow with default behavior
        /// </summary>
        /// <param name="filename">
        /// File to load
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename);

        /// <summary>
        /// Start flow with specific behavior
        /// </summary>
        /// <param name="filename">
        /// File to load
        /// </param>
        /// <param name="discardUnsaved">
        /// Behavior if unsaved curves are available
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(string filename, bool discardUnsaved);

        #endregion
    }
}