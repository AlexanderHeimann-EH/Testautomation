﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunEnvelopeCurve.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Start menu Envelope Curve
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    using Ranorex.Core;

    /// <summary>
    ///     Start menu Envelope Curve
    /// </summary>
    public interface IRunEnvelopeCurve
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via menu
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        Element ViaMenu();

        #endregion
    }
}