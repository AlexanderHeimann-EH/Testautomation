﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunDisplay.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface for function Run Display
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    using Ranorex.Core;

    /// <summary>
    ///     Interface for function Run Display
    /// </summary>
    public interface IRunDisplay
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via menu
        /// </summary>
        /// <returns>
        ///     <br>Element: if call worked fine</br>
        ///     <br>Null: if an error occurred</br>
        /// </returns>
        Element ViaMenu();

        #endregion
    }
}