﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunUndoZoom.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality undo zoom
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface to start Envelope Curve functionality undo zoom
    /// </summary>
    public interface IRunUndoZoom
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}