﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunPlayback.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality playback curves
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    using Ranorex.Core;

    /// <summary>
    ///     Interface to start Envelope Curve functionality playback curves
    /// </summary>
    public interface IRunPlayback
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="Element"/>.
        /// </returns>
        Element ViaMenu();

        #endregion
    }
}