﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunNewCurve.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality new (empty) diagram, parameters and curve data
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface to start Envelope Curve functionality new (empty) diagram, parameters and curve data
    /// </summary>
    public interface IRunNewCurve
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}