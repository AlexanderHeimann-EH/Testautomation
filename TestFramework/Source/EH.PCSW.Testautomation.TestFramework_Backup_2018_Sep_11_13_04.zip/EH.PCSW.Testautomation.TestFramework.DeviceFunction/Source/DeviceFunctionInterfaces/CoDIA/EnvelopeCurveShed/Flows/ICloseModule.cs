﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICloseModule.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides interfaces for CloseModule
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Flows
{
    /// <summary>
    ///     Provides interfaces for CloseModule
    /// </summary>
    public interface ICloseModule
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Interface for function ViaWindow
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run();

        /// <summary>
        /// Close module via frame menu within a default time
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout In Milliseconds.
        /// </param>
        /// <returns>
        /// <br>True: if everything worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run(int timeoutInMilliseconds);

        #endregion
    }
}