﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IOpenModule.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Provides methods for function IOpenModule.cs
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides methods for function IOpenModule.cs
    /// </summary>
    public interface IOpenModule
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Methods to Open module
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu();

        /// <summary>
        /// Methods to Open module
        /// </summary>
        /// <param name="moduleToOpen">
        /// Module name
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu(string moduleToOpen);

        #endregion
    }
}