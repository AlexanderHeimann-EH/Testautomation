﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IOpenCyclicReadSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface for function Open Cyclic Read Settings
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface for function Open Cyclic Read Settings
    /// </summary>
    public interface IOpenCyclicReadSettings
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Open via menu
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}