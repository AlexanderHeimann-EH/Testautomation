﻿//------------------------------------------------------------------------------
// <copyright file="ICurveReadingSingle.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Effner, Christian
 * Date: 10.07.2012
 * Time: 9:25 
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Flows
{
    /// <summary>
    ///     Provides methods for flow ICurveReadingSingle
    /// </summary>
    public interface ICurveReadingSingle
    {
        /// <summary>
        ///     Method to start curve reading via menu
        /// </summary>
        /// <param name="waitUntilFinished">Time until action must be finished</param>
        /// <returns>
        ///     <br>True: if curves are read</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaMenu(bool waitUntilFinished);

        /// <summary>
        ///     Method to start curve reading via icon
        /// </summary>
        /// <param name="waitUntilFinished">Time until action must be finished</param>
        /// <returns>
        ///     <br>True: if curves are read</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool RunViaIcon(bool waitUntilFinished);
    }
}