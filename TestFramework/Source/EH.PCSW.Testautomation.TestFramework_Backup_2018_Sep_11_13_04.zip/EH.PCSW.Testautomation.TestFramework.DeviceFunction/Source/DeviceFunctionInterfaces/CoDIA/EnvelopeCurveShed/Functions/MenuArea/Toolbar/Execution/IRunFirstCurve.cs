﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunFirstCurve.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to start Envelope Curve functionality show first curve
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    ///     Interface to start Envelope Curve functionality show first curve
    /// </summary>
    public interface IRunFirstCurve
    {
        #region Public Methods and Operators

        /// <summary>
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool ViaIcon();

        #endregion
    }
}