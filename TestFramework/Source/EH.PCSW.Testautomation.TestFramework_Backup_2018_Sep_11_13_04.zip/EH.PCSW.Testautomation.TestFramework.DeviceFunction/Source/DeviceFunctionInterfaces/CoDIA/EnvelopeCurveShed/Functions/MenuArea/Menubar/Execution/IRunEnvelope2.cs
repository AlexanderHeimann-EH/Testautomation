﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRunEnvelope2.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Interface to use Envelope Curve -&gt; Set Cursor -&gt; Cursor 2 -&gt; Envelope Curve
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.EnvelopeCurveShed.Functions.MenuArea.Menubar.Execution
{
    /// <summary>
    ///     Interface to use Envelope Curve -> Set Cursor -> Cursor 2 -> Envelope Curve
    /// </summary>
    public interface IRunEnvelope2
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Run via context
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaContext();

        /// <summary>
        ///     Run via menu
        /// </summary>
        /// <returns>
        ///     <br>True: if element was found and clicked</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool ViaMenu();

        #endregion
    }
}