﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureLiquidProperties.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IConfigureLiquidProperties.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IConfigureLiquidProperties.
    /// </summary>
    public interface IConfigureLiquidProperties
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs the specified calculation base.
        /// </summary>
        /// <param name="calculationBase">The calculation base.</param>
        /// <param name="sensor">The sensor.</param>
        /// <param name="densityCalibration">The density calibration.</param>
        /// <param name="temperaturMin">The temperature minimum.</param>
        /// <param name="temperaturMax">The temperature maximum.</param>
        /// <param name="temperaturUnit">The temperature unit.</param>
        /// <param name="densityMin">The density minimum.</param>
        /// <param name="densityMax">The density maximum.</param>
        /// <param name="densityUnit">The density unit.</param>
        /// <param name="concentrationMin">The concentration minimum.</param>
        /// <param name="concentrationMax">The concentration maximum.</param>
        /// <param name="concentrationUnit">The concentration unit.</param>
        /// <returns><c>true</c> if configured, <c>false</c> otherwise.</returns>
        bool Run(string calculationBase, string sensor, string densityCalibration, string temperaturMin, string temperaturMax, string temperaturUnit, string densityMin, string densityMax, string densityUnit, string concentrationMin, string concentrationMax, string concentrationUnit);


        #endregion
    }
}