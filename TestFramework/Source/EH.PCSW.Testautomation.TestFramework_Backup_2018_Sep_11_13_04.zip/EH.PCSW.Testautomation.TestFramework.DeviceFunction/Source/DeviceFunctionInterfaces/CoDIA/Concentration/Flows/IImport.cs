﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IImport.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IImport.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IImport.
    /// </summary>
    public interface IImport
    {
        #region Public Methods and Operators

        /// <summary>
        /// Imports Concentration data with default name from report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Imports Concentration data
        /// </summary>
        /// <param name="filename">
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run(string filename);

        #endregion
    }
}