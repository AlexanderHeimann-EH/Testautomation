﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckExpertResults.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The CheckExpertResults interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    /// The CheckExpertResults interface.
    /// </summary>
    public interface ICheckExpertResults
    {
        #region Public Methods and Operators

        /// <summary>
        /// Selects each result from the combo box and takes a screenshot of the diagram
        /// </summary>
        /// <returns><c>true</c> if execution was successful, <c>false</c> otherwise.</returns>
        bool SelectEachResultAndTakeScreenshot();

        #endregion
    }
}