﻿/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:25 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IHelp.
    /// </summary>
    public interface IHelp
    {
    }
}