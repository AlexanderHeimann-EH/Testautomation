﻿namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Functions.ApplicationArea.MainView.Validation

{
    using Ranorex;
    using Ranorex.Core;

    /// <summary>
    ///     Interface for IsModuleReady
    /// </summary>
    public interface IIsModuleReady
    {
        /// <summary>
        ///     Checks if module (online) is ready
        /// </summary>
        /// <param name="button">Button to check</param>
        /// <returns>
        ///     <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool IsModuleOfflineReady(Button button);

        /// <summary>
        ///     Checks if module (offline) is ready
        /// </summary>
        /// <returns>
        ///     <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool IsModuleOfflineReady(Element element);

        /// <summary>
        ///     Checks if module (online) is ready
        /// </summary>
        /// <returns>
        ///     <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool IsModuleOnlineReady(Adapter adapter);


        // 2013-06-28 EC - Added in addition to function above
        /// <summary>
        ///     Checks if module (online) is ready
        /// </summary>
        /// <returns>
        ///     <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool IsModuleOnlineReady(Button button);

        /// <summary>
        ///     Checks if module (offline) is ready
        /// </summary>
        /// <param name="element">Element to check</param>
        /// <returns>
        ///     <br>True: if module is ready</br>
        ///     <br>False: if module is not ready</br>
        /// </returns>
        bool IsModuleOnlineReady(Element element);
    }
}