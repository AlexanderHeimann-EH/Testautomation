﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IModuleOpeningAndClosing.cs" company="E+H PCPS AG">
//   E+H PCPS AG
// </copyright>
// <summary>
//   Interface for ModuleOpeningAndClosing
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Interface for ModuleOpeningAndClosing
    /// </summary>
    public interface IModuleOpeningAndClosing
    {
        /// <summary>
        /// Validates that a module is already open or not (brings module to foreground if it is already open)
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool IsModuleAlreadyOpened();

        /// <summary>
        /// Validates that a module is closed
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool IsModuleClosed();

        /// <summary>
        /// Validates that a module is open
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool IsModuleOpened();

        /// <summary>
        /// Validation if module is closed within a specified time
        /// </summary>
        /// <param name="timeOutInMilliseconds">
        /// Time within module must be closed
        /// </param>
        /// <returns>
        /// <br>True: if module is closed</br>
        ///     <br>False: if module is not closed</br>
        /// </returns>
        bool WaitUntilModuleIsClosed(int timeOutInMilliseconds);

        /// <summary>
        /// Validation if module is opened within a specified time
        /// </summary>
        /// <param name="timeOutInMilliseconds">
        /// Time within module should be opened
        /// </param>
        /// <returns>
        /// <br>True: if module is opened in time</br>
        ///     <br>False: if module is not opened in time</br>
        /// </returns>
        bool WaitUntilModuleIsOpen(int timeOutInMilliseconds);
    }
}