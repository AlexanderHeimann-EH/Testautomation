﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckAvailabilityOfTabPages.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   The CheckAvailabilityOfTabPages interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// The CheckAvailabilityOfTabPages interface.
    /// </summary>
    public interface ICheckAvailabilityOfTabPages
    {
        #region Public Methods and Operators

        /// <summary>
        /// Determines whether base settings tab page is available.
        /// </summary>
        /// <returns><c>true</c> if base settings tab page is available; otherwise, <c>false</c>.</returns>
        bool IsBaseSettingsTabPageAvailable();

        /// <summary>
        /// Determines whether coefficient overview tab page is available.
        /// </summary>
        /// <returns><c>true</c> if coefficient overview tab page is available; otherwise, <c>false</c>.</returns>
        bool IsCoefficientOverviewTabPageAvailable();

        /// <summary>
        /// Determines whether expert results tab page is available.
        /// </summary>
        /// <returns><c>true</c> if expert results tab page is available; otherwise, <c>false</c>.</returns>
        bool IsExpertResultsTabPageAvailable();

        /// <summary>
        /// Determines whether liquid properties tab page is available.
        /// </summary>
        /// <returns><c>true</c> if liquid properties tab page is available; otherwise, <c>false</c>.</returns>
        bool IsLiquidPropertiesTabPageAvailable();

        #endregion
    }
}