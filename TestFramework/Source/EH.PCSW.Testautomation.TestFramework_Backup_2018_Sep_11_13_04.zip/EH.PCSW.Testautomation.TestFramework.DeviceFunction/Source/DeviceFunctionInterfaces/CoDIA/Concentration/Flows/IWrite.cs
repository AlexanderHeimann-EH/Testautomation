﻿//------------------------------------------------------------------------------
// <copyright file="IWrite.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/2/2013
 * Time: 2:26 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Flows
{
    /// <summary>
    ///     Description of IWrite.
    /// </summary>
    public interface IWrite
    {
        /// <summary>
        ///     writes coefficients to device, waits until "write finished" user notification message is displayed and write button is enabled again
        /// </summary>
        /// <returns>
        ///     true: if coefficients were written
        ///     false: if an error occurred
        /// </returns>
        bool Run();
    }
}