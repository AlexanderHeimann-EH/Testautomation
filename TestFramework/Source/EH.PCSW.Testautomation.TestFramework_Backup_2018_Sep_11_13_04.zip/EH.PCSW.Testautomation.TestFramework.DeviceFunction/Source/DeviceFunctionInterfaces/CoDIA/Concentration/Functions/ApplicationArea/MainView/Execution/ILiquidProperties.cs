﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ILiquidProperties.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides methods for tab liquid properties within module concentration
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Concentration.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides methods for tab liquid properties within module concentration
    /// </summary>
    public interface ILiquidProperties
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the input format.
        /// </summary>
        /// <value>The input format.</value>
        string InputFormat { get; set; }

        /// <summary>
        /// Gets or sets the spreadsheet.
        /// </summary>
        /// <value>The spreadsheet.</value>
        string Spreadsheet { get; set; }

        /// <summary>
        /// Gets or sets the value1.
        /// </summary>
        /// <value>The value1.</value>
        string Value1 { get; set; }

        /// <summary>
        /// Gets or sets the value1 maximum.
        /// </summary>
        /// <value>The value1 maximum.</value>
        string Value1Max { get; set; }

        /// <summary>
        /// Gets or sets the value1 minimum.
        /// </summary>
        /// <value>The value1 minimum.</value>
        string Value1Min { get; set; }

        /// <summary>
        /// Gets or sets the value1 unit.
        /// </summary>
        /// <value>The value1 unit.</value>
        string Value1Unit { get; set; }

        /// <summary>
        /// Gets or sets the value2.
        /// </summary>
        /// <value>The value2.</value>
        string Value2 { get; set; }

        /// <summary>
        /// Gets or sets the value2 maximum.
        /// </summary>
        /// <value>The value2 maximum.</value>
        string Value2Max { get; set; }

        /// <summary>
        /// Gets or sets the value2 minimum.
        /// </summary>
        /// <value>The value2 minimum.</value>
        string Value2Min { get; set; }

        /// <summary>
        /// Gets or sets the value2 unit.
        /// </summary>
        /// <value>The value2 unit.</value>
        string Value2Unit { get; set; }

        /// <summary>
        /// Gets or sets the value3.
        /// </summary>
        /// <value>The value3.</value>
        string Value3 { get; set; }

        /// <summary>
        /// Gets or sets the value3 maximum.
        /// </summary>
        /// <value>The value3 maximum.</value>
        string Value3Max { get; set; }

        /// <summary>
        /// Gets or sets the value3 minimum.
        /// </summary>
        /// <value>The value3 minimum.</value>
        string Value3Min { get; set; }

        /// <summary>
        /// Gets or sets the value3 unit.
        /// </summary>
        /// <value>The value3 unit.</value>
        string Value3Unit { get; set; }

        #endregion

        #region Public Methods and Operators

        /// <summary>
        ///     Fills list with random numbers between 0-100
        /// </summary>
        void FillList();

        #endregion
    }
}