﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRead.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IRead.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of IRead.
    /// </summary>
    public interface IRead
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Reads coefficients from device, waits until "read finished" user notification message is displayed and read icon is enabled again
        /// </summary>
        /// <returns>
        ///     true: if coefficients were read
        ///     false: if an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}