﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckAvailabilityOfTabPages.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The CheckAvailabilityOfTabPages interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// The CheckAvailabilityOfTabPages interface.
    /// </summary>
    public interface ICheckAvailabilityOfTabPages
    {
        #region Public Methods and Operators

        /// <summary>
        /// Determines whether base settings tab page is available.
        /// </summary>
        /// <returns><c>true</c> if base settings tab page is available; otherwise, <c>false</c>.</returns>
        bool IsBaseSettingsTabPageAvailable();

        /// <summary>
        /// Determines whether coefficient overview tab page is available.
        /// </summary>
        /// <returns><c>true</c> if coefficient overview tab page is available; otherwise, <c>false</c>.</returns>
        bool IsCoefficientOverviewTabPageAvailable();

        /// <summary>
        /// Determines whether expert results tab page is available.
        /// </summary>
        /// <returns><c>true</c> if expert results tab page is available; otherwise, <c>false</c>.</returns>
        bool IsExpertResultsTabPageAvailable();

        /// <summary>
        /// Determines whether liquid properties tab page is available.
        /// </summary>
        /// <returns><c>true</c> if liquid properties tab page is available; otherwise, <c>false</c>.</returns>
        bool IsLiquidPropertiesTabPageAvailable();

        /// <summary>
        /// Determines whether [is reference values tab page available].
        /// </summary>
        /// <returns><c>true</c> if [is reference values tab page available]; otherwise, <c>false</c>.</returns>
        bool IsReferenceValuesTabPageAvailable();

        #endregion
    }
}