﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IWrite.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IWrite.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of IWrite.
    /// </summary>
    public interface IWrite
    {
        #region Public Methods and Operators

        /// <summary>
        ///     writes coefficients to device, waits until "write finished" user notification message is displayed and write button is enabled again
        /// </summary>
        /// <returns>
        ///     true: if coefficients were written
        ///     false: if an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}