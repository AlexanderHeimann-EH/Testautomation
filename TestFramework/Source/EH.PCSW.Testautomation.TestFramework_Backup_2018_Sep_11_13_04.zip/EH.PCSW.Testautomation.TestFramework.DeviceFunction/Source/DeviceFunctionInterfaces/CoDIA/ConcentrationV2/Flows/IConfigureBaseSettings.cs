﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureBaseSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of IConfigureBaseSettings.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of IConfigureBaseSettings.
    /// </summary>
    public interface IConfigureBaseSettings
    {
        #region Public Methods and Operators

        /// <summary>
        /// Averages the pressure.
        /// </summary>
        /// <param name="averageProcessPressure">
        /// The average process pressure.
        /// </param>
        /// <param name="averageProcessPressureUnit">
        /// The average process pressure unit.
        /// </param>
        /// <returns>
        /// <c>true</c> if configured correctly, <c>false</c> otherwise.
        /// </returns>
        bool AveragePressure(string averageProcessPressure, string averageProcessPressureUnit);

        /// <summary>
        /// Bases the configuration.
        /// </summary>
        /// <param name="calculationBase">The calculation base.</param>
        /// <param name="liquidType">Type of the liquid.</param>
        /// <param name="userProfile">The user profile.</param>
        /// <param name="referenceTemperature">The reference temperature.</param>
        /// <param name="mineralContent">Content of the mineral.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool BaseConfiguration(string calculationBase, string liquidType, string userProfile, string referenceTemperature, string mineralContent);

        /// <summary>
        /// Configures operating range
        /// </summary>
        /// <param name="temperatureMinimum">
        /// The temperature minimum.
        /// </param>
        /// <param name="temperatureMaximum">
        /// The temperature maximum.
        /// </param>
        /// <param name="concentrationMinimum">
        /// The concentration minimum.
        /// </param>
        /// <param name="concentrationMaximum">
        /// The concentration maximum.
        /// </param>
        /// <param name="temperatureUnit">
        /// The temperature unit.
        /// </param>
        /// <param name="concentrationUnit">
        /// The concentration unit.
        /// </param>
        /// <returns>
        /// <c>true</c> if configured correctly, <c>false</c> otherwise.
        /// </returns>
        bool OperatingRange(string temperatureMinimum, string temperatureMaximum, string concentrationMinimum, string concentrationMaximum, string temperatureUnit, string concentrationUnit);

        #endregion
    }
}