﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IContainer.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides methods to select different tabs within module concentration
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides methods to select different tabs within module concentration
    /// </summary>
    public interface IContainer
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Select tab base settings
        /// </summary>
        /// <returns>
        ///     <br>True: if selection worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool SelectTabBaseSettings();

        /// <summary>
        ///     Select tab coefficients overview
        /// </summary>
        /// <returns>
        ///     <br>True: if selection worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool SelectTabCoefficientsOverview();

        /// <summary>
        ///     Select tab expert results
        /// </summary>
        /// <returns>
        ///     <br>True: if selection worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool SelectTabExpertResults();

        /// <summary>
        ///     Select tab liquid properties
        /// </summary>
        /// <returns>
        ///     <br>True: if selection worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool SelectTabLiquidProperties();

        /// <summary>
        /// Selects the tab reference values.
        /// </summary>
        /// <returns><c>true</c> if tab selected, <c>false</c> otherwise.</returns>
        bool SelectTabReferenceValues();

        #endregion
    }
}