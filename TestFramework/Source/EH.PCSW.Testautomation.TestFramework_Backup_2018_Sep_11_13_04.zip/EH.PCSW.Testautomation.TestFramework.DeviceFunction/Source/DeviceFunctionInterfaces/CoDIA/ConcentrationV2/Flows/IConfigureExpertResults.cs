﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IConfigureExpertResults.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ConfigureExpertResults interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    /// The ConfigureExpertResults interface.
    /// </summary>
    public interface IConfigureExpertResults
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs the specified density calibration.
        /// </summary>
        /// <param name="densityCalibration">
        /// The density calibration.
        /// </param>
        /// <param name="sensor">
        /// The sensor.
        /// </param>
        /// <param name="fieldDensityAdjustment">
        /// The field density adjustment.
        /// </param>
        /// <param name="diagramSelection">
        /// The diagram selection.
        /// </param>
        /// <returns>
        /// <c>true</c> if configured, <c>false</c> otherwise.
        /// </returns>
        bool Run(string densityCalibration, string sensor, string fieldDensityAdjustment, string diagramSelection);

        #endregion
    }
}