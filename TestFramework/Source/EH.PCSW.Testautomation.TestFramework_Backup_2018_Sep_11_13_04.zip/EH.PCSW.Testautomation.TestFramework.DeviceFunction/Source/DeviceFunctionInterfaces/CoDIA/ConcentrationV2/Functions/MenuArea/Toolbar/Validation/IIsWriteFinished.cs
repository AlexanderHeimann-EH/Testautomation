﻿/*
 * Created by Ranorex
 * User: testadmin
 * Date: 7/9/2013
 * Time: 3:00 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.MenuArea.Toolbar.Validation
{
    /// <summary>
    ///     Description of IsWriteFinished.
    /// </summary>
    public interface IIsWriteFinished
    {
        /// <summary>
        ///     Checks if writing coefficients to the device is finished
        /// </summary>
        /// <returns>
        ///     true: if write button is enabled and user notification message is shown
        ///     false: if either write button is not enabled or message is not shown
        /// </returns>
        bool Run();
    }
}