﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISave.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of ISave.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of ISave.
    /// </summary>
    public interface ISave
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Saves current Viscosity data via Save button
        /// </summary>
        /// <returns>
        ///     true: if call worked fine
        ///     false: if an error occurred
        /// </returns>
        bool Run();

        #endregion
    }
}