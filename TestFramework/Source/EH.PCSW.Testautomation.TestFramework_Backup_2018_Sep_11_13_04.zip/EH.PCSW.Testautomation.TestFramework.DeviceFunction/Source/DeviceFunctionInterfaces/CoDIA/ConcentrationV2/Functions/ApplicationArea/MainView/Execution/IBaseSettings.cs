﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IBaseSettings.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides interfaces tab base settings within module concentration
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides interfaces tab base settings within module concentration
    /// </summary>
    public interface IBaseSettings
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the average process pressure.
        /// </summary>
        /// <value>The average process pressure.</value>
        string AverageProcessPressure { get; set; }

        /// <summary>
        /// Gets or sets the average process pressure unit.
        /// </summary>
        /// <value>The average process pressure unit.</value>
        string AverageProcessPressureUnit { get; set; }

        /// <summary>
        /// Gets or sets the calculation base.
        /// </summary>
        string CalculationBase { get; set; }

        /// <summary>
        /// Gets or sets the concentration max.
        /// </summary>
        string ConcentrationMax { get; set; }

        /// <summary>
        /// Gets or sets the concentration min.
        /// </summary>
        string ConcentrationMin { get; set; }

        /// <summary>
        /// Gets or sets the concentration unit.
        /// </summary>
        string ConcentrationUnit { get; set; }

        /// <summary>
        /// Gets or sets the density calibration.
        /// </summary>
        string DensityCalibration { get; set; }

        /// <summary>
        /// Gets or sets the field density adjustment.
        /// </summary>
        /// <value>
        /// The field density adjustment.
        /// </value>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string FieldDensityAdjustment { get; set; }

        /// <summary>
        /// Gets or sets the liquid type.
        /// </summary>
        string LiquidType { get; set; }

        /// <summary>
        /// Gets or sets the content of the mineral.
        /// </summary>
        /// <value>The content of the mineral.</value>
        string MineralContent { get; set; }

        /// <summary>
        /// Gets or sets the reference temperature.
        /// </summary>
        /// <value>The reference temperature.</value>
        string ReferenceTemperature { get; set; }

        /// <summary>
        /// Gets or sets the sensor.
        /// </summary>
        string Sensor { get; set; }

        /// <summary>
        /// Gets or sets the temperature max.
        /// </summary>
        string TemperatureMax { get; set; }

        /// <summary>
        /// Gets or sets the temperature min.
        /// </summary>
        string TemperatureMin { get; set; }

        /// <summary>
        /// Gets or sets the temperature unit.
        /// </summary>
        string TemperatureUnit { get; set; }

        /// <summary>
        /// Gets or sets the user profile.
        /// </summary>
        /// <value>The user profile.</value>
        string UserProfile { get; set; }

        #endregion
    }
}