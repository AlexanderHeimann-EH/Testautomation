﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IGetValuesFromTable.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The GetValuesFromTable interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    using System.Collections.Generic;

    /// <summary>
    /// The GetValuesFromTable interface.
    /// </summary>
    public interface IGetValuesFromTable
    {
        #region Public Methods and Operators

        /// <summary>
        /// Gets all values from Concentration table within Liquid properties and stores them in a list. This will only work if you selected List as input form.
        /// </summary>
        /// <returns>List with all table values.</returns>
        List<string> AllValues();

        /// <summary>
        /// Prints table values in report.
        /// </summary>
        void PrintAllValuesInReport();

        /// <summary>
        /// Returns the value for a specified row and column
        /// </summary>
        /// <param name="row">
        /// The row.
        /// </param>
        /// <param name="column">
        /// The column.
        /// </param>
        /// <returns>
        /// The value for the row and column.
        /// </returns>
        string SingleValue(int row, int column);

        #endregion
    }
}