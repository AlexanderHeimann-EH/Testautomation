﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICoefficientsOverview.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides methods for tab coefficients overview within module concentration
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides methods for tab coefficients overview within module concentration
    /// </summary>
    public interface ICoefficientsOverview
    {
        /// <summary>
        /// Gets or sets the calculated a 0.
        /// </summary>
        string CalculatedA0 { get; set; }

        /// <summary>
        /// Gets or sets the calculated a 1.
        /// </summary>
        string CalculatedA1 { get; set; }

        /// <summary>
        /// Gets or sets the calculated a 2.
        /// </summary>
        string CalculatedA2 { get; set; }

        /// <summary>
        /// Gets or sets the calculated a 3.
        /// </summary>
        string CalculatedA3 { get; set; }

        /// <summary>
        /// Gets or sets the calculated a 4.
        /// </summary>
        string CalculatedA4 { get; set; }

        /// <summary>
        /// Gets or sets the calculated b 1.
        /// </summary>
        string CalculatedB1 { get; set; }

        /// <summary>
        /// Gets or sets the calculated b 2.
        /// </summary>
        string CalculatedB2 { get; set; }

        /// <summary>
        /// Gets or sets the calculated b 3.
        /// </summary>
        string CalculatedB3 { get; set; }

        /// <summary>
        /// Gets or sets the calculated d1.
        /// </summary>
        /// <value>The calculated d1.</value>
        string CalculatedD1 { get; set; }

        /// <summary>
        /// Gets or sets the calculated d2.
        /// </summary>
        /// <value>The calculated d2.</value>
        string CalculatedD2 { get; set; }

        /// <summary>
        /// Gets or sets the calculated d3.
        /// </summary>
        /// <value>The calculated d3.</value>
        string CalculatedD3 { get; set; }

        /// <summary>
        /// Gets or sets the calculated d4.
        /// </summary>
        /// <value>The calculated d4.</value>
        string CalculatedD4 { get; set; }

        /// <summary>
        /// Gets or sets the from device a 0.
        /// </summary>
        string FromDeviceA0 { get; set; }

        /// <summary>
        /// Gets or sets the from device a 1.
        /// </summary>
        string FromDeviceA1 { get; set; }

        /// <summary>
        /// Gets or sets the from device a 2.
        /// </summary>
        string FromDeviceA2 { get; set; }

        /// <summary>
        /// Gets or sets the from device a 3.
        /// </summary>
        string FromDeviceA3 { get; set; }

        /// <summary>
        /// Gets or sets the from device a 4.
        /// </summary>
        string FromDeviceA4 { get; set; }

        /// <summary>
        /// Gets or sets the from device b 1.
        /// </summary>
        string FromDeviceB1 { get; set; }

        /// <summary>
        /// Gets or sets the from device b 2.
        /// </summary>
        string FromDeviceB2 { get; set; }

        /// <summary>
        /// Gets or sets the from device b 3.
        /// </summary>
        string FromDeviceB3 { get; set; }

        /// <summary>
        /// Gets or sets the from device D1.
        /// </summary>
        string FromDeviceD1 { get; set; }

        /// <summary>
        /// Gets or sets the from device D2.
        /// </summary>
        string FromDeviceD2 { get; set; }

        /// <summary>
        /// Gets or sets the from device D3.
        /// </summary>
        string FromDeviceD3 { get; set; }

        /// <summary>
        /// Gets or sets the from device D4.
        /// </summary>
        string FromDeviceD4 { get; set; }

        /// <summary>
        ///     Checks whether calculated Coefficients are available or not
        /// </summary>
        /// <returns>
        ///     true: if at least one value is not empty
        ///     false: if all values are empty
        /// </returns>
        bool AreCalculatedCoefficientsAvailable();

        /// <summary>
        ///     Checks whether Coefficients are available or not
        /// </summary>
        /// <returns>
        ///     true: if at least one coefficient is not "0"
        ///     false: if all values are "0"
        /// </returns>
        bool AreCoefficientsAvailable();

        /// <summary>
        ///     Checks whether Coefficients read from device are available or not
        /// </summary>
        /// <returns>
        ///     true: if at least one value is not empty
        ///     false: if all values are empty
        /// </returns>
        bool AreReadCoefficientsAvailable();

        /// <summary>
        /// Compares all calculated coefficients against the coefficients read from device
        /// </summary>
        /// <param name="accuracy">
        /// maximum difference between two coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficients(string accuracy);

        /// <summary>
        /// Compares all calculated coefficients against the coefficients read from device
        /// </summary>
        /// <param name="accuracy">
        /// maximum difference between two coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficients(double accuracy);

        /// <summary>
        /// Compares all calculated coefficients against user given coefficients
        /// </summary>
        /// <param name="accuracy">
        /// maximum allowed difference between two coefficients
        /// </param>
        /// <param name="expectedCoefficients">
        /// string[] with user given coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficients(string accuracy, string[] expectedCoefficients);

        /// <summary>
        /// Compares all calculated coefficients against user given coefficients
        /// </summary>
        /// <param name="accuracy">
        /// maximum allowed difference between two coefficients
        /// </param>
        /// <param name="expectedCoefficients">
        /// string[] with user given coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficients(double accuracy, string[] expectedCoefficients);

        /// <summary>
        /// Compares all coefficients from device against user given coefficients
        /// </summary>
        /// <param name="accuracy">
        /// maximum allowed difference between two coefficients
        /// </param>
        /// <param name="expectedCoefficients">
        /// string[] with user given coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficientsFromDevice(string accuracy, string[] expectedCoefficients);

        /// <summary>
        /// Compares all coefficients from device against user given coefficients
        /// </summary>
        /// <param name="accuracy">
        /// maximum allowed difference between two coefficients
        /// </param>
        /// <param name="expectedCoefficients">
        /// string[] with user given coefficients
        /// </param>
        /// <returns>
        /// <br>true: if all coefficients are identical</br>
        ///     <br>false: if one paring is not identical</br>
        /// </returns>
        bool CompareCoefficientsFromDevice(double accuracy, string[] expectedCoefficients);
    }
}