﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="INew.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of INew.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.ConcentrationV2.Flows
{
    /// <summary>
    ///     Description of INew.
    /// </summary>
    public interface INew
    {
        #region Public Methods and Operators

        /// <summary>
        /// Clears Concentration data via New button, checks whether coefficients in coefficients overview are empty
        /// </summary>
        /// <returns>true: if Concentration data is cleared; false: if an error occurred</returns>
        bool Run();

        #endregion
    }
}