﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ILoadDataset1.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface for flow Load Dataset 1
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Flows
{
    /// <summary>
    ///     Interface for flow Load Dataset 1
    /// </summary>
    public interface ILoadDataset1
    {
        #region Public Methods and Operators

        /// <summary>
        /// Flow: Load default file from report folder
        /// </summary>
        /// <returns>
        /// <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>s>
        bool Run();

        /// <summary>
        /// Start flow
        /// </summary>
        /// <param name="fileName">
        /// Dataset to load
        /// </param>
        /// <returns>
        /// <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run(string fileName);

        #endregion
    }
}