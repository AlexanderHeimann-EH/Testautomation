﻿//------------------------------------------------------------------------------
// <copyright file="Action.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Zander, Jan
 * Date: 23.07.2012
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Provides interfaces for action area at module Compare
    /// </summary>
    public interface IAction
    {
        /// <summary>
        ///     Starts comparing by clicking related button
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool StartCompare();

        /// <summary>
        ///     Cancels comparing by clicking related button
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool CancelCompare();
    }
}