﻿//------------------------------------------------------------------------------
// <copyright file="IComparisonProgress.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 10/14/2013
 * Time: 3:07 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Provides interface for checking comparison progress
    /// </summary>
    public interface IComparisonProgress
    {
        /// <summary>
        ///     Wait until compare is finished within a speficied time
        /// </summary>
        /// <param name="timeOutInMilliseconds">Time within action must be finished</param>
        /// <returns>
        ///     <br>True: if comparison is finished in time</br>
        ///     <br>False: if comparison is not finished in time</br>
        /// </returns>
        bool WaitUntilCompareFinished(int timeOutInMilliseconds);

        /// <summary>
        ///     Checks if comparison is finished
        /// </summary>
        /// <returns>
        ///     <br>True: if comparison is finished</br>
        ///     <br>False: if comparison is not finished</br>
        /// </returns>
        bool IsComparing();
    }
}