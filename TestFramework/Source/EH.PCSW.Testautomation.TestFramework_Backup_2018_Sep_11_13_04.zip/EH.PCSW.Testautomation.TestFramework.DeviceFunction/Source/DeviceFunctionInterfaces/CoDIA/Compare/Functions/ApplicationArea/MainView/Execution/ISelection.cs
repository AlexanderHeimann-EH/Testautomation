﻿//------------------------------------------------------------------------------
// <copyright file="ISelection.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Zander, Jan
 * Date: 23.07.2012
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.ApplicationArea.MainView.Execution
{
    using System.Collections.Generic;

    using Ranorex;

    /// <summary>
    ///     Provides interfaces for action area at module Compare
    /// </summary>
    public interface ISelection
    {
        /// <summary>
        ///     Get list of listitems after compare
        /// </summary>
        IList<ListItem> Entries();

        /// <summary>
        ///     Open mode selection
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool OpenSelectMode();

        /// <summary>
        ///     Flow: Select compare mode
        /// </summary>
        /// <param name="index">Entry to select, starting with 0</param>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool SelectMode(int index);

        /// <summary>
        ///     Select Mode via text, returns true when mode is set
        /// </summary>
        /// <param name="mode">Entry to select</param>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool SelectMode(string mode);

        /// <summary>
        ///     Open file browser for dataset 1
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Dataset1();

        /// <summary>
        ///     Open file browser for dataset 2
        /// </summary>
        /// <returns>
        ///     <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Dataset2();
    }
}