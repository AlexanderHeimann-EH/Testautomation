﻿namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    ///     Interface for WaitUntilDTMIsConnected
    /// </summary>
    public interface IWaitUntilDTMIsConnected
    {
        /// <summary>
        ///     Wait until DTM connection is established and shown by GUI
        /// </summary>
        /// <param name="timeOutInMilliseconds">Time until action must be performed</param>
        /// <returns>
        ///     <br>True: if module is connected</br>
        ///     <br>False: if module is not connected</br>
        /// </returns>
        bool Run(int timeOutInMilliseconds);
    }
}