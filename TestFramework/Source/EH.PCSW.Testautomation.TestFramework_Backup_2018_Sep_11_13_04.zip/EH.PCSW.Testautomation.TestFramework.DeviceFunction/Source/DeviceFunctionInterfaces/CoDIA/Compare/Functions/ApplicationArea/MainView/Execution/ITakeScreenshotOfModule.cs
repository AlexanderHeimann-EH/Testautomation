﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ITakeScreenshotOfModule.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   The TakeScreenshotOfModule interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The TakeScreenshotOfModule interface.
    /// </summary>
    public interface ITakeScreenshotOfModule
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs this instance.
        /// </summary>
        void Run();

        #endregion
    }
}