﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICancelCompare.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   Starts compare, then cancels it after a specified time
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Flows
{

    /// <summary>
    /// Interface ICancelCompare
    /// </summary>
    public interface ICancelCompare
    {
        #region Public Methods and Operators

        /// <summary>
        /// Starts compare, then cancels it after a specified time
        /// </summary>
        /// <param name="timeToWaitUntilCancelInMilliseconds">
        /// The time to wait until the comparison is canceled in milliseconds.
        /// </param>
        /// <returns>
        /// <c>true</c> if compare is canceled successfully, <c>false</c> otherwise.
        /// </returns>
        bool Run(int timeToWaitUntilCancelInMilliseconds);

        #endregion
    }
}