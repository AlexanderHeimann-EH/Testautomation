﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICheckCompareResult.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>
//   The CheckCompareResult interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.Compare.Flows
{
    using System.Collections.Generic;

    /// <summary>
    /// The CheckCompareResult interface.
    /// </summary>
    public interface ICheckCompareResult
    {
        #region Public Methods and Operators

        /// <summary>
        /// Checks whether the offline and online value of a parameter are identical.
        /// </summary>
        /// <param name="parameterNames">
        /// List with the name(s) of the parameter which will be checked. E.g. Full calibration (4), Empty calibration (3), Device tag.
        /// </param>
        /// <returns>
        /// <c>true</c> if the offline and online values of all parameter are identical, <c>false</c> otherwise.
        /// </returns>
        bool CheckThatOfflineAndOnlineParameterAreEqual(List<string> parameterNames);

        /// <summary>
        /// Checks whether the offline and online value of a parameter are not equal.
        /// </summary>
        /// <param name="parameterNames">
        /// List with the name(s) of the parameter which will be checked. E.g. Full calibration (4), Empty calibration (3), Device tag.
        /// </param>
        /// <returns>
        /// <c>true</c> if the offline and online values of all parameter from the list are not identical, <c>false</c> otherwise.
        /// </returns>
        bool CheckThatOfflineAndOnlineParameterAreNotEqual(List<string> parameterNames);

        /// <summary>
        /// Navigates through the Compare result and logs all parameter with different offline and online values. Result is shown in the report.
        /// </summary>
        bool LogAllParameterWithDifferentOfflineAndOnlineValues();

        /// <summary>
        /// Navigates through the Compare result and logs all parameter with identical offline and online values. Result is shown in the report.
        /// </summary>
        bool LogAllParameterWithIdenticalOfflineAndOnlineValues();

        /// <summary>
        /// Navigates through the Compare result and logs all parameter with offline and online values. Result is shown in the report.
        /// </summary>
        bool LogAllParameterWithOfflineAndOnlineValues();

        #endregion
    }
}