﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRead.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The Read interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Flows
{
    /// <summary>
    /// The Read interface.
    /// </summary>
    public interface IRead
    {
        #region Public Methods and Operators

        /// <summary>
        /// Writes to device
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout In Milliseconds.
        /// </param>
        /// <returns>
        /// true: if reading finished successfully; false: if an error occurred
        /// </returns>
        bool Run(int timeoutInMilliseconds);

        #endregion
    }
}