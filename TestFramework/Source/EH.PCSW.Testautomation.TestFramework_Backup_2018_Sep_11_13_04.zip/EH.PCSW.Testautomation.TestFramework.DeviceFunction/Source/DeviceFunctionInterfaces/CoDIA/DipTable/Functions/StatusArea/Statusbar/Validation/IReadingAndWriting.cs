﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IReadingAndWriting.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ReadingAndWriting interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    /// The ReadingAndWriting interface.
    /// </summary>
    public interface IReadingAndWriting
    {
        #region Public Methods and Operators

        /// <summary>
        /// Validates whether reading from device started
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds.
        /// </param>
        /// <returns>
        /// True: if progress bar(buttonOperationInProgress) is != null
        /// </returns>
        bool HasReadingStarted(int timeoutInMilliseconds);

        /// <summary>
        /// Validates whether writing from device started
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds.
        /// </param>
        /// <returns>
        /// True: if progress bar(buttonOperationInProgress) is != null
        /// </returns>
        bool HasWritingStarted(int timeoutInMilliseconds);

        /// <summary>
        /// Determines whether [read button is active].
        /// </summary>
        /// <returns><c>true</c> if [read button is active]; otherwise, <c>false</c>.</returns>
        bool IsReadButtonActive();

        /// <summary>
        /// Determines whether reading is active
        /// </summary>
        /// <returns>
        /// True: if reading is active. False: otherwise
        /// </returns>
        bool IsReading();

        /// <summary>
        /// Determines whether [write button is active].
        /// </summary>
        /// <returns><c>true</c> if [write button is active]; otherwise, <c>false</c>.</returns>
        bool IsWriteButtonActive();

        /// <summary>
        /// Determines whether reading or writing is active
        /// </summary>
        /// <returns>
        /// True: if reading is active. False: otherwise
        /// </returns>
        bool IsWriting();

        /// <summary>
        /// Waits the until read button and write button are active.
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds.
        /// </param>
        /// <returns>
        /// <c>true</c> if read button and write button are active, <c>false</c> otherwise.
        /// </returns>
        bool WaitUntilReadButtonAndWriteButtonAreActive(int timeoutInMilliseconds);

        /// <summary>
        /// Waits until reading finished
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds.
        /// </param>
        /// <returns>
        /// True: if reading is finished; False: otherwise
        /// </returns>
        bool WaitUntilReadingIsFinished(int timeoutInMilliseconds);

        /// <summary>
        /// Waits until writing is finished
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout in milliseconds.
        /// </param>
        /// <returns>
        /// True: if reading or writing is finished; False: otherwise
        /// </returns>
        bool WaitUntilWritingIsFinished(int timeoutInMilliseconds);

        #endregion
    }
}