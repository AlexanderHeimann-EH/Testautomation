﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClickOnUndoZoom.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ClickOnUndoZoom interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    /// The ClickOnUndoZoom interface.
    /// </summary>
    public interface IClickOnUndoZoom
    {
        #region Public Methods and Operators

        /// <summary>
        /// Mouse click on the button undo zoom
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run();

        #endregion
    }
}