﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IWaitUntilDtmIsDisconnected.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface for WaitUntilDtmIsDisconnected
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    /// Interface for WaitUntilDtmIsDisconnected
    /// </summary>
    public interface IWaitUntilDtmIsDisconnected
    {
        #region Public Methods and Operators

        /// <summary>
        /// Wait until DTM connection is established and shown by GUI
        /// </summary>
        /// ///
        /// <param name="timeOutInMilliseconds">
        /// Time until action must be performed
        /// </param>
        /// <returns>
        /// <br>True: if module is disconnected</br>
        ///     <br>False: if module is not disconnected</br>
        /// </returns>
        bool Run(int timeOutInMilliseconds);

        #endregion
    }
}