﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ITakeScreenshotOfModule.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The TakeScreenshotOfModule interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The TakeScreenshotOfModule interface.
    /// </summary>
    public interface ITakeScreenshotOfModule
    {
        #region Public Methods and Operators

        /// <summary>
        /// Runs this instance.
        /// </summary>
        void Run();

        #endregion
    }
}