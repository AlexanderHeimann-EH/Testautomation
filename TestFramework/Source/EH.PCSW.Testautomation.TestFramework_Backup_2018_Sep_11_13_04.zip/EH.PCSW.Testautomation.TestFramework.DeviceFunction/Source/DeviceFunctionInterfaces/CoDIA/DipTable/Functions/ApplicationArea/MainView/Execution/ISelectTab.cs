﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISelectTab.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The SelectTab interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The SelectTab interface.
    /// </summary>
    public interface ISelectTab
    {
        #region Public Methods and Operators

        /// <summary>
        /// Select a tab with specified tabindex
        /// </summary>
        /// <param name="index">
        /// Tabindex to select
        /// </param>
        /// <returns>
        /// <br>True: if selection worked </br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run(int index);

        #endregion
    }
}