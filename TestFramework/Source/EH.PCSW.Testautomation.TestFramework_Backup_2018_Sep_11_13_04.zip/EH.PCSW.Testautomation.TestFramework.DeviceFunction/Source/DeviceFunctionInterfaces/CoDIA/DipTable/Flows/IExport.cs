﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IExport.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The Export interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Flows
{
    /// <summary>
    /// The Export interface.
    /// </summary>
    public interface IExport
    {
        #region Public Methods and Operators

        /// <summary>
        /// Export Linearization data with default file name to report folder
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Exports the a Linearization file.
        /// </summary>
        /// <param name="fileName">
        /// Name and path of the file. E.g. C:\Test\testData 
        /// </param>
        /// <returns>
        /// <c>true</c> if XXXX, <c>false</c> otherwise.
        /// </returns>
        bool Run(string fileName);

        #endregion
    }
}