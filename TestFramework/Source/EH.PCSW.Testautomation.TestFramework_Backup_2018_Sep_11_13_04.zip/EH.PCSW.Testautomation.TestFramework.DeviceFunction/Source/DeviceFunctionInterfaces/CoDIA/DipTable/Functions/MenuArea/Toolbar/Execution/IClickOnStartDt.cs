﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClickOnStartDt.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   The ClickOnStartDT interface.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.DipTable.Functions.MenuArea.Toolbar.Execution
{
    /// <summary>
    /// The ClickOnStartDT interface.
    /// </summary>
    public interface IClickOnStartDt
    {
        #region Public Methods and Operators

        /// <summary>
        /// Mouse click on the button StartDT.
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        bool Run();

        #endregion
    }
}