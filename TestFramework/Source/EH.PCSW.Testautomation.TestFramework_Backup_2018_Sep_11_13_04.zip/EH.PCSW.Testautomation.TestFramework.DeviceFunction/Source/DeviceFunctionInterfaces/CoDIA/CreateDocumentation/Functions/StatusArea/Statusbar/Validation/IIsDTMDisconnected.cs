﻿//------------------------------------------------------------------------------
// <copyright file="IIsDtmDisconnected.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 11/11/2013
 * Time: 11:22 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Functions.StatusArea.Statusbar.Validation
{
    /// <summary>
    ///     Description of IIsDtmDisconnected.
    /// </summary>
    public interface IIsDTMDisconnected
    {
        /// <summary>
        ///     Determines whether dtm is offline
        /// </summary>
        /// <returns>
        ///     true: if DTM is offline
        ///     false: if DTM is online or an error occurred
        /// </returns>
        bool Run();
    }
}