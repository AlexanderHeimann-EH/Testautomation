﻿//------------------------------------------------------------------------------
// <copyright file="IWaitUntilPrintingIsFinished.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: testadmin
 * Date: 10/17/2013
 * Time: 8:41 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    ///     Description of IWaitUntilPrintingIsFinished.
    /// </summary>
    public interface IWaitUntilPrintingIsFinished
    {
        /// <summary>
        ///     Provides validation function for module Create Documentation
        /// </summary>
        /// <returns>
        ///     <br>True: if prinint finished</br>
        ///     <br>False: if printing is not finished</br>
        /// </returns>
        bool IsPrintingFinished();

        /// <summary>
        ///     Waits until printing is finished
        /// </summary>
        /// <param name="timeOutInMilliseconds">time within action must be finished</param>
        /// <returns>
        ///     <br>True: if printing is finished in time</br>
        ///     <br>False: if printing is not finished in time</br>
        /// </returns>
        bool Run(int timeOutInMilliseconds);
    }
}