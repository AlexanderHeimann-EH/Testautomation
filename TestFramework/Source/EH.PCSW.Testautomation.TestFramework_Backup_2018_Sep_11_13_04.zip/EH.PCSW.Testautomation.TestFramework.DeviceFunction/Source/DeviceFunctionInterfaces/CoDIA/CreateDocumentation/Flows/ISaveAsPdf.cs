﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ISaveAsPdf.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Interface ISaveAsPdf
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Flows
{
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// Interface ISaveAsPdf
    /// </summary>
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "Reviewed. Suppression is OK here.")]
    public interface ISaveAsPdf
    {
        #region Public Methods and Operators

        /// <summary>
        /// Flow: Save file as PDF via file browser with default timeout
        /// </summary>        
        /// <returns>
        /// true: if file is saved; false: if an error occurred
        /// </returns>
        bool Run();

        /// <summary>
        /// Flow: Save file as PDF via file browser with default timeout
        /// </summary>
        /// <param name="fileName">
        /// Filename to save printout as
        /// </param>
        /// <returns>
        /// <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Run(string fileName);

        /// <summary>
        /// Flow: Save file as PDF via file browser with specialized timeout
        /// </summary>
        /// <param name="fileName">
        /// Filename to save printout as
        /// </param>
        /// <param name="waitUntilFinished">
        /// Control if should be waited until module is opened or not
        /// </param>
        /// <param name="timeOutInMilliseconds">
        /// Time until printout has to be generated at last
        /// </param>
        /// <returns>
        /// <br>True: If call worked fine</br>
        ///     <br>False: If an error occurred</br>
        /// </returns>
        bool Run(string fileName, bool waitUntilFinished, int timeOutInMilliseconds);

        #endregion
    }
}