﻿//------------------------------------------------------------------------------
// <copyright file="IPrinterAndProgress.cs" company="Endress+Hauser Process Solutions AG">
//     Copyright (c) Endress+Hauser Process Solutions AG. All rights reserved.
// </copyright>
// <summary>Description of file.</summary>
//------------------------------------------------------------------------------

/*
 * Created by Ranorex
 * User: Effner Christian
 * Date: 03.10.2012
 * Time: 10:57 
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    ///     Interface for area Printer And Progress
    /// </summary>
    public interface IPrinterAndProgress
    {
        /// <summary>
        ///     Get main progress state
        /// </summary>
        /// <returns>
        ///     <br>String: if call worked fine</br>
        ///     <br>Empty string: if an error occurred</br>
        /// </returns>
        string GetMainProgressBarState();

        /// <summary>
        ///     Get sub progress state
        /// </summary>
        /// <returns>
        ///     <br>String: if call worked fine</br>
        ///     <br>Empty string: if an error occurred</br>
        /// </returns>
        string GetSubProgressBarState();
    }
}