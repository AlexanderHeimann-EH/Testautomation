﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IOpenModuleOnline.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Provides methods for flow IOpenModuleOnline.cs
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.CreateDocumentation.Flows
{
    /// <summary>
    ///     Provides methods for flow IOpenModuleOnline.cs
    /// </summary>
    public interface IOpenModuleOnline
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Methods to Open module
        /// </summary>
        /// <returns>
        ///     <br>True: if call worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run();

        /// <summary>
        /// Open module via frame menu within a default time
        /// </summary>
        /// <param name="timeoutInMilliseconds">
        /// The timeout In Milliseconds for the module opening.
        /// </param>
        /// <returns>
        /// <br>True: if everything worked fine</br>
        ///     <br>False: if an error occurred</br>
        /// </returns>
        bool Run(int timeoutInMilliseconds);

        #endregion
    }
}