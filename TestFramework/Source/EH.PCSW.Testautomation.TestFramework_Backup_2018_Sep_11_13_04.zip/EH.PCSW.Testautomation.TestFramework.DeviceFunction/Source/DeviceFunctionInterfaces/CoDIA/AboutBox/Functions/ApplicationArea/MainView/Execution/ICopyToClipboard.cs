﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ICopyToClipboard.cs" company="E+H Process Solutions AG">
//  E+H Process Solutions AG 
// </copyright>
// <summary>
//   Defines the ICopyToClipboard type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The CopyToClipboard interface.
    /// </summary>
    public interface ICopyToClipboard
    {
        /// <summary>
        /// Starts execution
        /// </summary>
        /// <returns>
        /// true if button is found and clicked, false if an error occurred
        /// </returns>
        bool Run();
    }
}