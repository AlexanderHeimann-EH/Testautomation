﻿// -----------------------------------------------------------------------
// <copyright file="IIsDeviceTypeNameCorrect.cs" company="Endress+Hauser Process Solutions AG">
// E+H PCPS AG
// </copyright>
// -----------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Validation
{
    /// <summary>
    /// The IsDeviceTypeNameCorrect interface.
    /// </summary>
    public interface IIsDeviceTypeNameCorrect
    {
        /// <summary>
        /// Checks whether a device type name matches the pattern [x]x.[x]x.[x]x.xxxx 
        /// </summary>
        /// <param name="deviceTypeName">
        /// The device type name
        /// </param>
        /// <returns>
        /// True: if setup version matches pattern; False: otherwise
        /// </returns>
        bool Run(string deviceTypeName);
    }
}