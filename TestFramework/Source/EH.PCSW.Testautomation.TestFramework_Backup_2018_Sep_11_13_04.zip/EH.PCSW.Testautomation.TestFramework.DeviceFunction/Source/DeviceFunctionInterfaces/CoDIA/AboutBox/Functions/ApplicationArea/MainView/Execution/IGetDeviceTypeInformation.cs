﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IGetDeviceTypeInformation.cs" company="Endress+Hauer Process Solutions AG">
//  Endress+Hauer Process Solutions AG 
// </copyright>
// <summary>
//   Defines the IGetDeviceTypeInformation type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Functions.ApplicationArea.MainView.Execution
{
    /// <summary>
    /// The GetDeviceTypeInformation interface.
    /// </summary>
    public interface IGetDeviceTypeInformation
    {
        /// <summary>
        /// Device Type Information -> Name
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Name();

        /// <summary>
        /// Device Type Information -> Version
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Version();

        /// <summary>
        /// Device Type Information -> Date
        /// </summary>
        /// <returns>
        /// The <see cref="string"/>.
        /// </returns>
        string Date();
    }
}