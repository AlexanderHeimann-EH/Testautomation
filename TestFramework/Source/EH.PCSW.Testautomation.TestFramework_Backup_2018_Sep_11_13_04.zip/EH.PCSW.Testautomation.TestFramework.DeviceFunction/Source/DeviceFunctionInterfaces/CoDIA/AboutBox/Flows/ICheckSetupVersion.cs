﻿// -----------------------------------------------------------------------
// <copyright file="ICheckSetupVersion.cs" company="Endress+Hauser Process Solutions AG">
// E+H PCPS AG
// </copyright>
// -----------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Flows
{
    /// <summary>
    /// The CheckSetupVersion interface.
    /// </summary>
    public interface ICheckSetupVersion
    {
        /// <summary>
        /// Gets the setup version from the setup information box and checks if it is valid.
        /// </summary>
        /// <returns>
        /// True: if the setup version is valid; False: if otherwise
        /// </returns>
        bool Run();
    }
}