﻿// -----------------------------------------------------------------------
// <copyright file="ICheckDeviceTypeName.cs" company="Endress+Hauser Process Solutions AG">
// E+H PCPS AG
// </copyright>
// -----------------------------------------------------------------------
namespace EH.PCPS.TestAutomation.DeviceFunctionInterfaces.CoDIA.AboutBox.Flows
{
    /// <summary>
    /// The CheckDeviceTypeName interface.
    /// </summary>
    public interface ICheckDeviceTypeName
    {
        /// <summary>
        /// Gets the device type name from the device type information box and checks if it is valid.
        /// </summary>
        /// <returns>
        /// True: if the device type name is valid; False: if otherwise
        /// </returns>
        bool Run();
    }
}