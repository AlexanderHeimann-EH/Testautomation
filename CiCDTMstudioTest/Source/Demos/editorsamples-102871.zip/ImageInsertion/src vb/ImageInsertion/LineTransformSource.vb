﻿Imports System.Text
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Text.Formatting

Namespace Microsoft.VisualStudio.ImageInsertion
	Friend Class LineTransformSource
		Implements ILineTransformSource
		Private Const ImageAdornmentSpacePadding = 20

		Private manager As ImageAdornmentManager

		Public Sub New(ByVal manager As ImageAdornmentManager)
			Me.manager = manager
		End Sub

		Private Function GetLineTransform(ByVal line As ITextViewLine, ByVal yPosition As Double, ByVal placement As ViewRelativePosition) As LineTransform Implements ILineTransformSource.GetLineTransform
			Dim targetImages = Me.manager.Images.Where(Function(imageAdornment) imageAdornment.ApplyRenderTrackingPoint(Me.manager.View.TextSnapshot, line))

			If targetImages.Count() > 0 Then
				Dim imageAdornmentWithMaxHeight = targetImages.OrderByDescending(Function(imageAdornment) imageAdornment.VisualElement.Height).FirstOrDefault()

				Return New LineTransform(imageAdornmentWithMaxHeight.VisualElement.Height + ImageAdornmentSpacePadding, 0, 1.0)
			End If

			Return New LineTransform(0, 0, 1.0)
		End Function
	End Class
End Namespace
