Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Controls.Primitives
Imports System.Windows.Documents
Imports System.Windows.Navigation
Imports System.Windows.Shapes
Imports System.Windows.Data
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Input
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.ImageInsertion

    Partial Public Class EditorImage
        Inherits UserControl
        ''' <summary>
        ''' The event is raised when the image is deleted by the user
        ''' </summary>
        Friend Event Deleted As EventHandler

        ''' <summary>
        ''' The event is raised when the image is being resized
        ''' </summary>
        Friend Event Resizing As EventHandler

        ''' <summary>
        ''' Gets or sets if the image is being moved
        ''' </summary>
        Friend Property IsMoving As Boolean

        ''' <summary>
        ''' Gets true if the image is selected
        ''' </summary>
        <System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")>
        Friend Property IsSelected As Boolean

        ''' <summary>
        ''' Gets true if the image is being resized
        ''' </summary>
        Friend Property IsResizing As Boolean

        Friend Sub New(ByVal imageSource As ImageSource)
            InitializeComponent()
            Me.Image.Source = imageSource
            canvasStretch.Width = Me.Image.Source.Width
            canvasStretch.Height = Me.Image.Source.Height
        End Sub

        ''' <summary>
        ''' See <see cref="UIElement"/>
        ''' </summary>
        ''' <param name="e"></param>
        Protected Overrides Sub OnMouseEnter(ByVal e As MouseEventArgs)
            MyBase.OnMouseEnter(e)
            Mouse.OverrideCursor = Cursors.Arrow
            Me.IsSelected = True
            Me.CloseButtonGrid.Visibility = Visibility.Visible
            Me.verticalResizeThumb.Visibility = Me.CloseButtonGrid.Visibility
            Me.horizontalResizeThumb.Visibility = Me.verticalResizeThumb.Visibility
            Me.horizontalAndVerticalResizeThumb.Visibility = Me.horizontalResizeThumb.Visibility
        End Sub

        ''' <summary>
        ''' See <see cref="UIElement"/>
        ''' </summary>
        ''' <param name="e"></param>
        Protected Overrides Sub OnMouseLeave(ByVal e As MouseEventArgs)
            MyBase.OnMouseLeave(e)
            Mouse.OverrideCursor = Nothing
            Me.IsSelected = False
            Me.CloseButtonGrid.Visibility = Visibility.Hidden
            Me.verticalResizeThumb.Visibility = Me.CloseButtonGrid.Visibility
            Me.horizontalResizeThumb.Visibility = Me.verticalResizeThumb.Visibility
            Me.horizontalAndVerticalResizeThumb.Visibility = Me.horizontalResizeThumb.Visibility
        End Sub

        Friend ReadOnly Property Image As Image
            Get
                Return Me._image
            End Get
        End Property

        Private Sub AdjustVerticalChange(ByVal sender As Object, ByVal e As DragDeltaEventArgs)
            Dim heightAdjust = canvasStretch.Height + e.VerticalChange
            If heightAdjust >= canvasStretch.MinHeight Then
                canvasStretch.Height = heightAdjust
            End If
            OnResizing(New EventArgs)
        End Sub

        Private Sub AdjustHorizontalChange(ByVal sender As Object, ByVal e As DragDeltaEventArgs)
            Dim widthAdjust = canvasStretch.Width + e.HorizontalChange
            If widthAdjust >= canvasStretch.MinWidth Then
                canvasStretch.Width = widthAdjust
            End If
            OnResizing(New EventArgs)
        End Sub

        Private Sub AdjustHorizontalAndVerticalChange(ByVal sender As Object, ByVal e As DragDeltaEventArgs)
            AdjustHorizontalChange(sender, e)
            AdjustVerticalChange(sender, e)
        End Sub

        Private Sub OnResizing(ByVal e As EventArgs)
            RaiseEvent Resizing(Me, e)
        End Sub

        Private Sub ResizeThumb_MouseEnter(ByVal sender As Object, ByVal e As MouseEventArgs)
            IsResizing = True
            Dim element = TryCast(sender, FrameworkElement)
            Mouse.OverrideCursor = element.Cursor
        End Sub

        Private Sub ResizeThumb_MouseLeave(ByVal sender As Object, ByVal e As MouseEventArgs)
            IsResizing = False
            Mouse.OverrideCursor = Cursors.Arrow
        End Sub

        Private Sub CloseButton_MouseLeftButtonUp(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
            OnDeleted(New EventArgs)
        End Sub

        Private Sub OnDeleted(ByVal e As EventArgs)
            RaiseEvent Deleted(Me, e)
        End Sub

        Friend Property Top As Double
            Get
                Return Canvas.GetTop(Me)
            End Get
            Set(ByVal value As Double)
                Canvas.SetTop(Me, value)
            End Set
        End Property

        Friend Property Left As Double
            Get
                Return Canvas.GetLeft(Me)
            End Get
            Set(ByVal value As Double)
                Canvas.SetLeft(Me, value)
            End Set
        End Property

        Friend ReadOnly Property Area As Rect
            Get
                Return New Rect(Me.Left, Me.Top, Me.Width, Me.Height)
            End Get
        End Property

        ''' <summary>
        ''' Moves the element to the target x,y location
        ''' </summary>
        ''' <param name="x"></param>
        ''' <param name="y"></param>
        Friend Sub MoveTo(ByVal x As Double, ByVal y As Double)
            Me.Left = x
            Me.Top = y
        End Sub

        ''' <summary>
        ''' Moves the element to the target point.
        ''' </summary>
        ''' <param name="targetPoint">The target point</param>
        Friend Sub MoveTo(ByVal targetPoint As Point)
            Me.MoveTo(targetPoint.X, targetPoint.Y)
        End Sub
    End Class
End Namespace