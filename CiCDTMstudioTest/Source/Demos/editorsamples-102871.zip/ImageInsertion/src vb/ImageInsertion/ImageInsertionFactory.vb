﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Text.Formatting
Imports Microsoft.VisualStudio.Shell


Namespace Microsoft.VisualStudio.ImageInsertion
	''' <summary>
	''' Creates and initializes an instance of <see cref="ImageAdornmentManager"/> when view is created.
	''' </summary>
	<Export(GetType(ILineTransformSourceProvider)), _
	Export(GetType(IWpfTextViewCreationListener)), _
	ContentType("CSharp"), _
	ContentType("Basic"), _
	TextViewRole(PredefinedTextViewRoles.Document)>
	Friend Class ImageInsertionFactory
		Implements ILineTransformSourceProvider, IWpfTextViewCreationListener

		<Import()>
		Private Property EditorFormatMapService As IEditorFormatMapService

        <Import(GetType(SVsServiceProvider))>
        Private Property ServiceProvider As IServiceProvider

		Private Function Create(ByVal view As IWpfTextView) As ILineTransformSource Implements ILineTransformSourceProvider.Create
			Return New LineTransformSource(GetOrCreateManager(view))
		End Function

		Public Sub TextViewCreated(ByVal textView As IWpfTextView) Implements IWpfTextViewCreationListener.TextViewCreated
			Me.GetOrCreateManager(textView)
		End Sub

		Private Function GetOrCreateManager(ByVal view As IWpfTextView) As ImageAdornmentManager
			Return view.Properties.GetOrCreateSingletonProperty(Of ImageAdornmentManager)(Function() New ImageAdornmentManager(Me.ServiceProvider, view, Me.EditorFormatMapService.GetEditorFormatMap(view)))
		End Function
	End Class
End Namespace