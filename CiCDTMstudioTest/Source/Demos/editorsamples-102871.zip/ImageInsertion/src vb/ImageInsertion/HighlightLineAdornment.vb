﻿Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Media
Imports System.Windows.Shapes
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Text.Formatting

Namespace Microsoft.VisualStudio.ImageInsertion
	''' <summary>
	''' Provides a visual element that highlights a text line in the editor.
	''' </summary>
	Friend Class HighlightLineAdornment
        Private mVisualElement As Rectangle
        Private editorFormatMap As IEditorFormatMap
        Private ReadOnly DefaultBackgroundColor As Color = Color.FromRgb(51, 153, 255)
        Private backgroundColor As Color

        Friend Sub New(ByVal view As IWpfTextView, ByVal editorFormatMap As IEditorFormatMap)
            Me.View = view
            Me.editorFormatMap = editorFormatMap

            CreateVisualElement()
        End Sub

        Private Sub CreateVisualElement()
            UpdateBackgroundColor()

            mVisualElement = New Rectangle
            Dim fillBrush As New LinearGradientBrush(Color.FromArgb(&H60, backgroundColor.R, backgroundColor.G, backgroundColor.B), Color.FromArgb(&H60, backgroundColor.R, backgroundColor.G, backgroundColor.B), 90)

            fillBrush.GradientStops.Add(New GradientStop(Color.FromArgb(&H30, backgroundColor.R, backgroundColor.G, backgroundColor.B), 0.5))
            mVisualElement.Fill = fillBrush

            mVisualElement.Stroke = New SolidColorBrush(Color.FromRgb(51, 153, 255))
            mVisualElement.StrokeThickness = 2
            mVisualElement.Opacity = 0.3
            mVisualElement.RadiusY = 2
            mVisualElement.RadiusX = mVisualElement.RadiusY
            mVisualElement.Visibility = Visibility.Hidden
        End Sub

        Private Sub UpdateBackgroundColor()
            ' Use the editor format map to get the configured background color of VS for selected text
            Dim properties = Me.editorFormatMap.GetProperties("Selected Text")
            If properties IsNot Nothing AndAlso properties.Contains("BackgroundColor") Then
                Me.backgroundColor = CType(properties("BackgroundColor"), Color)
            Else
                ' use the default one
                Me.backgroundColor = DefaultBackgroundColor
            End If
        End Sub

        ''' <summary>
        ''' Gets the visual representation of the adornment.
        ''' </summary>
        Friend ReadOnly Property VisualElement As UIElement
            Get
                Return Me.mVisualElement
            End Get
        End Property

        ''' <summary>
        ''' Gets the view where the adornment is being shown
        ''' </summary>
        Friend Property View As IWpfTextView

        ''' <summary>
        ''' Highlighs the text line
        ''' </summary>
        ''' <param name="textLine">The text line</param>
        Friend Sub Highlight(ByVal textLine As ITextViewLine)
            If textLine IsNot Nothing Then
                Me.mVisualElement.Visibility = Visibility.Visible
                ' Set the position of the visual element
                Me.mVisualElement.Height = textLine.Height
                Me.mVisualElement.Width = Me.View.ViewportWidth
                Canvas.SetLeft(Me.mVisualElement, Me.View.ViewportLeft)
                Canvas.SetTop(Me.mVisualElement, textLine.Top + textLine.LineTransform.TopSpace)
            Else
                Me.Clear()
            End If
        End Sub

        Friend Sub Clear()
            Me.VisualElement.Visibility = Visibility.Hidden
        End Sub
	End Class
End Namespace