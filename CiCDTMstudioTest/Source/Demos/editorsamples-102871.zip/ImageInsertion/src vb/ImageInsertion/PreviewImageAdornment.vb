﻿Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Media.Imaging

Namespace Microsoft.VisualStudio.ImageInsertion
	''' <summary>
	''' Provides a visual element that shows a preview image in the editor.
	''' </summary>
	Friend Class PreviewImageAdornment
        Friend Const PreviewOpacity = 0.5

        Friend Property VisualElement As Image

		Friend Sub New()
			CreateVisualElement()
		End Sub

		Private Sub CreateVisualElement()
            Me.VisualElement = New Image
			Me.VisualElement.Stretch = System.Windows.Media.Stretch.None
			Me.VisualElement.Opacity = PreviewOpacity
			Me.VisualElement.Visibility = Visibility.Hidden
		End Sub

		''' <summary>
		''' Shows the preview of the image in the editor
		''' </summary>
		''' <param name="imageFilename"></param>
		<System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000")>
		Friend Sub Show(ByVal imageFilename As String)
			VisualElement.Source = BitmapFrame.Create(New Uri(imageFilename, UriKind.RelativeOrAbsolute))
			VisualElement.Visibility = Visibility.Visible
			VisualElement.Tag = New System.Drawing.Bitmap(imageFilename)
		End Sub

		Friend Sub Clear()
			VisualElement.Source = Nothing
			VisualElement.Visibility = Visibility.Hidden
			VisualElement.Tag = Nothing
		End Sub

		''' <summary>
		''' Moves the preview image to the target point
		''' </summary>
		''' <param name="targetPoint"></param>
		Friend Sub MoveTo(ByVal targetPoint As Point)
			If Me.VisualElement IsNot Nothing Then
				Canvas.SetLeft(VisualElement, targetPoint.X - (VisualElement.Source.Width / 2))
				Canvas.SetTop(VisualElement, targetPoint.Y - (VisualElement.Source.Height / 2))
			End If
		End Sub
	End Class
End Namespace