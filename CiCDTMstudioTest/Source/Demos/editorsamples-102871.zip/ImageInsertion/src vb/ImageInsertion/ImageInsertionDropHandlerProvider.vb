﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Text.Editor.DragDrop
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.ImageInsertion
	<Export(GetType(IDropHandlerProvider)), DropFormat(ImageInsertionDropHandlerProvider.FileDropDataFormat), DropFormat(ImageInsertionDropHandlerProvider.VSProjectItemDataFormat), Name("Image Insertion Drop Handler"), Order(Before := "DefaultFileDropHandler")>
	Friend Class ImageInsertionDropHandlerProvider
		Implements IDropHandlerProvider
        Friend Const VSProjectItemDataFormat = "CF_VSSTGPROJECTITEMS"
        Friend Const FileDropDataFormat = "FileDrop"

        Public Function GetAssociatedDropHandler(ByVal view As IWpfTextView) As IDropHandler Implements IDropHandlerProvider.GetAssociatedDropHandler
            Dim imagesManager = view.Properties.GetProperty(Of ImageAdornmentManager)(GetType(ImageAdornmentManager))

            Return view.Properties.GetOrCreateSingletonProperty(Of ImageInsertionDropHandler)(Function() New ImageInsertionDropHandler(imagesManager))
        End Function
	End Class
End Namespace