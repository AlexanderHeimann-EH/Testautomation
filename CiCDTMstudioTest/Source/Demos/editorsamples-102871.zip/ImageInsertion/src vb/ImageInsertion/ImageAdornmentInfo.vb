﻿Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports Microsoft.VisualStudio.Text

Namespace Microsoft.VisualStudio.ImageInsertion
	''' <summary>
	''' Provides a simpler and serializable version of <see cref="ImageAdornment"/>
	''' </summary>
    <Serializable()>
    Public Class ImageAdornmentInfo
        ''' <summary>
        ''' Creates a new instance of <see cref="ImageAdornmentInfo"/> based on the image adornment.
        ''' </summary>
        ''' <param name="imageAdornment"></param>
        Friend Sub New(ByVal imageAdornment As ImageAdornment)
            Me.Id = imageAdornment.Id
            Me.TextViewLineDelta = imageAdornment.TextViewLineDelta
            Me.Span = imageAdornment.TrackingSpan.GetSpan(imageAdornment.TrackingSpan.TextBuffer.CurrentSnapshot).Span
            Me.Bitmap = TryCast(imageAdornment.VisualElement.Image.Tag, System.Drawing.Bitmap)

            Me.Area = New Rect(imageAdornment.VisualElement.Left, imageAdornment.VisualElement.Top, imageAdornment.VisualElement.Width, imageAdornment.VisualElement.Height)
        End Sub

        ''' <summary>
        ''' Gets or sets the left, top, width and height of the image adornment.
        ''' </summary>
        Public Property Area As Rect

        ''' <summary>
        ''' Gets or sets the difference between the location of the image and the associated span.
        ''' </summary>
        Public Property TextViewLineDelta As Point

        ''' <summary>
        ''' Gets or sets the start position of the span associated with the image.
        ''' </summary>
        Public Property SpanStartPosition As Integer

        ''' <summary>
        ''' Gets or sets the lenght of the span associated with the image.
        ''' </summary>
        Public Property SpanLength As Integer

        ''' <summary>
        ''' Gets the Span associated with the image
        ''' </summary>
        Friend Property Span As Span
            Get
                Return New Span(Me.SpanStartPosition, Me.SpanLength)
            End Get
            Private Set(ByVal value As Span)
                Me.SpanStartPosition = value.Start
                Me.SpanLength = value.Length
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the unique id of the image adornment
        ''' </summary>
        Public Property Id As String

        ''' <summary>
        ''' Gets or sets the image as a bitmap
        ''' </summary>
        Public Property Bitmap As System.Drawing.Bitmap
    End Class
End Namespace