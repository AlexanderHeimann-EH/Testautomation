﻿Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Navigation
Imports System.Windows.Shapes
Imports System.Windows.Controls.Primitives
Imports Microsoft.VisualStudio.Language.Intellisense
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.IntellisensePresenter
    Partial Public Class CompletionSessionView
        Inherits UserControl
        Private presenter As CompletionSessionPresenter

        Friend Sub New(ByVal presenter As CompletionSessionPresenter)
            InitializeComponent()

            Me.presenter = presenter

            SubscribeToEvents()
            Me.DataContext = presenter
        End Sub

        Private Sub SubscribeToEvents()
            AddHandler presenter.Session.Dismissed, AddressOf OnSessionDismissed
        End Sub

        Private Sub OnSessionDismissed(ByVal sender As Object, ByVal e As EventArgs)
            UnsubscribeFromEvents()
            SurrenderFocus()
        End Sub

        Private Sub UnsubscribeFromEvents()
            RemoveHandler presenter.Session.Dismissed, AddressOf OnSessionDismissed
        End Sub

        Private Sub SurrenderFocus()
            Dim view = TryCast(Me.presenter.Session.TextView, IWpfTextView)
            If view IsNot Nothing Then
                Keyboard.Focus(view.VisualElement)
            End If
        End Sub

        Private Sub ListView_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
            Me.presenter.SelectedCompletion = TryCast(Me.listViewCompletions.SelectedItem, Completion)
            Me.SurrenderFocus()
        End Sub

        Private Sub ListView_MouseDoubleClick(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
            Me.presenter.Commit()
        End Sub

        Friend Sub [Select](ByVal completion As Completion)
            Me.listViewCompletions.SelectedItem = completion
            If completion IsNot Nothing Then
                Me.listViewCompletions.ScrollIntoView(completion)
            End If
        End Sub

        Private Sub listViewCompletions_MouseLeftButtonDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
            Me.SurrenderFocus()
        End Sub

        Private Sub OnThumbDragDelta(ByVal sender As Object, ByVal e As System.Windows.Controls.Primitives.DragDeltaEventArgs)
            Dim heightAdjust = Me.Height + e.VerticalChange
            If heightAdjust >= Me.MinHeight Then
                Me.Height = heightAdjust
            End If

            Dim widthAdjust = Me.Width + e.HorizontalChange
            If widthAdjust >= Me.MinWidth Then
                Me.Width = widthAdjust
            End If
        End Sub

        Private Sub OnMsdnImageMouseDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
            presenter.Navigate("http://msdn.microsoft.com")
        End Sub
    End Class
End Namespace