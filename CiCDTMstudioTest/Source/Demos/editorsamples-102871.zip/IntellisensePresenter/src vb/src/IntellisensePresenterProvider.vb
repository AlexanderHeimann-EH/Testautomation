﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Shell

Namespace Microsoft.VisualStudio.IntellisensePresenter
	<Export(GetType(IIntellisensePresenterProvider)), ContentType("text"), Order(Before := "Default Completion Presenter"), Name("Custom Completion Presenter")>
	Friend Class IntellisensePresenterProvider
        Implements IIntellisensePresenterProvider

        <Import(GetType(SVsServiceProvider))>
        Private ServiceProvider As IServiceProvider

        Public Function TryCreateIntellisensePresenter(ByVal session As IIntellisenseSession) As IIntellisensePresenter Implements IIntellisensePresenterProvider.TryCreateIntellisensePresenter
			Dim completionSession = TryCast(session, ICompletionSession)
			If Not completionSession Is Nothing Then
				Return New CompletionSessionPresenter(Me.ServiceProvider, completionSession)
			End If

            Return Nothing
        End Function
	End Class
End Namespace