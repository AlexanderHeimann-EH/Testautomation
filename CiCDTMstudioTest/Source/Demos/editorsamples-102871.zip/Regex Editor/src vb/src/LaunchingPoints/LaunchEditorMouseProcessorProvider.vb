﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Adornments
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.LaunchingPoints
    <ContentType("code"), Export(GetType(IMouseProcessorProvider)), Name("Launch Editor MouseProcessor"), Order(Before:="default"), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend Class LaunchEditorMouseProcessorProvider
        Implements IMouseProcessorProvider

        <Import()>
        Private Property RegexEditorService As RegexEditorService

        <Import()>
        Private Property ToolTipProviderFactory As IToolTipProviderFactory

#Region "IMouseProcessorProvider Members"

        Public Function GetAssociatedProcessor(ByVal wpfTextView As IWpfTextView) As IMouseProcessor Implements IMouseProcessorProvider.GetAssociatedProcessor
            Return New LaunchEditorMouseProcessor(wpfTextView, RegexEditorService, ToolTipProviderFactory)
        End Function

#End Region

    End Class
End Namespace