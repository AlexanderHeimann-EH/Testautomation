﻿Imports System.Text
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Text.Formatting

Namespace Microsoft.VisualStudio.RegularExpression.LaunchingPoints
	''' <summary>
	''' Provides information about the current regex line.
	''' Tipically the line will be similar to: Regex regex = new Regex("pattern", options);
	''' </summary>
	Friend Class RegexLineData
        Private Const Quote = """"

		Private Sub New()
		End Sub

		''' <summary>
		''' Gets the regex snapshot line.
		''' </summary>
        Friend Property Line As ITextSnapshotLine

		''' <summary>
		''' Gets the text of the line.
		''' </summary>
        Friend ReadOnly Property Text As String
            Get
                Return Me.Line.GetText()
            End Get
        End Property

		''' <summary>
		''' Gets the view where the line is.
		''' </summary>
        Friend Property View As ITextView

		''' <summary>
		''' Gets the caret point at the time the line was created
		''' </summary>
        Friend Property CaretPoint As SnapshotPoint?

		''' <summary>
		''' Gets the caret position at the time the line was created
		''' </summary>
        Friend ReadOnly Property CaretPosition As Integer
            Get
                Return Me.CaretPoint.Value.Position
            End Get
        End Property

		''' <summary>
		''' Gets the snapshot for the regular expression parameter of the regex ctor.
		''' </summary>
        Friend ReadOnly Property Expression As SnapshotSpan?
            Get
                ' Get the position of the first quote
                Dim start = Me.Text.IndexOf(Quote)
                If start <> -1 Then
                    ' Get the position of the last quote
                    Dim [end] = Me.Text.LastIndexOf(Quote)

                    If [end] > start Then
                        Return New SnapshotSpan(Me.View.TextSnapshot, start + 1 + Me.Line.Start.Position, [end] - start - 1)
                    End If
                End If

                Return Nothing
            End Get
        End Property

		''' <summary>
		''' Creates the regex line for the current position in the view.
		''' </summary>
		''' <param name="view"></param>
		''' <returns></returns>
		Friend Shared Function CreateFromCaretPosition(ByVal view As IWpfTextView) As RegexLineData
            Dim data As New RegexLineData

			data.View = view

			data.CaretPoint = view.Caret.Position.Point.GetPoint(view.TextBuffer, PositionAffinity.Predecessor)

			data.Line = view.TextSnapshot.GetLineFromPosition(data.CaretPosition)

			Return data
		End Function

		''' <summary>
		''' Creates the regex line for the current position in the view.
		''' </summary>
		''' <param name="view"></param>
		''' <param name="line"></param>
		''' <returns></returns>
		Friend Shared Function CreateFromTextViewLine(ByVal view As ITextView, ByVal line As ITextViewLine) As RegexLineData
            Dim data As New RegexLineData

			data.View = view

            ' TODO: RC1
            'data.Line = line.SnapshotLine
            data.Line = line.Snapshot.GetLineFromPosition(line.Start.Position)

			Return data
		End Function
	End Class
End Namespace