﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.LaunchingPoints
    <ContentType("code"), Export(GetType(IKeyProcessorProvider)), Name("Launch Editor KeyProcessor"), Order(Before:="Regex Key Processor"), TextViewRole(PredefinedTextViewRoles.Document)>
 Friend NotInheritable Class LaunchEditorKeyProcessorProvider
        Implements IKeyProcessorProvider

        <Import()>
        Private Property RegexEditorService As RegexEditorService

#Region "IKeyProcessorProvider Members"

        Public Function GetAssociatedProcessor(ByVal wpfTextView As IWpfTextView) As KeyProcessor Implements IKeyProcessorProvider.GetAssociatedProcessor
            Return New LaunchEditorKeyProcessor(wpfTextView, RegexEditorService)
        End Function

#End Region

    End Class
End Namespace