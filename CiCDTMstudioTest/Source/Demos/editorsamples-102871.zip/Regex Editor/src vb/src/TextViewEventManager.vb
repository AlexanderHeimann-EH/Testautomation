﻿Imports System.Text
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.RegularExpression
	''' <summary>
	''' Allows to communicate different object that user an instance of <see cref="ITextView"/>
	''' </summary>
	Friend Class TextViewEventManager
		Public Sub New(ByVal textView As ITextView)
			Me.TextView = textView

		End Sub

        Friend Const Key = "TextViewEventManagerKey"

		Friend Event IntellisenseSessionStart As EventHandler
		Friend Event IntellisenseSessionEnd As EventHandler

        Public Property TextView As ITextView

		Friend Overridable Sub OnIntellisenseSessionStart(ByVal e As EventArgs)
			RaiseEvent IntellisenseSessionStart(Me, e)
		End Sub

		Friend Overridable Sub OnIntellisenseSessionEnd(ByVal e As EventArgs)
			RaiseEvent IntellisenseSessionEnd(Me, e)
		End Sub
	End Class
End Namespace
