﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders
	''' <summary>
	''' Provides the completions for the slash ('\') character.
	''' </summary>
	Friend Class SlashCompletions
		Inherits RegexCompletionProvider
		Friend Overrides Function GetCompletions(ByVal session As Microsoft.VisualStudio.Language.Intellisense.ICompletionSession) As List(Of Completion)
            Return New List(Of Completion) From {New RegexCompletion("\d : Digits", "\d", 0), New RegexCompletion("\D : Non-digit characters", "\D", 0), New RegexCompletion("\w : Letters", "\w", 0), New RegexCompletion("\W : Non-letter characters", "\W", 0), New RegexCompletion("\s : Spaces", "\s", 0), New RegexCompletion("\S : Non-space characters", "\S", 0), New RegexCompletion("\A : Start of string", "\A", 0), New RegexCompletion("\Z : End of string", "\Z", 0), New RegexCompletion("\B : Word boundary", "\B", 0), New RegexCompletion("\b : Non-word boundary", "\B", 0), New RegexCompletion("\t : Tab", "\t", 0), New RegexCompletion("\v : Vertical Tab", "\v", 0), New RegexCompletion("\r : Carriage return", "\r", 0), New RegexCompletion("\f : Form feed", "\f", 0), New RegexCompletion("\n : New line", "\n", 0)}
		End Function
	End Class
End Namespace
