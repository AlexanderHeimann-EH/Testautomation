﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Language.Intellisense
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense
    <Export(GetType(ICompletionSourceProvider)), Name("Regex Completion Source Provider"), Order(Before:="default"), ContentType(RegexContentType.ContentTypeName)>
    Friend Class RegexCompletionSourceProvider
        Implements ICompletionSourceProvider
#Region "ICompletionSourceProvider Members"

        Public Function TryCreateCompletionSource(ByVal textBuffer As ITextBuffer) As ICompletionSource Implements ICompletionSourceProvider.TryCreateCompletionSource
            Return New RegexCompletionSource
        End Function

#End Region
    End Class
End Namespace