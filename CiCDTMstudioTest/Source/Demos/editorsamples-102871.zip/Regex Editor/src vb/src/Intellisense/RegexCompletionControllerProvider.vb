﻿Imports System.Text
Imports System.ComponentModel
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Language.Intellisense
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense
    <Export(GetType(IIntellisenseControllerProvider)), Name("Regex Completion Controller"), Order(Before:="Default Completion Controller"), ContentType(RegexContentType.ContentTypeName)>
    Friend Class RegexCompletionControllerProvider
        Implements IIntellisenseControllerProvider

        <Import()>
        Private Property ClassificationTypeRegistry As IClassificationTypeRegistryService

        <Import()>
        Private Property CompletionBroker As ICompletionBroker

        Public Function TryCreateIntellisenseController(ByVal textView As ITextView, ByVal subjectBuffers As IList(Of ITextBuffer)) As IIntellisenseController Implements IIntellisenseControllerProvider.TryCreateIntellisenseController
            Return New RegexCompletionController(subjectBuffers, textView, Me.CompletionBroker)
        End Function

    End Class
End Namespace