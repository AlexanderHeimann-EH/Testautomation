﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders
	''' <summary>
	''' Provides the completions for the square bracket '[' character.
	''' </summary>
	Friend Class SquareBracketCompletions
		Inherits RegexCompletionProvider
		Friend Overrides Function GetCompletions(ByVal session As Microsoft.VisualStudio.Language.Intellisense.ICompletionSession) As List(Of Completion)
            Return New List(Of Completion) From {New RegexCompletion("[<chars>] : Group", "[]", 1), New RegexCompletion("[^<chars>] : Negated Group", "[^]", 1)}
		End Function
	End Class
End Namespace