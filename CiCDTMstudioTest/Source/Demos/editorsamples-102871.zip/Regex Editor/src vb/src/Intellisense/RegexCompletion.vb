﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense
    ''' <summary>
    ''' Customizes how the regex completion are shown.
    ''' </summary>
    Friend Class RegexCompletion
        Inherits Completion
        ''' <summary>
        ''' Defines a modifier for the final position where the caret will be after commiting the completion
        ''' </summary>
        Friend Property CommitPositionModifier As Integer

        Friend Sub New(ByVal displayText As String, ByVal insertionText As String, ByVal commitPositionModifier As Integer)
            MyBase.New(displayText)
            Me.InsertionText = insertionText
            Me.CommitPositionModifier = commitPositionModifier
            ' Add the icon to the completion
            MyBase.Properties.AddProperty(GetType(IconDescription), New IconDescription(StandardGlyphGroup.GlyphCSharpExpansion, StandardGlyphItem.GlyphItemPublic))
        End Sub
    End Class
End Namespace