﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders
	''' <summary>
	''' Provides the completions for the parenthesis '(' character.
	''' </summary>
	Friend Class ParenthesisCompletions
		Inherits RegexCompletionProvider
		Friend Overrides Function GetCompletions(ByVal session As Microsoft.VisualStudio.Language.Intellisense.ICompletionSession) As List(Of Completion)
            Return New List(Of Completion) From {New RegexCompletion("(<group>) : Capture group", "()", 1), New RegexCompletion("(<group>|<group>) : Choice", "(|)", 2), New RegexCompletion("(?<group>) : Named Capture", "(?<>)", 2), New RegexCompletion("(?:<group>) : Passive group", "(?:)", 1), New RegexCompletion("(?i:<group>) : Case insensitive group", "(?i:)", 1), New RegexCompletion("(?m:<group>) : Multiline group", "(?m:)", 1), New RegexCompletion("(?n:<group>) : Explicit capture group", "(?n:)", 1), New RegexCompletion("(?s:<group>) : Single line group", "(?s:)", 1), New RegexCompletion("(?x:<group>) : Allow whitespace in group", "(?x:)", 1), New RegexCompletion("(?-i:<group>) : Case sensitive group", "(?-i:)", 1), New RegexCompletion("(?-m:<group>) : Non-multiline group", "(?-m:)", 1), New RegexCompletion("(?-n:<group>) : Non-explicit capture group", "(?-n:)", 1), New RegexCompletion("(?-s:<group>) : Non-single line group", "(?-s:)", 1), New RegexCompletion("(?-x:<group>) : Disallow whitespace in group", "(?-x:)", 1)}
		End Function
	End Class
End Namespace
