﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders
	''' <summary>
	''' Provides the completions for the bracket '{' character.
	''' </summary>
	Friend Class BracketCompletions
		Inherits RegexCompletionProvider
		Friend Overrides Function GetCompletions(ByVal session As Microsoft.VisualStudio.Language.Intellisense.ICompletionSession) As List(Of Completion)
            Return New List(Of Completion) From {New RegexCompletion("{N} : Exactly N", "{}", 1), New RegexCompletion("{N,M} : From N to M", "{,}", 2)}
		End Function
	End Class
End Namespace
