﻿Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders
	''' <summary>
	''' Provides a list of completions.
	''' </summary>
	Friend MustInherit Class RegexCompletionProvider
        Friend Shared CompletionProviderSessionKey As String = "completionProvider"

		''' <summary>
		''' Returns a list of completions.
		''' </summary>
		''' <param name="session">The completion session.</param>
		''' <returns>A list of completions.</returns>
		Friend MustOverride Function GetCompletions(ByVal session As ICompletionSession) As List(Of Completion)
	End Class
End Namespace
