﻿Imports System.Collections.ObjectModel
Imports System.Text
Imports Microsoft.VisualStudio.Language.Intellisense
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Text.Classification
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.RegularExpression.Intellisense.CompletionProviders

Namespace Microsoft.VisualStudio.RegularExpression.Intellisense
    ''' <summary>
    ''' Implementation of <see cref="ICompletionSource"/>. Provides the completion sets for the regex editor. 
    ''' </summary>
    Friend Class RegexCompletionSource
        Implements ICompletionSource

        Friend Shared CompletionSetName As String = "Regex"

        Friend Sub New()
        End Sub

        Public Sub AugmentCompletionSession(ByVal session As Language.Intellisense.ICompletionSession, ByVal completionSets As System.Collections.Generic.IList(Of Language.Intellisense.CompletionSet)) Implements Language.Intellisense.ICompletionSource.AugmentCompletionSession
            Dim triggerPointPosition = session.GetTriggerPoint(session.TextView.TextBuffer).GetPosition(session.TextView.TextSnapshot)
            Dim trackingSpan = session.TextView.TextSnapshot.CreateTrackingSpan(triggerPointPosition, 0, SpanTrackingMode.EdgeInclusive)

            Dim completionProvider = TryCast(session.Properties(RegexCompletionProvider.CompletionProviderSessionKey), RegexCompletionProvider)

            If completionProvider IsNot Nothing Then
                REM TODO: RC1 Investigate what the moniker parameter is
                completionSets.Add(New CompletionSet("regex", CompletionSetName, trackingSpan, completionProvider.GetCompletions(session), Nothing))
            End If

        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose

        End Sub
    End Class
End Namespace