﻿Imports System.Text
Imports Microsoft.VisualStudio.Text

Namespace Microsoft.VisualStudio.RegularExpression.Parser
	''' <summary>
	''' Executes the parsing when the text buffer changes.
	''' </summary>
	Friend NotInheritable Class ParserRunner
        Private WithEvents textBuffer As ITextBuffer

        Friend Property Parser As Parser

		Friend Sub New(ByVal textBuffer As ITextBuffer)
			Me.textBuffer = textBuffer
            Me.Parser = New Parser

            Parse()
		End Sub

        Private Sub TextBuffer_Changed() Handles textBuffer.Changed
            Parse()
        End Sub

		Private Sub Parse()
			Me.Parser.Parse(textBuffer.CurrentSnapshot.GetText())
		End Sub
	End Class
End Namespace