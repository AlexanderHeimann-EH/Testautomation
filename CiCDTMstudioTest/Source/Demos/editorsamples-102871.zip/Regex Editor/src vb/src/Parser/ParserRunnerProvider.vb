﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.Parser
    ''' <summary>
    ''' Saves an intance of <see cref="ParserRunner"/> in the properties of the text buffer when the text view is created.
    ''' </summary>
    <Export(GetType(IWpfTextViewCreationListener)), ContentType(RegexContentType.ContentTypeName), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class ParserRunnerProvider
        Implements IWpfTextViewCreationListener

        Public Sub TextViewCreated(ByVal textView As Text.Editor.IWpfTextView) Implements Text.Editor.IWpfTextViewCreationListener.TextViewCreated
            textView.TextBuffer.Properties.GetOrCreateSingletonProperty(Of ParserRunner)(Function() New ParserRunner(textView.TextBuffer))
        End Sub
    End Class
End Namespace