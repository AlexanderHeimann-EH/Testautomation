﻿Imports System.Text

Namespace Microsoft.VisualStudio.RegularExpression.Parser
	''' <summary>
	''' King of tokens
	''' </summary>
	Friend Enum TokenKind
		CharGroup
		Repetition
		EscapedExpression
		Expression
		Multiplier
		Delimiter
		Capture
		CaptureName
	End Enum
End Namespace
