﻿Imports System.Text
Imports Microsoft.VisualStudio.RegularExpression.Coloring

Namespace Microsoft.VisualStudio.RegularExpression.Parser
	''' <summary>
	''' Unit of parse for a regular expression.
	''' </summary>
	Friend Structure Token
		Friend Start As Integer
		Friend [End] As Integer
		Friend Kind As TokenKind
		Friend MatchBraces As Boolean

		Friend Sub New(ByVal start As Integer, ByVal [end] As Integer, ByVal kind As TokenKind)
			Me.Start = start
			Me.End = [end]
			Me.Kind = kind
			MatchBraces = False

		End Sub

		Friend Sub New(ByVal start As Integer, ByVal [end] As Integer, ByVal kind As TokenKind, ByVal matchBraces As Boolean)
			Me.Start = start
			Me.End = [end]
			Me.Kind = kind
			Me.MatchBraces = matchBraces
		End Sub

		Friend Shared Function TranslateEnumToString(ByVal tokenKindEnum As TokenKind) As String
			Select Case tokenKindEnum
				Case TokenKind.CharGroup
					Return ClassificationTypes.CharGroup
				Case TokenKind.Repetition
					Return ClassificationTypes.Repetition
				Case TokenKind.EscapedExpression
					Return ClassificationTypes.EscapedExpression
				Case TokenKind.Expression
					Return ClassificationTypes.Expression
				Case TokenKind.Multiplier
					Return ClassificationTypes.Multiplier
				Case TokenKind.Delimiter
					Return ClassificationTypes.Delimiter
				Case TokenKind.Capture
					Return ClassificationTypes.Capture
				Case TokenKind.CaptureName
					Return ClassificationTypes.Capture
				Case Else
					Return ""
			End Select
		End Function
	End Structure
End Namespace
