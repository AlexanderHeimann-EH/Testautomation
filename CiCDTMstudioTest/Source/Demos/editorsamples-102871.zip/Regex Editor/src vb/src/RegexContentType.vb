﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression
	Friend Class RegexContentType
		<Export, Name(ContentTypeName), BaseDefinition("code")>
		Friend Shared RegexContentTypeDefinition As ContentTypeDefinition

        Friend Const ContentTypeName = "regex"
	End Class
End Namespace