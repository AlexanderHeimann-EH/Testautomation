﻿Imports System.Text
Imports Microsoft.VisualStudio.Utilities
Imports System.ComponentModel.Composition

Namespace Microsoft.VisualStudio.RegularExpression
	Friend NotInheritable Class RegexFileExtensionDefinition
		<Export, FileExtension(RegexFileExtension), ContentType(RegexContentType.ContentTypeName)>
		Friend Shared FileExtensionDefinition As FileExtensionToContentTypeDefinition

        Friend Const RegexFileExtension = ".regex"
	End Class
End Namespace