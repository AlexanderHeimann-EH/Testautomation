﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports System.Windows.Media
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.RegularExpression.Coloring
    'Classification Formats are used to provide default color for the types defined in Classification Types.

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.CharGroup), _
    Name("RegexCharGroupFormatDefinition"), DisplayName("Regexp Character Group"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexCharGroupFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.ForestGreen
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.Repetition), _
    Name("RegexRepetitionFormatDefinition"), DisplayName("Regexp Repetition"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexRepetitionFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.Gray
            IsItalic = True
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.Capture), _
    Name("RegexCaptureFormatDefinition"), DisplayName("Regexp Capture"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexCaptureFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.Blue
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.EscapedExpression), _
    Name("RegexEscapedExpressionDefinition"), DisplayName("Regexp Escaped Expression"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexEscapedExpressionFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.LightGray
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.Expression), _
    Name("RegexExpressionDefinition"), DisplayName("Regexp Expression"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexExpressionFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.Blue
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.Multiplier), _
    Name("RegexMultiplierDefinition"), DisplayName("Regexp Multiplier"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexMultiplierFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.Gray
            IsItalic = True
        End Sub
    End Class

    <Export(GetType(EditorFormatDefinition)), UserVisible(False), ClassificationType(ClassificationTypeNames:=ClassificationTypes.Delimiter), _
    Name("RegexDelimiterDefinition"), DisplayName("Regexp Delimiter"), Order(), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexDelimiterFormatDefinition
        Inherits ClassificationFormatDefinition
        Public Sub New()
            ForegroundBrush = Brushes.DarkBlue
            IsItalic = True
        End Sub
    End Class
End Namespace
