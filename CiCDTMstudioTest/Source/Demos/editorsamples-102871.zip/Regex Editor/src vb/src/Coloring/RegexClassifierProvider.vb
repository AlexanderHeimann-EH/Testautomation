Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.RegularExpression.Parser

Namespace Microsoft.VisualStudio.RegularExpression.Coloring
    <Export(GetType(IClassifierProvider)), ContentType(RegexContentType.ContentTypeName)>
    Friend NotInheritable Class RegexClassifierProvider
        Implements IClassifierProvider
        'The ClassificationTypeRegistryService is used to discover the types defined in ClassificationTypeDefinitions
        <Import()>
        Private Property ClassificationTypeRegistry As IClassificationTypeRegistryService

        Public Function GetClassifier(ByVal buffer As ITextBuffer) As IClassifier Implements IClassifierProvider.GetClassifier
            buffer.Properties.GetOrCreateSingletonProperty(Of ParserRunner)(Function() New ParserRunner(buffer))
            Return New RegexClassifier(buffer, ClassificationTypeRegistry)
        End Function
    End Class
End Namespace