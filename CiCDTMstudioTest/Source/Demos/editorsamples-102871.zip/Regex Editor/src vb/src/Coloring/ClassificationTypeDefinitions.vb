﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Classification
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.Coloring
	'Claffication types are used to define coloring groups. They are linked to Classification Formats by the name
	Friend NotInheritable Class ClassificationTypes
        Friend Const CharGroup = "regex char group"
        Friend Const Expression = "regex expression"
        Friend Const EscapedExpression = "regex escaped expression"
        Friend Const Multiplier = "regex multiplier"
        Friend Const Delimiter = "regex delimiter"
        Friend Const Capture = "regex capture"
        Friend Const Repetition = "regex repetition"

		<Export, Name(ClassificationTypes.CharGroup)>
		Friend Shared RegexCharGroupClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.Repetition)>
		Friend Shared RegexRepetitionClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.EscapedExpression)>
		Friend Shared RegexEscapedExpressionClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.Expression)>
		Friend Shared RegexExpressionClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.Multiplier)>
		Friend Shared RegexMultiplierClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.Delimiter)>
		Friend Shared RegexDelimiterClassificationType As ClassificationTypeDefinition

		<Export, Name(ClassificationTypes.Capture)>
		Friend Shared RegexCaptureClassificationType As ClassificationTypeDefinition

	End Class
End Namespace