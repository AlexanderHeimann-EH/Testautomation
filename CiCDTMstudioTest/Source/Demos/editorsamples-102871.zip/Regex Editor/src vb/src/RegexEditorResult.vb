﻿Imports System.Text

Namespace Microsoft.VisualStudio.RegularExpression
	''' <summary>
	''' Represents the result of showing the regex dialog.
	''' </summary>
	Friend Class RegexEditorResult
		Friend Sub New(ByVal pattern As String, ByVal result? As Boolean)
            Me.Result = result
            Me.Pattern = pattern
		End Sub

		''' <summary>
		''' Gets the result of showing the dialog. If true the user accepted the dialog.
		''' </summary>
        Friend Property Result As Boolean?

		''' <summary>
		''' Gets the regex expression.
		''' </summary>
        Friend Property Pattern As String
    End Class
End Namespace
