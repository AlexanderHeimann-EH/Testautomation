﻿Imports System.Text
Imports System.Windows.Input
Imports Microsoft.VisualStudio.Text.Editor

Namespace Microsoft.VisualStudio.RegularExpression
	''' <summary>
	''' Provides key events.
	''' </summary>
	Friend Class RegexKeyProcessor
		Inherits KeyProcessor
		Private view As IWpfTextView

		Friend Shared Event KeyDownEvent As KeyEventHandler
		Friend Shared Event KeyUpEvent As KeyEventHandler

		Friend Sub New(ByVal view As IWpfTextView)
			Me.view = view
		End Sub

		Public Overrides Sub KeyDown(ByVal args As KeyEventArgs)
			Me.OnKeyDown(args)
			MyBase.KeyDown(args)
		End Sub

		Public Overrides Sub KeyUp(ByVal args As KeyEventArgs)
			Me.OnKeyUp(args)
			MyBase.KeyUp(args)
		End Sub

		Protected Overridable Sub OnKeyDown(ByVal args As KeyEventArgs)
			RaiseEvent KeyDownEvent(view, args)
		End Sub

		Protected Overridable Sub OnKeyUp(ByVal args As KeyEventArgs)
			RaiseEvent KeyUpEvent(view, args)
		End Sub
	End Class
End Namespace