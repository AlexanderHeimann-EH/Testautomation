﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression.BraceMatching
	<Export(GetType(IBraceMatcherProvider)), ContentType(RegexContentType.ContentTypeName)>
	Friend NotInheritable Class RegexBraceMatcherProvider
		Implements IBraceMatcherProvider
		Public Function GetBraceMatcher(ByVal snapshot As ITextSnapshot) As IBraceMatcher Implements IBraceMatcherProvider.GetBraceMatcher
			Return New RegexBraceMatcher(snapshot)
		End Function
	End Class
End Namespace