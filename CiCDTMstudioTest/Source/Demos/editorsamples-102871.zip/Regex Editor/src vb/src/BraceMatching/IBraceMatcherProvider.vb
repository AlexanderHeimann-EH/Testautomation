﻿Imports System.Text
Imports Microsoft.VisualStudio.Text

Namespace Microsoft.VisualStudio.RegularExpression.BraceMatching
	''' <summary>
	''' Provides an implementation of <see cref="IBraceMatcher"/>
	''' </summary>
	Friend Interface IBraceMatcherProvider
		Function GetBraceMatcher(ByVal snapshot As ITextSnapshot) As IBraceMatcher
	End Interface
End Namespace