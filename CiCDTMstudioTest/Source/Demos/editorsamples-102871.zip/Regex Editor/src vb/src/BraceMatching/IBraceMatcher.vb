﻿Imports System.Text
Imports Microsoft.VisualStudio.Text

Namespace Microsoft.VisualStudio.RegularExpression.BraceMatching
	''' <summary>
	''' Provides the brace macthing spans.
	''' </summary>
	Friend Interface IBraceMatcher
		''' <summary>
		''' Returns the list of brace matching spans. Each tuple defines from/to the brace matching should be applied.
		''' It's possible to highlight more than one caracter.
		''' </summary>
		''' <param name="caretLocation"></param>
		''' <returns></returns>
		Function GetBraceMatchingSpans(ByVal caretLocation As SnapshotPoint) As IList(Of Tuple(Of SnapshotSpan, SnapshotSpan))
	End Interface
End Namespace