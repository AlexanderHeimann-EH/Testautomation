﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Text.Adornments

Namespace Microsoft.VisualStudio.RegularExpression.BraceMatching

    <Export(GetType(IWpfTextViewCreationListener)), ContentType(RegexContentType.ContentTypeName), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend Class BraceMatchingPresenterFactory
        Implements IWpfTextViewCreationListener

        <Import()>
        Private Property TextMakerProviderFactory As ITextMarkerProviderFactory

        <ImportMany()>
        Private Property BraceMatcherProviders As IEnumerable(Of Lazy(Of IBraceMatcherProvider))

        Friend Sub TextViewCreated(ByVal textView As IWpfTextView) Implements IWpfTextViewCreationListener.TextViewCreated

            textView.Properties.GetOrCreateSingletonProperty(Of BraceMatchingPresenter)(
                Function()
                    Dim providers = Me.BraceMatcherProviders.Select(Function(p) p.Value)
                    Return New BraceMatchingPresenter(textView, providers.ToList(), Me.TextMakerProviderFactory)
                End Function)
        End Sub
    End Class
End Namespace