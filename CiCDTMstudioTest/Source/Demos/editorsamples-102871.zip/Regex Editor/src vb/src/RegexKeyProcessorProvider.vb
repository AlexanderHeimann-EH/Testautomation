﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities

Namespace Microsoft.VisualStudio.RegularExpression
    <Export(GetType(IKeyProcessorProvider)), Name("Regex Key Processor"), Order(Before:="default"), ContentType(RegexContentType.ContentTypeName), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexKeyProcessorProvider
        Implements IKeyProcessorProvider
        Public Function GetAssociatedProcessor(ByVal wpfTextView As IWpfTextView) As KeyProcessor Implements IKeyProcessorProvider.GetAssociatedProcessor
            Return (New RegexKeyProcessor(wpfTextView))
        End Function
    End Class
End Namespace