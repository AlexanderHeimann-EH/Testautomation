﻿Imports System.Text
Imports System.IO
Imports System.Xml.Serialization
Imports System.Xml

Namespace Microsoft.VisualStudio.RegularExpression.UI
	''' <summary>
	''' Item to be saved or loaded from the user's regex repository.
	''' </summary>
	<Serializable>
	Public Class RegexRepositoryItem
		Implements ICloneable
		''' <summary>
		''' Gets or sets the Author
		''' </summary>
        Public Property Author As String

		''' <summary>
		''' Gets or sets the category
		''' </summary>
        Public Property Category As String

		''' <summary>
		''' Gets or sets the Description
		''' </summary>
        Public Property Description As String

		''' <summary>
		''' Gets or sets the Matches
		''' </summary>
        Public Property Matches As String

		''' <summary>
		''' Gets or sets the Regex
		''' </summary>
        Public Property Regex As String

		''' <summary>
		''' Gets or sets the Title
		''' </summary>
        Public Property Title As String

		''' <summary>
		''' Clones an instance of <see cref="RegexRepositoryItem"/>
		''' </summary>
		''' <returns></returns>
		Public Function Clone() As Object Implements ICloneable.Clone
            Dim item As New RegexRepositoryItem
			item.Author = Me.Author
			item.Category = Me.Category
			item.Description = Me.Description
			item.Matches = Me.Matches
			item.Title = Me.Title
			item.Regex = Me.Regex

			Return item
		End Function
	End Class
End Namespace