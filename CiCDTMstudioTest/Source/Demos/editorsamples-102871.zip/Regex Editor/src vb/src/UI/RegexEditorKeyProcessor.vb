﻿Imports System.Text
Imports System.Windows.Input
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Text.Operations
Imports System.Windows
Imports System.ComponentModel

Namespace Microsoft.VisualStudio.RegularExpression.UI
    ''' <summary>
    ''' Handles key in the regex editor
    ''' </summary>
    Friend Class RegexEditorKeyProcessor
        Inherits KeyProcessor
        Private editorOperations As IEditorOperations
        Private keyTypeConverter As KeyTypeConverter

        Friend Sub New(ByVal editorOperations As IEditorOperations)
            Me.editorOperations = editorOperations
            Me.keyTypeConverter = New KeyTypeConverter
        End Sub

        Public Overrides Sub KeyDown(ByVal args As KeyEventArgs)
            ' Convert the Key into a char
            Dim myKey? = keyTypeConverter.ConvertToChar(args.Key)

            If myKey.HasValue Then
                If IsCtrlKeyDown() Then
                    Select Case myKey.Value
                        ' Paste command
                        Case "v"c, "V"c
                            If editorOperations.CanPaste Then
                                Me.editorOperations.Paste()
                            End If

                            ' Copy command
                        Case "c"c, "C"c
                            Me.editorOperations.CopySelection()

                            ' Cut command
                        Case "x"c, "X"c
                            If editorOperations.CanCut Then
                                Me.editorOperations.CutSelection()
                            End If

                            ' Select All command
                        Case "a"c, "A"c
                            editorOperations.SelectAll()
                    End Select
                Else
                    Me.editorOperations.InsertText(myKey.Value.ToString())
                End If
                args.Handled = True
            Else
                args.Handled = True
                Select Case args.Key
                    Case Key.Left
                        Me.editorOperations.MoveToPreviousCharacter(IsShiftKeyDown())
                        Return
                    Case Key.Right
                        Me.editorOperations.MoveToNextCharacter(IsShiftKeyDown())
                        Return
                    Case Key.Home
                        Me.editorOperations.MoveToStartOfLine(IsShiftKeyDown())
                        Return
                    Case Key.End
                        Me.editorOperations.MoveToEndOfLine(IsShiftKeyDown())
                        Return
                    Case Key.Delete
                        Me.editorOperations.Delete()
                        Return
                End Select
                args.Handled = False
            End If
        End Sub

        Public Overrides Sub KeyUp(ByVal args As KeyEventArgs)
            If args.Key = Key.Back Then
                Me.editorOperations.Backspace()
                args.Handled = True
            End If
        End Sub

        ''' <summary>
        ''' Returns true if the Shift Key is pressed
        ''' </summary>
        ''' <returns></returns>
        Private Function IsShiftKeyDown() As Boolean
            Return Keyboard.IsKeyDown(Key.RightShift) OrElse Keyboard.IsKeyDown(Key.LeftShift)
        End Function

        ''' <summary>
        ''' Returns true if Ctrl key is pressed
        ''' </summary>
        ''' <returns></returns>
        Private Function IsCtrlKeyDown() As Boolean
            Return Keyboard.IsKeyDown(Key.LeftCtrl) OrElse Keyboard.IsKeyDown(Key.RightCtrl)
        End Function

    End Class
End Namespace