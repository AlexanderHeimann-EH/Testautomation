﻿Imports System.Text
Imports System.ComponentModel.Composition
Imports Microsoft.VisualStudio.Text.Editor
Imports Microsoft.VisualStudio.Utilities
Imports Microsoft.VisualStudio.Text.Operations

Namespace Microsoft.VisualStudio.RegularExpression.UI
    <Export(GetType(IKeyProcessorProvider)), Name("Regex Editor Key Processor"), Order(After:="Regex Key Processor"), ContentType(RegexContentType.ContentTypeName), TextViewRole(PredefinedTextViewRoles.Document)>
    Friend NotInheritable Class RegexEditorKeyProcessorProvider
        Implements IKeyProcessorProvider

        <Import()>
        Private Property EditorOperationsFactoryService As IEditorOperationsFactoryService

        Public Function GetAssociatedProcessor(ByVal wpfTextView As IWpfTextView) As KeyProcessor Implements IKeyProcessorProvider.GetAssociatedProcessor
            ' Create the key processor only if the target buffer is of content type "regex"
            If wpfTextView.TextBuffer.ContentType.TypeName = RegexContentType.ContentTypeName Then
                Dim editorOperations = Me.EditorOperationsFactoryService.GetEditorOperations(wpfTextView)

                Return New RegexEditorKeyProcessor(editorOperations)
            End If

            Return Nothing
        End Function
    End Class
End Namespace
