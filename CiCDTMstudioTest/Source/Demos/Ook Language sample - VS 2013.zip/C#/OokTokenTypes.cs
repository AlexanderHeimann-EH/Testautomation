﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OokLanguage
{
    public enum OokTokenTypes
    {
       OokExclaimation, OokQuestion, OokPeriod
    }
}
