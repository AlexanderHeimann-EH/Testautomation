﻿#region Using

using System;
using System.Windows.Media;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.ComponentModel;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    #region Documentation
    /// <summary>
    /// filter view model
    /// </summary>
    #endregion // Documentation
    public class Filter : INotifyPropertyChanged
    {
        #region Properties

        #region Icon Automation Text

        #region Documentation
        /// <summary>
        /// tooltip
        /// </summary>
        #endregion // Documentation
        public String IconAutomationText { get; set; }

        #endregion // Icon Automation Text

        #region Is Checked

        #region Documentation
        /// <summary>
        /// the filter state
        /// </summary>
        #endregion // Documentation
        public bool IsChecked { get; set; }

        #endregion // Is Checked

        #region Image Source

        #region Documentation
        /// <summary>
        /// the filter image
        /// </summary>
        #endregion // Documentation
        public ImageSource ImageSource { get; set; }

        #endregion // Image Source

        #region Is Active In Current Session

        #region Documentation
        /// <summary>
        /// Indicate whether the filter is active in the current session
        /// </summary>
        #endregion // Documentation
        public bool IsActiveInCurrentSession { get; set; }

        #endregion // Is Active In Current Session

        #region Owner

        #region Documentation
        /// <summary>
        /// The UI element that own the filter
        /// </summary>
        #endregion // Documentation
        public ToggleButton Owner { get; set; }

        #endregion // Owner

        #region Is Visible

        private Visibility _isVisible = Visibility.Visible;
        public Visibility IsVisible 
        {
            get { return _isVisible; }
            set
            {
                if (_isVisible == value)
                    return;
                _isVisible = value;

                const string PROPERTY_NAME = "IsVisible";
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs(PROPERTY_NAME));
            }
        }

        #endregion // Is Visible

        #endregion // Properties

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion // INotifyPropertyChanged Members
    }
}
