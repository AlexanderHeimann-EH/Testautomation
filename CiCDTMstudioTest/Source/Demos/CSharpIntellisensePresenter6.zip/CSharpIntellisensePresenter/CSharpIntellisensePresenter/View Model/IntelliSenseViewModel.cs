﻿#region Using

using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.VisualStudio.Language.Intellisense;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    #region Documentation
    /// <summary>
    /// concrete IntelliSense class
    /// </summary>
    #endregion // Documentation
    internal class IntelliSenseViewModel : FilteredIntelliSensePresenseViewModelBase
    {
        #region Private / Protected Fields

        private IntelliSenseView _view;

        #endregion // Private / Protected Fields

        #region Constructors

        internal IntelliSenseViewModel(IServiceProvider serviceProvider, ICompletionSession session)
            : base(serviceProvider, session)
        {
            _view = new IntelliSenseView(this);
        }

        #endregion

        #region Properties

        protected override ListBox CompletionsListBox
        {
            get
            {
                if (_view != null && _view.listViewCompletions != null)
                {
                    return _view.listViewCompletions;
                }
                else
                {
                    return null;
                }
            }
        }

        #endregion

        #region Methods

        #region On Collection View Filter

        protected override bool OnCollectionViewFilter(Object itemToFilter)
        {
            Completion item = itemToFilter as Completion;
            if (item == null)
                return false;

            if (!IsIconFilterEnabled(item.IconAutomationText))
                return false;

            bool isMatch = IsMatch(item);

            return isMatch;
        }

        #endregion // On Collection View Filter

        #endregion

        #region IPopupIntellisensePresenter Properties

        #region Documentation
        /// <summary>
        /// Set the view as the surface element
        /// </summary>
        #endregion // Documentation
        public override UIElement SurfaceElement
        {
            get { return _view; }
        }

        #endregion
    }
}
