﻿#region Using

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.VisualStudio.Language.Intellisense;
using Microsoft.VisualStudio.Text;
using System.Diagnostics;
using Microsoft.VisualStudio.Text.Editor;
using System.Windows.Threading;
using System.Linq;
using System.Collections.Specialized;
using System.Windows.Controls.Primitives;
using System.Collections.ObjectModel;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    #region Documentation
    /// <summary>
    /// base class for the IntelliSense view model
    /// </summary>
    #endregion // Documentation
    internal abstract class FilteredIntelliSensePresenseViewModelBase:
        IPopupIntellisensePresenter,IIntellisenseCommandTarget,INotifyPropertyChanged
    {
        #region Constants

        private Regex _regex = new Regex(STR_REPLACE_REGEX);
        private const String STR_REPLACE_REGEX = "[0-9a-z.]";
        private static readonly string[] COMMIT_CHARS = new[] { /*";", "(", "{",*/  Environment.NewLine };

        #endregion // Constants

        #region Private / Protected Fields

        private ICompletionSession _completionSession;
        private IServiceProvider _serviceProvider;
        private CollectionViewSource _cvs;
        private IDictionary<String,Filter> _filters;
        private readonly ObservableCollection<ToggleButton> _filterView = new ObservableCollection<ToggleButton>();

        #endregion // Private / Protected Fields

        #region Constructor

        protected FilteredIntelliSensePresenseViewModelBase(IServiceProvider serviceProvider,ICompletionSession session)
        {
            _filters = new Dictionary<String,Filter>();
            _completionSession = session;
            _serviceProvider = serviceProvider;
            LoadCapsAndIcons();
            ITextView textView = _completionSession.TextView;

            _cvs = new CollectionViewSource();
            _cvs.Source = this.SelectedCompletionSet.Completions;
            _cvs.View.Filter = OnCollectionViewFilterHandler;
            _cvs.View.CollectionChanged += OnViewCollectionChangedHandler;
            textView.TextBuffer.Changed += OnTextBufferChangedHandler;
            _completionSession.Dismissed += OnSessionDismissedHandler;

            Application.Current.DispatcherUnhandledException -= OnAppDispatcherUnhandledExceptionHandler;
            Application.Current.DispatcherUnhandledException += OnAppDispatcherUnhandledExceptionHandler;
            SelectedCompletionSet.SelectionStatus = new CompletionSelectionStatus(null,true,true);
            SelectBestMatch();
        }

        #endregion // Constructor

        #region Events

#pragma warning disable 0067
        public event EventHandler PresentationSpanChanged;
#pragma warning restore 0067

#pragma warning disable 0067
        public event EventHandler SurfaceElementChanged;
#pragma warning restore 0067

#pragma warning disable 0067
        public event EventHandler<ValueChangedEventArgs<Microsoft.VisualStudio.Text.Adornments.PopupStyles>> PopupStylesChanged;
#pragma warning restore 0067

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties

        #region Selected Completion Set

        #region Documentation
        /// <summary>
        /// Gets / Sets the Selected Completion Set
        /// </summary>
        #endregion // Documentation
        public CompletionSet SelectedCompletionSet
        {
            get
            {
                if(_completionSession == null)
                    return null;
                return _completionSession.SelectedCompletionSet;
            }
        }

        #endregion // Selected Completion Set

        #region Filters

        #region Documentation
        /// <summary>
        /// Gets the filters collection
        /// </summary>
        #endregion // Documentation
        public IDictionary<string,Filter> Filters
        {
            get
            {
                return _filters;
            }
        }

        #endregion // Filters

        #region Filter View

        #region Documentation
        /// <summary>
        /// Collection of filter ToggleButton (for binding)
        /// </summary>
        #endregion // Documentation
        public ObservableCollection<ToggleButton> FilterView
        {
            get
            {
                return _filterView;
            }
        }

        #endregion // Filter View

        #region Completions List Box

        #region Documentation
        /// <summary>
        /// Gets the list box that present the completions
        /// </summary>
        #endregion // Documentation
        abstract protected ListBox CompletionsListBox
        {
            get;
        }

        #endregion // Completions List Box

        #region Completion Session

        #region Documentation
        /// <summary>
        /// Gets the current completion session
        /// </summary>
        #endregion // Documentation
        protected ICompletionSession CompletionSession
        {
            get
            {
                return _completionSession;
            }
        }

        #endregion // Completion Session

        #region Current User Text

        #region Documentation
        /// <summary>
        /// Gets the current text that the user is typing (after the .)
        /// </summary>
        #endregion // Documentation
        protected virtual String CurrentUserText
        {
            get
            {
                if(_completionSession == null || this.SelectedCompletionSet == null)
                    return String.Empty;

                ITrackingSpan tracking = this.SelectedCompletionSet.ApplicableTo;
                ITextSnapshot snapshot = tracking.TextBuffer.CurrentSnapshot;
                string userText = tracking.GetText(snapshot);
                int index = userText.LastIndexOf(".");
                if(index > -1)
                {
                    if(index < userText.Length - 1)
                        userText = userText.Substring(index);
                    else
                        userText = String.Empty;
                }
                return userText;

            }
        }

        #endregion // Current User Text

        #region Items

        #region Documentation
        /// <summary>
        /// Used to items collection of the current state
        /// </summary>
        #endregion // Documentation
        public CollectionViewSource Items
        {
            get
            {
                return _cvs;
            }
        }

        #endregion // Items

        #region Selected Item

        private Completion _selectedItem;
        #region Documentation
        /// <summary>
        /// The selected item
        /// </summary>
        #endregion // Documentation
        public Completion SelectedItem
        {
            get
            {
                return _selectedItem;
            }
            set
            {
                _selectedItem = value;
                if(_completionSession != null)
                    this.SelectedCompletionSet.SelectionStatus = new CompletionSelectionStatus(_selectedItem,true,true);
                if(PropertyChanged != null)
                    PropertyChanged(this,new PropertyChangedEventArgs("SelectedItem"));
            }
        }

        #endregion // Selected Item

        #region Is SingleFiltering

        private static bool _isSingleFiltering;
        #region Documentation
        /// <summary>
        /// Gets whether the current mode is a single filtering mode
        /// </summary>
        #endregion // Documentation
        public bool IsSingleFiltering
        {
            get
            {
                return _isSingleFiltering;
            }
            set
            {
                _isSingleFiltering = value;
                RaisePropertyChanged("IsSingleFiltering");
                Refresh();
            }
        }

        #endregion // Is SingleFiltering

        #region Is Show Tooltip

        private static Visibility _isShowTooltip = Visibility.Collapsed;
        #region Documentation
        /// <summary>
        /// Gets whether the documentation tooltip is visible
        /// </summary>
        #endregion // Documentation
        public Visibility IsShowTooltip
        {
            get
            {
                return _isShowTooltip;
            }
            set
            {
                _isShowTooltip = value;
                RaisePropertyChanged("IsShowTooltip");
                //Refresh();
            }
        }

        #endregion // Is Show Tooltip

        #endregion // Properties

        #region Interception Points

        abstract protected bool OnCollectionViewFilter(Object itemToFilter);

        protected virtual void OnDismissed()
        {
        }

        #endregion // Interception Points

        #region Methods

        #region Execute Filter

        public void ExecuteFilter(Filter filter)
        {
            if(_filters.ContainsKey(filter.IconAutomationText))
            {
                _filters[filter.IconAutomationText].IsChecked = filter.IsChecked;
            }
            _cvs.View.Refresh();
        }

        #endregion // Execute Filter

        #region Refresh

        #region Documentation
        /// <summary>
        /// refresh the view
        /// </summary>
        #endregion // Documentation
        public void Refresh()
        {
            try
            {
                if(_cvs == null || _cvs.View == null)
                    return;

                Completion selected = SelectedItem;

                _cvs.View.Refresh();

                if(_cvs.View.Contains(selected))
                    SelectedItem = selected;
                else
                    SelectBestMatch();
            }
            #region Exception Handling

            catch(Exception)
            {
                //ignore - happens is another thread shuts down this object

                #region Debug Section
#if DEBUG

                if(Debugger.IsAttached)
                {
                    Debugger.Break();
                }

#endif // DEBUG
                #endregion // Debug Section
            }

            #endregion // Exception Handling
        }

        #endregion // Refresh

        #region Commit

        #region Documentation
        /// <summary>
        /// Commit IntelliSense selection
        /// </summary>
        #endregion // Documentation
        internal void Commit()
        {
            if(_completionSession != null)
                _completionSession.Commit();
        }

        #endregion // Commit

        #region Is Icon Filter Enabled

        #region Documentation
        /// <summary>
        /// Gets whether the icon text related to enabled filter
        /// </summary>
        /// <param name="iconAutomationText"></param>
        /// <returns></returns>
        #endregion // Documentation
        public bool IsIconFilterEnabled(String iconAutomationText)
        {
            if(_filters.ContainsKey(iconAutomationText))
            {
                return _filters[iconAutomationText].IsActiveInCurrentSession && _filters[iconAutomationText].IsChecked;
            }
            else
            {
                return true;
            }
        }

        #endregion // Is Icon Filter Enabled

        #region Load Caps And Icons

        #region Documentation
        /// <summary>
        /// initialize the filters list
        /// </summary>
        #endregion // Documentation
        protected void LoadCapsAndIcons()
        {
            foreach(Filter item in Filters.Values)
            {
                item.IsActiveInCurrentSession = false;
            }

            foreach(CompletionSet cs in _completionSession.CompletionSets)
            {
                foreach(Completion item in cs.Completions)
                {
                    if(string.IsNullOrWhiteSpace(item.IconAutomationText))
                        continue;

                    if(item.IconAutomationText == "9")
                        continue;

                    if(_filters.ContainsKey(item.IconAutomationText))
                    {
                        Filter filter = _filters[item.IconAutomationText];
                        filter.IsActiveInCurrentSession = true;
                    }
                    else
                    {
                        Filter filter = new Filter()
                            {
                                IsActiveInCurrentSession = true,
                                IconAutomationText = item.IconAutomationText,
                                IsChecked = true,
                                ImageSource = item.IconSource.CloneCurrentValue()
                            };
                        _filters.Add(item.IconAutomationText,filter);
                    }
                }
            }
        }

        #endregion // Load Caps And Icons

        #region Get All Caps

        protected string GetAllCaps(Completion item,String userText)
        {
            if(userText.Length < 2)
                return null;
            String allCaps = _regex.Replace(item.DisplayText,String.Empty);
            return allCaps;
        }

        #endregion // Get All Caps

        #region Refresh Filter View

        private void RefreshFilterView()
        {
            #region Validation

            if(SelectedCompletionSet == null)
                return;

            #endregion // Validation

            foreach(Filter filter in _filters.Values)
            {
                bool isVisible = (from completion in SelectedCompletionSet.Completions
                                  where IsMatch(completion) &&
                                        filter.IconAutomationText == completion.IconAutomationText
                                  select completion).Any();
                if(isVisible)
                    filter.IsVisible = Visibility.Visible;
                else
                    filter.IsVisible = Visibility.Collapsed;
            }
        }

        #endregion // Refresh Filter View

        #region Refresh Selection

        #region Documentation
        /// <summary>
        /// Refresh the view
        /// </summary>
        #endregion // Documentation
        private void RefreshSelection()
        {
            #region Validation

            if(_cvs == null)
                return;

            #endregion // Validation

            String userText = CurrentUserText;
            if(!String.IsNullOrWhiteSpace(userText))
            {
                if(Utilities.IsAllCaps(userText) && userText.Length > 1 && userText.Length < 5)
                {
                    foreach(Completion item in _cvs.View)
                    {
                        String allCaps = GetAllCaps(item,userText);

                        if(userText.Length > allCaps.Length)
                            continue;
                        if(userText == allCaps.Substring(0,userText.Length))
                        {
                            SelectCompletion(item);
                            EnsureVisible();
                            return;
                        }
                    }
                }
            }

            SelectBestMatch();
            EnsureVisible();
        }

        #endregion // Refresh Selection

        #region Select Relative Completion

        #region Documentation
        /// <summary>
        /// Move the selection by relative index 
        /// </summary>
        /// <param name="relativeIndex"></param>
        #endregion // Documentation
        private void SelectRelativeCompletion(int relativeIndex)
        {
            if(_cvs != null && _cvs.View != null && _completionSession != null)
            {
                Int32 newPostion = _cvs.View.CurrentPosition + relativeIndex;
                if(relativeIndex >= 0)
                {
                    try
                    {
                        if(!_cvs.View.MoveCurrentToPosition(newPostion))
                        {
                            _cvs.View.MoveCurrentToLast();
                        }
                    }
                    catch(Exception ex)
                    {
                        #region Debug Section
#if DEBUG

                        if(Debugger.IsAttached)
                        {
                            Debugger.Break();
                        }

#endif // DEBUG
                        #endregion // Debug Section
                        Debug.WriteLine(ex.Message);
                        _cvs.View.MoveCurrentToLast();
                    }
                }
                else
                {
                    try
                    {
                        if(!_cvs.View.MoveCurrentToPosition(newPostion))
                        {
                            _cvs.View.MoveCurrentToFirst();
                        }
                    }
                    catch(Exception)
                    {
                        _cvs.View.MoveCurrentToFirst();
                    }
                }
                this.SelectedCompletionSet.SelectionStatus =
                    new CompletionSelectionStatus((Completion)this.Items.View.CurrentItem,true,true);
                CompletionsListBox.Dispatcher.BeginInvoke(
                    new Action(ScrollFeedbackViewToCurrentItem),
                    System.Windows.Threading.DispatcherPriority.Send);
            }
        }

        #endregion // Select Relative Completion

        #region Select Completion

        #region Documentation
        /// <summary>
        /// Select completion item
        /// </summary>
        /// <param name="item"></param>
        #endregion // Documentation
        private void SelectCompletion(Completion item)
        {
            this.SelectedCompletionSet.SelectionStatus = new CompletionSelectionStatus(item,true,true);
            _cvs.View.MoveCurrentTo(item);

            #region Validation

            if(_cvs == null)
                return;
            if(_cvs.View == null)
                return;
            if(_cvs.View.CurrentItem == null)
                return;
            if(_cvs.View.IsCurrentBeforeFirst)
                return;
            if(_cvs.View.IsCurrentAfterLast)
                return;

            #endregion // Validation

            ScrollFeedbackViewToCurrentItem();
        }

        #endregion // Select Completion

        #region Scroll Feedback View To Last Item

        private void ScrollFeedbackViewToCurrentItem()
        {
            #region Validation

            if(_cvs == null)
                return;
            if(_cvs.View == null)
                return;
            if(_cvs.View.CurrentItem == null)
                return;
            if(_cvs.View.IsCurrentBeforeFirst)
                return;
            if(_cvs.View.IsCurrentAfterLast)
                return;

            #endregion // Validation

            CompletionsListBox.ScrollIntoView(_cvs.View.CurrentItem);
        }

        #endregion // Scroll Feedback View To Last Item

        #region Select Best Match

        #region Documentation
        /// <summary>
        /// Make the best matching choice
        /// </summary>
        #endregion // Documentation
        private void SelectBestMatch()
        {
            if(SelectedCompletionSet == null)
                return;

            SelectedCompletionSet.SelectBestMatch();
            SelectedItem = SelectedCompletionSet.SelectionStatus.Completion;
        }

        #endregion // Select Best Match

        #region Is Match

        #region Documentation
        /// <summary>
        /// The actual matching
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        #endregion // Documentation
        protected virtual bool IsMatch(Completion item)
        {
            string userText = CurrentUserText;
            if(string.IsNullOrWhiteSpace(userText))
                return true;

            if(Utilities.IsAllCaps(userText))
            {
                string allCaps = GetAllCaps(item,userText);
                if(allCaps != null)
                {
                    bool startWithCap = allCaps.StartsWith(userText);
                    if(startWithCap)
                        return startWithCap;
                }
            }

            int i = item.DisplayText.IndexOf(userText,StringComparison.OrdinalIgnoreCase);
            return i != -1;
        }

        #endregion // Is Match

        #region Ensure Visible

        private void EnsureVisible()
        {
            CompletionsListBox.Dispatcher.BeginInvoke(
                   new Action(ScrollFeedbackViewToCurrentItem),
                    System.Windows.Threading.DispatcherPriority.Send);
        }

        #endregion // Ensure Visible

        #endregion // Public Methods

        #region Event Handlers

        #region On Session Dismissed Handler

        #region Documentation
        /// <summary>
        /// Handle session completion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #endregion // Documentation
        private void OnSessionDismissedHandler(object sender,EventArgs e)
        {
            if(_cvs != null && _cvs.View != null)
                _cvs.View.CollectionChanged -= OnViewCollectionChangedHandler;

            if(_completionSession != null)
            {
                ITextView textView = _completionSession.TextView;
                textView.TextBuffer.Changed -= OnTextBufferChangedHandler;
                _completionSession.Dismissed -= OnSessionDismissedHandler;
            }
            try
            {
                OnDismissed();
            }
            #region Exception Handling
            catch(Exception)
            {

                #region Debug Section
#if DEBUG

                if(Debugger.IsAttached)
                {
                    Debugger.Break();
                }

#endif // DEBUG
                #endregion // Debug Section

            }
            #endregion // Exception Handling


            Application.Current.DispatcherUnhandledException -= OnAppDispatcherUnhandledExceptionHandler;
            _cvs.Source = null;

        }

        #endregion // On Session Dismissed Handler

        #region On Text Buffer Changed Handler

        #region Documentation
        /// <summary>
        /// Handle the test changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #endregion // Documentation
        private void OnTextBufferChangedHandler(object sender,TextContentChangedEventArgs e)
        {
            #region Validation

            if(e.Changes.Count == 0)
                return;

            #endregion // Validation

            string newText = e.Changes[e.Changes.Count - 1].NewText;

            #region Validation

            if(string.IsNullOrEmpty(CurrentUserText))
            {
                if(_completionSession != null)
                    _completionSession.Dismiss();
            }

            #endregion // Validation

            bool hasCommit = false;
            foreach(string c in COMMIT_CHARS)
            {
                if(newText.EndsWith(c))
                {
                    Commit();
                    hasCommit = true;
                }
            }

            if(!hasCommit)
            {
                Action action = () =>
                    {
                        RefreshFilterView();
                        SelectBestMatch();
                    };
                Application.Current.Dispatcher.BeginInvoke(action,
                    System.Windows.Threading.DispatcherPriority.Send);
            }
        }

        #endregion // On Text Buffer Changed Handler

        #region On Collection View Filter Handler

        private bool OnCollectionViewFilterHandler(Object itemToFilter)
        {
            return OnCollectionViewFilter(itemToFilter);
        }

        #endregion // On Collection View Filter Handler

        #region On View Collection Changed Handler

        private void OnViewCollectionChangedHandler(object sender,NotifyCollectionChangedEventArgs e)
        {
            RefreshSelection();
        }

        #endregion // On View Collection Changed Handler

        #region On App Dispatcher Unhandled Exception Handler

        #region Documentation
        /// <summary>
        /// The dispatcher unhandled exception.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.Windows.Threading.DispatcherUnhandledExceptionEventArgs"/> instance containing the event data.</param>
        #endregion // Documentation
        private void OnAppDispatcherUnhandledExceptionHandler(object sender,DispatcherUnhandledExceptionEventArgs e)
        {
            #region Debug Section
#if DEBUG

            if(Debugger.IsAttached)
            {
                Debugger.Break();
            }

#endif // DEBUG
            #endregion // Debug Section

            Debug.WriteLine(e.Exception.Message);

            e.Handled = true;
        }

        #endregion // On App Dispatcher Unhandled Exception Handler

        #endregion // Event Handlers

        #region IPopupIntellisensePresenter Members

        #region Space Reservation Manager Name

        #region Documentation
        /// <summary>
        /// Gets the name of the space reservation manager that should be used to create
        ///     popups for this presenter
        /// </summary>
        #endregion // Documentation
        string IPopupIntellisensePresenter.SpaceReservationManagerName
        {
            get
            {
                return "completion";
            }
        }

        #endregion // Space Reservation Manager Name

        #region SurfaceElement

        #region Documentation
        /// <summary>
        /// Gets the WPF System.Windows.UIElement that the presenter wants to be displayed
        ///     inside a Microsoft.VisualStudio.Text.Editor.ITextView popup.
        /// </summary>
        #endregion // Documentation
        abstract public UIElement SurfaceElement
        {
            get;
        }

        #endregion // SurfaceElement

        #region Presentation Span

        #region Documentation
        /// <summary>
        /// Gets the Microsoft.VisualStudio.Text.ITrackingSpan to which this presenter
        ///     is related
        /// </summary>
        /// <remarks>
        /// This property is used to determine where to place the Microsoft.VisualStudio.Text.Editor.ITextView
        /// popup inside of which the presenter's SurfaceElement is hosted.
        /// </remarks>
        #endregion // Documentation
        public ITrackingSpan PresentationSpan
        {
            get
            {
                ITextView textView = _completionSession.TextView;
                ITextSnapshot snapshot = textView.TextSnapshot;
                ITrackingSpan track = this.SelectedCompletionSet.ApplicableTo;
                SnapshotSpan span = track.GetSpan(snapshot);
                NormalizedSnapshotSpanCollection spans = textView.BufferGraph.MapUpToBuffer(
                    span,
                    track.TrackingMode,
                    textView.TextBuffer);
                if(spans.Count <= 0)
                {
                    #region Debug Section
#if DEBUG

                    if(Debugger.IsAttached)
                    {
                        Debugger.Break();
                    }

#endif // DEBUG
                    #endregion // Debug Section

                    throw new InvalidOperationException("Completion Session Applicable-To Span is invalid.  It doesn't map to a span in the session's text view.");
                }
                SnapshotSpan span2 = spans[0];
                return textView.TextBuffer.CurrentSnapshot.CreateTrackingSpan(span2.Span,SpanTrackingMode.EdgeInclusive);
            }
        }

        #endregion // Presentation Span

        #region Session

        #region Documentation
        /// <summary>
        /// Gets the session that this presenter is rendering.
        /// </summary>
        #endregion // Documentation
        public IIntellisenseSession Session
        {
            get
            {
                return _completionSession;
            }
        }

        #endregion // Session

        #region Opacity

        #region Documentation
        /// <summary>
        /// Gets or sets the opacity of this popup presenter.
        /// </summary>
        #endregion // Documentation
        public double Opacity
        {
            get
            {
                return SurfaceElement.Opacity;
            }
            set
            {
                SurfaceElement.Opacity = value;
            }
        }

        #endregion // Opacity

        #region Popup Styles

        #region Documentation
        /// <summary>
        /// Gets a set of flags that determine the popup style.
        /// </summary>
        #endregion // Documentation
        public Microsoft.VisualStudio.Text.Adornments.PopupStyles PopupStyles
        {
            get
            {
                return Microsoft.VisualStudio.Text.Adornments.PopupStyles.PositionClosest;
            }
        }

        #endregion // Popup Styles

        #endregion // IPopupIntellisensePresenter Properties

        #region IIntellisenseCommandTarget Members

        #region Documentation
        /// <summary>
        /// Intercept the keyboard strikes
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        #endregion // Documentation
        public bool ExecuteKeyboardCommand(IntellisenseKeyboardCommand command)
        {
            switch(command)
            {
                case IntellisenseKeyboardCommand.Up:
                    SelectRelativeCompletion(-1);
                    return true;
                case IntellisenseKeyboardCommand.PageUp:
                    SelectRelativeCompletion(-10);
                    return true;
                case IntellisenseKeyboardCommand.Down:
                    SelectRelativeCompletion(1);
                    return true;
                case IntellisenseKeyboardCommand.PageDown:
                    SelectRelativeCompletion(10);
                    return true;
                case IntellisenseKeyboardCommand.Escape:
                    this.Session.Dismiss();
                    return true;
            }
            return false;
        }

        #endregion // IIntellisenseCommandTarget Members

        #region INotifyPropertyChanged Members

        protected void RaisePropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if(handler != null)
            {
                handler(this,new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion // INotifyPropertyChanged Members
    }
}
