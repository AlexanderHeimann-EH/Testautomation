﻿#region Using

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.Language.Intellisense;
using Microsoft.VisualStudio.Utilities;
using Microsoft.VisualStudio.Text.Editor;
using Microsoft.VisualStudio.Shell;
using System.Diagnostics;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    [Export(typeof(IIntellisensePresenterProvider))]
    [ContentType("text")]
    [Order(Before = "Default Completion Presenter")]
    [Name("Object Intellisense Presenter")]
    internal class IntellisensePresenterProvider : IIntellisensePresenterProvider
    {
        [Import(typeof(SVsServiceProvider))]
        IServiceProvider ServiceProvider { get; set; }

        #region Try Create Intellisense Presenter

        #region Documentation
        /// <summary>
        /// Inject the IntelliSense presenter
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        #endregion // Documentation
        public IIntellisensePresenter TryCreateIntellisensePresenter(IIntellisenseSession session)
        {
            #region Validation (is C#)

            const string CSHARP_CONTENT = "CSharp";
            if (session.TextView.TextBuffer.ContentType.TypeName != CSHARP_CONTENT)
            {
                return null;
            }

            #endregion // Validation

            ICompletionSession completionSession = session as ICompletionSession;
            if (completionSession != null)
            {
                var presenter = new IntelliSenseViewModel(ServiceProvider, completionSession);
                return presenter;
            }
            return null;
        }

        #endregion // Try Create Intellisense Presenter
    }

}
