﻿#region Using

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    #region Documentation
    /// <summary>
    /// Helper class
    /// </summary>
    #endregion // Documentation
    internal class Utilities
    {
        #region Is All Caps

        #region Documentation
        /// <summary>
        /// Check whether all char in the string are upper case
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        #endregion // Documentation
        public static bool IsAllCaps(String s)
        {
            if (s.Length < 2)
                return false;

            foreach (Char c in s)
            {
                if (!Char.IsUpper(c))
                {
                    return false;
                }
            }
            return true;
        }

        #endregion // Is All Caps
    }
}
