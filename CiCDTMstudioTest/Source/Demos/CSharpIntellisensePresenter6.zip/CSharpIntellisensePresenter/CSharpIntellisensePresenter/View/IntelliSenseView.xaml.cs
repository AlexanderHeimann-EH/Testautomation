﻿#region Using

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.VisualStudio.Language.Intellisense;
using Microsoft.VisualStudio.Text.Editor;
using System.Linq;
using System.Windows.Threading;
using System.Diagnostics;

#endregion // Using
// use ctrl+M, ctrl+O to collapse all regions

namespace Bnaya.Samples
{
    #region Documentation
    /// <summary>
    /// Main IntelliSense view
    /// </summary>
    #endregion // Documentation
    public partial class IntelliSenseView : UserControl
    {
        Stopwatch _watch = new Stopwatch();
        #region Private / Protected Fields
            
        private IntelliSenseViewModel _viewModel;
        private ToggleButton _resetCommand;

        #endregion // Private / Protected Fields

        #region Constructor

        internal IntelliSenseView(IntelliSenseViewModel viewModel)
        {
            _watch.Start();
            InitializeComponent();
            _viewModel = viewModel;
            this.DataContext = _viewModel;
            this.Loaded += OnIntelliSenseViewLoadedHandler;
        }

        #endregion

        #region Methods

        #region Set Reset Filtering State

        private void SetResetFilteringState()
        {
            bool resetEnable = false;
            if (_viewModel.Filters != null)
            {
                foreach (KeyValuePair<String, Filter> item in _viewModel.Filters)
                {
                    if (item.Value.IsChecked)
                        continue;

                    resetEnable = true;
                    break;
                }
            }
            _resetCommand.IsChecked = resetEnable;
            _resetCommand.IsEnabled = resetEnable;
        }

        #endregion // Set Reset Filtering State

        #endregion // Methods

        #region Event Handlers

        #region On IntelliSense View Loaded Handler 

        private void OnIntelliSenseViewLoadedHandler(object sender, RoutedEventArgs e)
        {
            if (_viewModel == null)
                return;

            _viewModel.Refresh();
        }

        #endregion // On IntelliSense View Loaded Handler 

        #region On List Loaded Handler

        #region Documentation
        /// <summary>
        /// Occurs when the list is loaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        #endregion // Documentation
        private void OnListLoadedHandler(object sender, RoutedEventArgs e)
        {
            if (_viewModel != null)
            {
                Debug.WriteLine("*** Loaded :" + _watch.ElapsedMilliseconds); 
                if (_viewModel.Items.View.CurrentItem != null)
                    this.listViewCompletions.ScrollIntoView(_viewModel.Items.View.CurrentItem);

                if (_viewModel.Filters != null)
                {

                    Style toggleStyle = this.TryFindResource("filterButtonStyle") as Style;
                    Binding b;
                    ToggleButton btn;
                    foreach (KeyValuePair<String, Filter> item in _viewModel.Filters)
                    {
                        if (item.Value.IsActiveInCurrentSession)
                        {
                            btn = new ToggleButton()
                            {
                                Content = new Image() { Source = item.Value.ImageSource },
                                ToolTip = "Show/hide matching items "
#if DEBUG
 + item.Key
#endif // DEBUG
                                ,
                                Focusable = false,
                                Tag = item.Value,
                                IsChecked = item.Value.IsChecked
                            };

                            #region IsVisible binding

                            b = new Binding("IsVisible");
                            b.Mode = BindingMode.OneWay;
                            btn.SetBinding(ToggleButton.VisibilityProperty, b);
                            btn.DataContext = item.Value;

                            #endregion // IsVisible binding

                            
                            if (toggleStyle != null)
                                btn.Style = toggleStyle;
                            btn.Click += OnFilterClickHandler;
                            _viewModel.FilterView.Add(btn);
                            item.Value.Owner = btn;
                        }
                    }

                    #region Reset

                    var img = new Image();
                    var packUri = "pack://application:,,,/CSharpIntellisensePresenter;component/Resources/Reset.png";
                    img.Source = new ImageSourceConverter().ConvertFromString(packUri) as ImageSource;
                    btn = new ToggleButton()
                    {
                        Content = img,
                        Focusable = false,
                        IsEnabled = false,
                        IsChecked = false,
                        ToolTip = "Reset the filter"
                    };
                    if (toggleStyle != null)
                        btn.Style = toggleStyle;
                    _resetCommand = btn;
                    SetResetFilteringState();
                    btn.Click += new RoutedEventHandler(OnResetFilterHandler);
                    _viewModel.FilterView.Add(btn);

                    #endregion // Reset

                    #region Single

                    img = new Image();
                    packUri = "pack://application:,,,/CSharpIntellisensePresenter;component/Resources/SingleSelection.png";
                    img.Source = new ImageSourceConverter().ConvertFromString(packUri) as ImageSource;
                    btn = new ToggleButton()
                    {
                        Content = img,
                        Focusable = false,
                        ToolTip = "Select single filter",
                        IsChecked = _viewModel.IsSingleFiltering
                    };
                    if (toggleStyle != null)
                        btn.Style = toggleStyle;
                    btn.Click += OnShowHideSingleFilteringHandler;
                    _viewModel.FilterView.Add(btn);
                    //this._tbFilters.Items.Add(btn);

                    #endregion // Single

                    #region Tooltip

                    img = new Image();
                    packUri = "pack://application:,,,/CSharpIntellisensePresenter;component/Resources/Tooltip.png";
                    img.Source = new ImageSourceConverter().ConvertFromString(packUri) as ImageSource;
                    btn = new ToggleButton()
                    {
                        Content = img,
                        Focusable = false,
                        ToolTip = "Show / Hide documentation",
                        IsChecked = (_viewModel.IsShowTooltip == System.Windows.Visibility.Visible)
                    };
                    if (toggleStyle != null)
                        btn.Style = toggleStyle;
                    btn.Click += OnShowHideTooltipHandler;
                    _viewModel.FilterView.Add(btn); 
                    //this._tbFilters.Items.Add(btn);

                    #endregion // Tooltip
                }
                _watch.Stop();
                Debug.WriteLine("*** Load Complete:" + _watch.ElapsedMilliseconds); 

            }
        }

        #endregion // On List Loaded Handler

        #region On Filter Click Handler

        private void OnFilterClickHandler(Object sender, RoutedEventArgs e)
        {
            if (_viewModel != null)
            {
                ToggleButton btn = sender as ToggleButton;
                if (btn == null)
                    return;

                if (_viewModel.IsSingleFiltering)
                {
                    foreach (KeyValuePair<String, Filter> item in _viewModel.Filters)
                    {
                        Filter filter = item.Value;
                        bool isFilter = (btn == filter.Owner);
                        filter.IsChecked = isFilter;
                        filter.Owner.IsChecked = isFilter;

                    }
                    SetResetFilteringState();
                    _viewModel.Refresh();
                }
                else
                {
                    Filter filter = btn.Tag as Filter;

                    if (filter == null)
                        return;

                    filter.IsChecked = !filter.IsChecked;

                    bool hasFilter = false;
                    foreach (KeyValuePair<String, Filter> item in _viewModel.Filters)
                    {
                        if (item.Value.IsChecked)
                        {
                            hasFilter = true;
                            break;
                        }
                    }
                    if (!hasFilter)
                    {
                        filter.IsChecked = true;
                        filter.Owner.IsChecked = true;
                        //_viewModel.Refresh();
                    }
                    else
                        _viewModel.ExecuteFilter(filter);

                }

                SetResetFilteringState();
            }
        }

        #endregion // On Filter Click Handler

        #region On Mouse Double Click Handler

        private void OnMouseDoubleClickHandler(Object sender, MouseButtonEventArgs e)
        {
            if (_viewModel != null)
            {
                #region Validation

                if (e.OriginalSource.GetType().Name == "ScrollChrome")
                    return;
                if (e.OriginalSource.GetType().Name == "Rectangle")
                    return;

                #endregion // Validation

                ListBox lb = sender as ListBox;
                if (lb != null && lb.SelectedItem != null)
                {
                    var completion = (Completion)lb.SelectedItem;
                    _viewModel.SelectedCompletionSet.SelectionStatus = new CompletionSelectionStatus(completion, true, true);
                }
                _viewModel.Commit();
            }
        }

        #endregion // On Mouse Double Click Handler

     

        #region On Reset Filter Handler

        private void OnResetFilterHandler(Object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn == null)
                return;

            if (_viewModel != null)
            {
                foreach (KeyValuePair<String, Filter> item in _viewModel.Filters)
                {
                    Filter filter = item.Value;
                    bool isFilter = true;
                    filter.IsChecked = isFilter;
                    filter.Owner.IsChecked = isFilter;
                }
                _viewModel.Refresh();
            }
        }

        #endregion // On Reset Filter Handler

        #region On Show Hide Tooltip Handler

        private void OnShowHideTooltipHandler(Object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn == null)
                return;

            if (_viewModel != null)
            {
                if (_viewModel.IsShowTooltip != Visibility.Visible)
                {
                    _viewModel.IsShowTooltip = Visibility.Visible;
                    btn.IsChecked = true;
                }
                else
                {
                    _viewModel.IsShowTooltip = Visibility.Collapsed;
                    btn.IsChecked = false;
                }

                //_viewModel.Refresh();
            }

            if (_viewModel.Items.View.CurrentItem != null)
                this.listViewCompletions.ScrollIntoView(_viewModel.Items.View.CurrentItem);
        }

        #endregion // On Show Hide Tooltip Handler

        #region On Show Hide Single Filtering Handler

        private void OnShowHideSingleFilteringHandler(Object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn == null)
                return;

            if (_viewModel != null)
            {
                _viewModel.IsSingleFiltering = !_viewModel.IsSingleFiltering;
                btn.IsChecked = _viewModel.IsSingleFiltering;
            }
        }

        #endregion // On Show Hide Single Filtering Handler

        #endregion // Event Handlers
    }
}
