﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 21.08.2015
 * Time: 11:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10107.Protocol
{
	/// <summary>
	/// Description of FoundationFieldbus.
	/// </summary>
	public class FoundationFieldbus
	{
		public const string commDriver = "FF H1 CommDTM";
		public const string protocolName = "FDT FIELDBUS FF H1";
		public const string communicationHardwareName = "NI USB";
		public const string versionInfo = "V1.0.42";
		
		public string CommunicationDriverName
		{
			get { return commDriver; }
		}
		public string ProtocolName
		{
			get { return protocolName; }
		}
		public string CommunicationHardwareName
		{
			get { return communicationHardwareName; }
		}
		public string VersionInfo
		{
			get { return versionInfo; }
		}
	}
}
