﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 21.08.2015
 * Time: 10:49
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10107.Protocol
{
	/// <summary>
	/// Description of HART.
	/// </summary>
	public class HART
	{
		public const string commDriver = "HART Communication";
		public const string protocolName = "HART";
		public const string commHardwareMactek = "VIATOR";
		public const string commHardwareFXA195 = "FXA195";
		public const string commHardwareVector = "Vector InfoTech HART";
		public const string versionInfo = "V1.0.42";
		public const bool isServiceInterface = false;

		public string CommunicationDriverName
		{
			get { return commDriver; }
		}
		public string ProtocolName
		{
			get { return protocolName; }
		}
		public string CommunicationHardwareMactek
		{
			get { return commHardwareMactek; }
		}
		public string CommunicationHardwareFXA195
		{
			get { return commHardwareFXA195; }
		}
		public string CommunicationHardwareVector
		{
			get { return commHardwareVector; }
		}
		public string VersionInfo
		{
			get { return versionInfo; }
		}
		
	}
}
