﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 16.09.2015
 * Time: 15:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10300.Functions.ApplicationArea.Page_Assistant_EH_ProtocolSelection
{
	/// <summary>
	/// Description of Assistant_EH_ProtocolSelection.
	/// </summary>
	public class Assistant_EH_ProtocolSelection_Functions
	{
		public Assistant_EH_ProtocolSelection_Functions()
		{
		}
	}
}
