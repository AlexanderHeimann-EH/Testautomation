﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 21.08.2015
 * Time: 12:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10300.Protocol
{
	/// <summary>
	/// Description of CDITCPIP.
	/// </summary>
	public class CDITCPIP
	{
		public const string commDriverName = "CDI Communication TCP/IP";
		public const string protocolName = "CDI TCP/IP";
		public const string versionInfo = "V1.0.42";
		
		public string CommDriverName
		{
			get { return commDriverName; }
		}
		public string ProtocolName
		{
			get { return protocolName; }
		}
		public string VersionInfo
		{
			get { return versionInfo; }
		}
	}
}
