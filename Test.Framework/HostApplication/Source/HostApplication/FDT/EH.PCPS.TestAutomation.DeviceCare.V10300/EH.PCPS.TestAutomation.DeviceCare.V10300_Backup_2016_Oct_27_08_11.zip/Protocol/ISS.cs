﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 21.08.2015
 * Time: 12:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10300.Protocol
{
	/// <summary>
	/// Description of ISS.
	/// </summary>
	public class ISS
	{
		public const string commDriverName = "Flow Communication FXA193/291";
		public const string protocolName = "ISS";
		public const string communicationHardwareName193 = "FXA193";
		public const string versionInfo = "V1.0.42";
		
		public string CommDriverName
		{
			get { return commDriverName; }
		}
		public string ProtocolName
		{
			get { return protocolName; }
		}
		public string CommunicationHardwareNameFXA193
		{
			get { return communicationHardwareName193; }
		}
		public string VersionInfo
		{
			get { return versionInfo; }
		}
	}
}
