﻿/*
 * Created by Ranorex
 * User: Simon Schwab
 * Date: 21.08.2015
 * Time: 12:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EH.PCPS.TestAutomation.DeviceCare.V10300.Protocol
{
	/// <summary>
	/// Description of Profibus.
	/// </summary>
	public class Profibus
	{
		public const string commDriver = "PROFIdtm DPV1";
		public const string protocolName = "Profibus DP/V1";
		public const string communicationHardwareNamePcmcia = "Softing PCMCIA";
		public const string communicationHardwareNameUsb = "Softing USB";
		public const string versionInfo = "V1.0.42";
		
		public string CommDriver {
			get { return commDriver; }
		}
		public string ProtocolName {
			get { return protocolName; }
		}
		public string CommunicationHardwareNamePcmcia {
			get { return communicationHardwareNamePcmcia; }
		}
		public string CommunicationHardwareNameUsb {
			get { return communicationHardwareNameUsb; }
		}
		public string VersionInfo {
			get { return versionInfo; }
		}
	}
}
