﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="Endress+Hauser Process Solutions AG" file="OpenHostApplication.cs">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   Description of OpenHostApplication.
// </summary>
// 
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceCare.V10300.CommonFlows
{
    using System.Reflection;

    using EH.PCPS.TestAutomation.Common.Tools;

    /// <summary>
    /// Description of OpenHostApplication.
    /// </summary>
    public class OpenHostApplication : EH.PCPS.TestAutomation.CommonHostApplicationLayerInterfaces.CommonFlows.IOpenHostApplication
    {
        public OpenHostApplication()
        {
        }
        
        public bool Run()
        {
            var module = new EH.PCPS.TestAutomation.DeviceCare.V10300.Functions.Helpers.DeviceCareProcessFunctions();
            
            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");
            
            return module.Run();
        }
        
        public bool Run(string path)
        {
            var module = new EH.PCPS.TestAutomation.DeviceCare.V10300.Functions.Helpers.DeviceCareProcessFunctions();
            
            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");
            
            int processID = module.Run(path);

            return module.IsHostApplicationRunning(processID);
            
        }
        
        public bool Run(string path, int timeOutInMilliseconds)
        {
            var module = new EH.PCPS.TestAutomation.DeviceCare.V10300.Functions.Helpers.DeviceCareProcessFunctions();
            
            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");
            
            int processID = module.Run(path,timeOutInMilliseconds);
            
            return module.IsHostApplicationRunning(processID);
        }
        
    }
}
