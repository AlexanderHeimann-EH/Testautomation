﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OpenHostApplication.cs" company="Endress+Hauser Process Solutions AG">
//   Copyright © Endress+Hauser Process Solutions AG 2015
// </copyright>
// <summary>
//   
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace EH.PCPS.TestAutomation.DeviceCare.CI.CommonFlows
{
    using System.Reflection;

    using EH.PCPS.TestAutomation.Common.Tools;
    using EH.PCPS.TestAutomation.CommonHostApplicationLayerInterfaces.CommonFlows;

    /// <summary>
    /// The open host application.
    /// </summary>
    public class OpenHostApplication : IOpenHostApplication
    {
        /// <summary>
        /// The run.
        /// </summary>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public bool Run()
        {
            var module = new Functions.Helpers.DeviceCareProcessFunctions();

            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");

            return module.Run();
        }

        /// <summary>
        /// The run.
        /// </summary>
        /// <param name="path">
        /// The path.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public bool Run(string path)
        {
            var module = new Functions.Helpers.DeviceCareProcessFunctions();
            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");
            int processId = module.Run(path);
            return module.IsHostApplicationRunning(processId);
        }

        /// <summary>
        /// The run.
        /// </summary>
        /// <param name="path">
        /// The path.
        /// </param>
        /// <param name="timeOutInMilliseconds">
        /// The time out in milliseconds.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public bool Run(string path, int timeOutInMilliseconds)
        {
            var module = new Functions.Helpers.DeviceCareProcessFunctions();
            Log.Info(LogInfo.Namespace(MethodBase.GetCurrentMethod()), "Current task: Open HostApplication (DeviceCare)");
            int processId = module.Run(path, timeOutInMilliseconds);
            return module.IsHostApplicationRunning(processId);
        }
    }
}
